from flet import*
(
UserControl,
colors,
Text,
Slider,
Container,
Column,
Stack,
CrossAxisAlignment,
border,
Switch,
BoxShadow,
ShadowBlurStyle,
Offset,
Page,
app,
LinearGradient,
Alignment,
GradientTileMode,



)
# Switch(label_position = 'stretch', label = 'Continuar', data = 'Continuar')

class Botao2(UserControl):
    def __init__(self,
        nome = 'nome',
        min = 0,
        max = 10,
        width = 100,
        nome_size = 25,
        valor_size = 25,
        bgcolor = '#6300f2',
        ponter_color = colors.WHITE,
        Border = 3,
        border_color = '#ffffff',
        data = None,
        with_Switch = False,  
        on_change =None,  
        value = None, 
        value_switch = False,      
 
                 ):
        super().__init__()
        # self.page = pae
        self.nome_size = nome_size
        self.min = min
        self.max = max
        self.valor_size = valor_size
        self.bgcolor = bgcolor
        self.ponter_color = ponter_color
        self.border = Border
        self.border_color = border_color
        self.data = data
        self.with_Switch = with_Switch
        self.value_switch = value_switch
        self.sw = Switch(visible=self.with_Switch,value = self.value_switch, data=  'sw',on_change = self.change_botao)
        self.on_change = on_change

        self.nome = Text(nome, size=self.nome_size)
        self.width = width
        self.valor_botao = Text('0.0', size = self.valor_size)
        self.value = value
        self.valor = Slider( width= self.width,min = 55, max = 100, divisions = 45, 
                            on_change=self.change_botao,
                            # active_color = "surface,0.0"
                            scale = 2,
                            opacity = 0,
                            bottom = 0,
                            data = self.data,
                            value = 55,
                            )
        self.valor_botao.value = f'{self.value}' if self.value != None else '0,0'
      
        self.bt =  Container(
                            content =Column(
                                        controls = [
                                            # Text(),
                                            Container(width=10,height=10,
                                                      bgcolor=self.ponter_color,
                                                      border_radius=50,
                                                      
                                                      ),
                                            # Text(),
                                                    
                                                    ],
                                        width=20,
                                        height=5,
                                        # bgcolor=colors.BLACK,
                                        expand=0,
                                        alignment='center',
                                         ),
                            width=self.width,
                            height=self.width,
                            bgcolor=self.bgcolor,
                            border_radius=50,
                            scale = 0.9,
                            rotate = self.mapear_valor(self.value,55,100,17,33)*0.314 if self.value != None else 17*0.317,
                            padding = 0,
                            margin=0,
                            border = border.all(self.border, color = self.border_color),
                            shadow = BoxShadow(
                                    spread_radius=0,
                                    blur_radius=100,
                                    color=colors.BLUE,
                                    offset=Offset(0, 0),
                                    blur_style=ShadowBlurStyle.OUTER,
                    ),
                    )
        # self.nome.bottom = 50                                     
        # self.bt.bottom = 25
        # self.valor.bottom = 25
        # self.valor_botao.bottom = 0  
    def build(self):
        # print(type(self.value))
        # if self.value != None:
        #     print(self.mapear_valor(self.value,55,100,17,33)*0.314, self.nome)
        return  Column([
                            self.nome,                                     
                    Stack(
                        [
                            self.bt,
                            self.valor,
                            # Slider( width= self.width,min = 55, max = 100, divisions = 45, 
                            # on_change=self.on_change,
                            # # active_color = "surface,0.0"
                            # scale = 2,
                            # opacity = 0,
                            # bottom = 0,
                            # data = self.data),
                            
                        ]
                    ),
                            self.valor_botao,
                            self.sw,
                        
                    ],
                    horizontal_alignment=CrossAxisAlignment.CENTER,
                    spacing = 0,
                    width=self.width,
                    scale = 0.6,
                    
                    )
        # return Column() 
    
    # @property
    # def on_change(self):
    #     print('evento')
    #     return self._get_event_handler("change")

    # @on_change.setter
    # def on_change(self, handler):
    #     self._add_event_handler("change", handler)
    def Exibir_atributos(self, objeto):
        for i in objeto.__dict__.keys():
            print(i) 
    def change_botao(self,e):
        # on_change_end
        # self.Exibir_atributos(e.page.on_window_event)
        # print(e.page.on_window_event._EventHandler__result_converter)
        if e.control.data != 'sw':
            self.bt.rotate = self.mapear_valor(self.valor.value,55,100,17,33)*0.314
            self.valor_botao.value = f'{round(self.mapear_valor(self.valor.value,55,100,self.min,self.max),1)}'
            self.value = self.valor_botao.value
            # print('self.valor.value: ', self.valor.value)
            # print('valor mapeado: ', self.valor_botao.value)
        else:
            self.value_switch = self.sw.value
        super().update()
    def mapear_valor(self, valor, inicio_intervalo_original, fim_intervalo_original, inicio_intervalo_alvo, fim_intervalo_alvo):
        # Garante que o valor esteja no intervalo original
        valor = max(min(valor, fim_intervalo_original), inicio_intervalo_original)

        # Calcula a porcentagem do valor no intervalo original
        percentual = (valor - inicio_intervalo_original) / (fim_intervalo_original - inicio_intervalo_original)

        # Mapeia a porcentagem para o intervalo alvo
        valor_mapeado = inicio_intervalo_alvo + percentual * (fim_intervalo_alvo - inicio_intervalo_alvo)

        return valor_mapeado
    


class Botao(UserControl):
    def __init__(self,
        nome = 'nome',
        min = 0,
        max = 10,
        width = 100,
        nome_size = 25,
        valor_size = 25,
        bgcolor = '#6300f2',
        ponter_color = colors.WHITE,
        Border = 3,
        border_color = '#ffffff',
        data = None,
        with_Switch = False,  
        on_change =None,  
        value = None, 
        value_switch = False,      
 
                 ):
        super().__init__()
        # self.page = pae
        self.nome_size = nome_size
        self.min = min
        self.max = max
        self.valor_size = valor_size
        self.bgcolor = bgcolor
        self.ponter_color = ponter_color
        self.border = Border
        self.border_color = border_color
        self.data = data
        self.with_Switch = with_Switch
        self.value_switch = value_switch
        self.sw = Switch(visible=self.with_Switch,value = self.value_switch, data=  'sw',on_change = self.change_botao)
        self.on_change = on_change

        self.nome = Text(nome, size=self.nome_size)
        self.width = width
        self.valor_botao = Text('0.0', size = self.valor_size)
        self.value = value
        self.valor = Slider( width= self.width,min = 55, max = 100, divisions = 45, 
                            on_change=self.change_botao,
                            # active_color = "surface,0.0"
                            scale = 2,
                            opacity = 0,
                            bottom = 0,
                            data = self.data,
                            value = 55,
                            )
        self.valor_botao.value = f'{self.value}' if self.value != None else '0,0'
      
        self.bt2 =  Container(
                            # content =Column(
                            #             controls = [
                            #                 # Text(),
                            #                 Container(width=10,height=10,
                            #                           bgcolor=self.ponter_color,
                            #                           border_radius=50,
                                                      
                            #                           ),
                            #                 # Text(),
                                                    
                            #                         ],
                            #             width=20,
                            #             height=5,
                            #             # bgcolor=colors.BLACK,
                            #             expand=0,
                            #             alignment='center',
                            #              ),
                            width=self.width,
                            height=self.width,
                            bgcolor=self.bgcolor,
                            border_radius=50,
                            scale = 0.9,
                            rotate = self.mapear_valor(self.value,55,100,17,33)*0.314 if self.value != None else 17*0.317,
                            padding = 0,
                            margin=0,
                            border = border.all(5, color = colors.with_opacity(0.2,'gray')),
                            shadow = BoxShadow(
                                spread_radius=0,
                                blur_radius=20,
                                color=colors.with_opacity(1,'black'),
                                offset=Offset(0, 0),
                                blur_style=ShadowBlurStyle.NORMAL),
                            gradient=LinearGradient(
                                begin=Alignment(-1, -1),
                                end=Alignment(-0.1, -0.1),
                                
                                colors=[
                                    "#777777",
                                    "black",
                                         ],
                                tile_mode=GradientTileMode.MIRROR,
                                rotation=70*3.14/180,
                            )
                    )
        self.bt =  Container(
                            content =Column(
                                        controls = [
                                            # Text(),
                                            Container(width=10,height=10,
                                                      bgcolor=self.ponter_color,
                                                      border_radius=50,
                                                      
                                                      ),
                                            # Text(),
                                                    
                                                    ],
                                        width=20,
                                        height=5,
                                        # bgcolor=colors.BLACK,
                                        expand=0,
                                        alignment='center',
                                         ),
                            width=self.width,
                            height=self.width,
                            border_radius=50,
                            scale = 0.9,
                            rotate = self.mapear_valor(self.value,55,100,17,33)*0.314 if self.value != None else 17*0.317,
                            padding = 0,
                            margin=0,

                    )
                
        # self.nome.bottom = 50                                     
        # self.bt.bottom = 25
        # self.valor.bottom = 25
        # self.valor_botao.bottom = 0  
    def build(self):
        # print(type(self.value))
        # if self.value != None:
        #     print(self.mapear_valor(self.value,55,100,17,33)*0.314, self.nome)
        return  Column([
                            self.nome,                                     
                    Stack(
                        [
                            self.bt2,
                            self.bt,
                            self.valor,
                            # Slider( width= self.width,min = 55, max = 100, divisions = 45, 
                            # on_change=self.on_change,
                            # # active_color = "surface,0.0"
                            # scale = 2,
                            # opacity = 0,
                            # bottom = 0,
                            # data = self.data),
                            
                        ]
                    ),
                            self.valor_botao,
                            self.sw,
                        
                    ],
                    horizontal_alignment=CrossAxisAlignment.CENTER,
                    spacing = 0,
                    width=self.width,
                    scale = 0.6,
                    
                    )
        # return Column() 
    
    # @property
    # def on_change(self):
    #     print('evento')
    #     return self._get_event_handler("change")

    # @on_change.setter
    # def on_change(self, handler):
    #     self._add_event_handler("change", handler)
    def Exibir_atributos(self, objeto):
        for i in objeto.__dict__.keys():
            print(i) 
    def change_botao(self,e):
        # on_change_end
        # self.Exibir_atributos(e.page.on_window_event)
        # print(e.page.on_window_event._EventHandler__result_converter)
        if e.control.data != 'sw':
            self.bt.rotate = self.mapear_valor(self.valor.value,55,100,17,33)*0.314
            self.valor_botao.value = f'{round(self.mapear_valor(self.valor.value,55,100,self.min,self.max),1)}'
            self.value = self.valor_botao.value
            # print('self.valor.value: ', self.valor.value)
            # print('valor mapeado: ', self.valor_botao.value)
        else:
            self.value_switch = self.sw.value
        super().update()
    def mapear_valor(self, valor, inicio_intervalo_original, fim_intervalo_original, inicio_intervalo_alvo, fim_intervalo_alvo):
        # Garante que o valor esteja no intervalo original
        valor = max(min(valor, fim_intervalo_original), inicio_intervalo_original)

        # Calcula a porcentagem do valor no intervalo original
        percentual = (valor - inicio_intervalo_original) / (fim_intervalo_original - inicio_intervalo_original)

        # Mapeia a porcentagem para o intervalo alvo
        valor_mapeado = inicio_intervalo_alvo + percentual * (fim_intervalo_alvo - inicio_intervalo_alvo)

        return valor_mapeado
    

# # Column([
#                 Text('Nome', color  = 'white'),
#                 Container(
#                 rotate = 3.14*0.5,
#                 content= Column([Container(expand = 0,shape = BoxShape.CIRCLE,height = 6, width = 6,bgcolor= 'blue')], alignment='center'),
#                 shape = BoxShape.CIRCLE,
#                 bgcolor= '#222222',
#                 height = 60,
#                 width = 60,
#                 border = border.all(5, color = colors.with_opacity(0.2,'gray')),                        
#                 shadow = BoxShadow(
#                     spread_radius=0,
#                     blur_radius=20,
#                     color=colors.with_opacity(1,'black'),
#                     offset=Offset(0, 0),
#                     blur_style=ShadowBlurStyle.NORMAL),

#                 gradient=LinearGradient(
#                         begin=Alignment(-1, -1),
#                         end=Alignment(-0.1, -0.1),
                        
#                         colors=[
#                             "#777777",
#                             "black",
#                             # "0xff870160",
#                             # "0xffac255e",
#                             # "0xffca485c",
#                             # "0xffe16b5c",
#                             # "0xfff39060",
#                             # "0xffffb56b",
#                         ],
#                         tile_mode=GradientTileMode.MIRROR,
#                         rotation=3.14*1.5,
#                     )
                        
#             #     ),
#             #     Text('valor', color  = 'white'),
#             # ],horizontal_alignment = 'center', spacing=0,




def main_test(page: Page):
    page.title = "NAM"
    # page.window_title_bar_hidden = True
    page.window_movable = True
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.LIGHT
    page.window_width = 600
    page.window_height = 460
    


    b = FloatingActionButton('Play',icon=icons.PLAY_ARROW, width= 130, bgcolor='blue', expand=0)
    c = Row([b,b,b,b], alignment=MainAxisAlignment.SPACE_BETWEEN, spacing=1)
    page.add(c)
    page.update()



if __name__ == '__main__':
    app(target=main_test)




