from flet import(

    Checkbox,
    Dropdown,
    Column,
    Container,
    WEB_BROWSER,
    app,
    Icon,
    AppBar,
    Alignment,
    border,
    icons,
    KeyboardEvent,
    theme,
    Slider,
    PopupMenuButton,
    PopupMenuItem,
    FloatingActionButton,
    NavigationRail,
    NavigationRailDestination,
    IconButton,
    Switch,
    ListView,
    Page,
    Row,
    Tab,
    Tabs,
    CrossAxisAlignment,
    MainAxisAlignment,
    MainAxisAlignment,
    ThemeMode,
    Text,
    TextField,
    ScrollMode,
    UserControl,

    Control,
    colors,
    icons,
    padding,
    margin,    
    alignment,    
    Divider,
    dropdown,
    Stack,
    border_radius,    
    InputBorder,
    MainAxisAlignment,
    AppView,
    BoxShadow,
    Offset,
    ShadowBlurStyle,
    TextThemeStyle,
    TextButton,
    GridView,
)
    
    
from time import sleep
import os
os.environ["FLET_WS_MAX_MESSAGE_SIZE"] = "8000000"

from todo2 import Eventos, Thread
from flet import theme
from Botao import Botao
from Swhitch_new import Switch_new
# import tracemalloc
# tracemalloc.start()

class Layout(Eventos):
    def __init__(self, page):
        super().__init__(page)
        # self.switch = Switch_new()
        self.saida = self.MeuContainer() 
        self.page = page
        # self.height = self.page.window_height
        # # self.ncontinuar = Switch(label_position = 'stretch', label = 'Continuar', data = 'Continuar')
        self.ncontinuar = Switch_new('Continuar')
        self.inverter = Switch_new('inverter')
        # # self.pomodoro_ativar = Switch(label = 'Habilitar Pomodoro', data ='Pomodoro_ativar', value = True )
        # self.pomodoro = Dropdown(on_change = self.add_clicked, 
        #                          border_width = 0, 
        #                          options=[dropdown.Option(i) for i in range(1,30,1)], 
        #                          width = 150, 
        #                          value = 3,
        #                          prefix_text = 'Pomodoro:  ', 
        #                          data= 'pomodoro',

        #                          )
        self.pomodoro = Botao(nome = 'Pomodoro', min = 0.1, max = 20, value = 1.0,
                               with_Switch=True, nome_size = 20, value_switch = True,)
        self.descanso = Botao(nome = 'descanso', min = 0.1, max = 20, value = 1.0,nome_size = 21,)
        self.pomodoro_ativar = self.pomodoro.value_switch
        # # self.descanso = Dropdown(on_change = self.add_clicked, border_width = 0, options=[dropdown.Option(i) for i in range(1,30,1)], width = 150, value = 1, prefix_text = 'Descanso:  ', data = 'descanso')
        self.respiro = Container(content=Text(),bgcolor= colors.YELLOW,width = 0, border_radius=40)
        # # self.meta = Slider(min = 30, max = 250, divisions = 220,value = 160, 
        # #                 #   on_change= self.Change_vol
        # #                 scale = 0.5,
        # #                   width = 200,
        # #                 data = 'Meta'
        # #                   )
          
        # # self.inicio = Slider(min = 30, max = 250, divisions = 220,value = 70, 
        # #                      data = 'Início',
        # #                               scale = 0.5,
        # #                   width = 200,
        # #                 #   on_change= self.Change_vol
        # #                   )
        # # self.passo = Slider(min = 0, max = 200, divisions = 201,value = 10,
        # #                 #   on_change= self.Change_vol
        # #                          scale = 0.5,
        # #                   width = 200,
        # #                 data = 'Passo',
        # #                   )
        # # self.passo_fim = Slider(min = 0, max = 20, divisions = 21,value = 10, 
        # #                 #   on_change= self.Change_vol
        # #                 scale = 0.5,
        # #                 width = 200,
        # #                 data = 'Passo_fim',
        # #                   )
        # # self.intervalo = Slider(min = 1, max = 60, divisions = 60,value = 1,
        # #                 #   on_change= self.Change_intervalo
        # #                     scale = 0.5,
        # #                   width = 200,
        # #                 data = 'Intervalo',
        # #                   )
        
        
        self.meta = Botao('Meta', with_Switch=False)
        self.inicio = Botao('inicio')
        self.passo = Botao('passo')
        self.passo_fim = Botao('passo_fim', nome_size = 20)
        self.intervalo = Botao('intervalo')
        # # self.tempo = Switch(label = 'Tempo', data = 'Tempo', on_change=self.pt)
        self.tempo = Switch_new('Tempo', data = 'Tempo')
        self.qtd_compassos = Dropdown(on_change = self.add_clicked, 
                                 border_width = 0, 
                                 options=[dropdown.Option(i) for i in range(1,25)], 
                                 width = 200, 
                                 value = 1,
                                 prefix_text = 'Qtd de Compassos: ',
                                 data = 'qtd_compassos' ,
                                 dense = True,
                                 )
        self.tipo_compasso = Dropdown(on_change = self.add_clicked, 
                                 border_width = 0, 
                                 options=[dropdown.Option(i) for i in ['2/4', '3/4', '4/4']], 
                                 width = 200, 
                                 value = '4/4',
                                 prefix_text = 'Tipo de Compasso: ',                                 
                                 data = 'qtd_compassos', 
                                 dense = True,
                                 )
        self.tipo_treino = Dropdown(on_change = self.add_clicked, 
                            border_width = 0, 
                            options=[dropdown.Option(i) for i in ['Tempo', 'Compassos']], 
                            width = 250, 
                            value = 'Tempo',
                            prefix_text = 'Tipo de Treino: ',                                 
                            data = 'Tipo de Treino' ,
                            dense = True,
                            )
        self.filter = Tabs(
                            selected_index=3, 
                            divider_color = '#282a36',
                            on_change=self.tabs_changed,
                            tabs=[
                                    Tab(text="Todos"), 
                                    Tab(text="Ativos"), 
                                    Tab(text="Concluídos"), 
                                    Tab(text="Metrônomo Normal"),
                                    Tab(text="Lento"),
                                    Tab(text="Médio"),
                                    Tab(text="Rápido"),
                                    Tab(text="Speed Burst"),
                                    ]
                            )
        self.linha_filtros = Row([self.filter], 
            alignment=MainAxisAlignment.SPACE_BETWEEN,
            height=23,
        )        
        self.Vol = self.Botao(0,10,11,'vol', 10)   
        self.tap = FloatingActionButton('Tap', on_click = self.Tap2, bgcolor = colors.with_opacity(1,'#282a36'))  
        self.Criar_tela_mentronomo_nomal()            
        self.Criar_tela_tarefas()
        self.Criar_tela_Concluidos()
        self.Criar_tela_Lento()
        self.Criar_tela_Medio()
        self.Criar_tela_Rapido()
        self.Criar_tela_Speed()
        self.Carregar_dados()
        self.Definir_tela_inicial()  
        # self.pt()
        self.New_task_list = self.MeuContainer('c')
        self.New_task_list.height = 30
        # self.New_task_list.width = 800
        self.New_task_list.content.controls = [
            TextField(
                prefix_text = 'Nova Lista de Tarefas: ',
                expand=1,
            )
        ]
        self.tela_principal = Column(
            [
                self.Menu_bar(),
                Divider(height=1),
                self.linha_filtros, 
                self.linha_pomodoro, 
                self.New_task_list, 
                self.new_task,
                self.saida,
                self.respiro,
                self.tarefas, 
                self.concluidos,
                self.tela_mentronomo_nomal,
                self.Lento,
                self.Medio,
                self.Rapido,
                self.Speed,
            ]
        )
        


    def task_select(self):
       return Container(
            FloatingActionButton(
                icon=icons.ADD_TASK,
                on_click=self.add_clicked,  
                tooltip='Selecionar lita de tarefas',
                data = 'Selecionar lita de tarefas',



           )
       )

    @property
    def new_task(self):
        self.novas_tarefas = self.MeuContainer()
        linha1 = Row(height=33, vertical_alignment = 'center')
        
        self.nova_tarefa = TextField(
            # hint_text="Nome da tarefa", 
            color = '#0fff00',
            # border = InputBorder.OUTLINE, 
            border_width = 0, 
            border_radius = 0,
            prefix_text = 'None da Tarefa: ',
            expand=True, 
            # height = 34,
            content_padding= 0,
            # max_length = 32
        )
        
        botao_add_nova_tarefa = FloatingActionButton(
            icon=icons.ADD, 
            on_click=self.add_clicked, 
            data = 'add_tarefa', 
            tooltip='adionar nova tarefa',
            bgcolor = colors.with_opacity(1,'#282a36'),
        )
        Botao_exibir_saidas = FloatingActionButton(icon=icons.OUTLINED_FLAG_OUTLINED, on_click=self.add_clicked, data = 'teste exibir', tooltip='enviar texto para saída')
        Botao_salvar = FloatingActionButton(icon=icons.SAVE, on_click=self.Salvar_cofig, data = 'salvar', tooltip='salvar tarefas', bgcolor = colors.with_opacity(1,'#282a36'))
        linha1.controls = [
            self.nova_tarefa, 
            botao_add_nova_tarefa,
            # self.task_select(),
            # Botao_exibir_saidas, 
            Botao_salvar
                           ]
        self.novas_tarefas.content = linha1    
        return self.novas_tarefas
    @property
    def linha_pomodoro(self):
        a1 = self.MeuContainer(tipo = 'c', cor = '#770808')#1d1e22

        
        linha2 = Column([
                        Row([self.ncontinuar],alignment = MainAxisAlignment.SPACE_AROUND),
                        

                                            ])  
        linha3 = [self.pomodoro, self.descanso, self.meta,self.inicio,self.passo,self.passo_fim, self.intervalo]
              

        a1.content = Row(linha3, alignment=MainAxisAlignment.SPACE_AROUND,
                          height=150,
                          vertical_alignment = 'start',
                          spacing = 0,
                          tight = 1,
                          )
        return a1      
    @property
    def Barra_App(self):
        self.barra_app =  AppBar(
            leading=IconButton(icons.PALETTE, 
                               on_click = self.Selecionar_cor, 
                               tooltip='selecionar cor'),
            # leading_width=self.page.window_width,
            # automatically_imply_leading = True,
            title=Text("Metrônomo"),
            center_title=False,
            bgcolor='#18162a',
            )
        self.barra_app.actions=[

                Dropdown(on_change = self.add_clicked, 
                                 border_width = 0, 
                                 options=[dropdown.Option(i) for i in range(1,25)], 
                                 width = 400, 
                                 value = 1,
                                 prefix_text = 'Selecionar Lista de Tarefas: ',
                                 data = 'Selecionar Lista de Tarefas' ,
                                 content_padding = 0,
                                 dense = True,
                                 ),
                IconButton(icons.WB_SUNNY_OUTLINED),
                IconButton(icons.FILTER_3),
                PopupMenuButton(
                    items=[
                        PopupMenuItem(text="Item 1"),
                        PopupMenuItem(),  # divider
                        PopupMenuItem(
                            text="Checked item", checked=False, 
                            # on_click=check_item_clicked
                        ),
                    ]
                )
        
        ]  
          
    def build(self): 
        return Container(
            # height=self.height-300,
            content=Column([self.tela_principal]),
            shadow = BoxShadow(
            spread_radius=1,
            blur_radius=15,
            color=colors.BLUE_GREY_300,
            offset=Offset(0, 0),
            blur_style=ShadowBlurStyle.OUTER)
            )  
    def MeuContainer(self, tipo = 'c', cor  = "#000000"):#282a36
        match tipo:
            case 'c':
                return Container(bgcolor = cor,
                                border = border.all(1, color = "#4f72a4"),#4f72a4
                                border_radius = 40,
                                content = Column(),
                                shadow = BoxShadow(
                                    spread_radius=1,
                                    blur_radius=8,
                                    color=colors.BLACK54,
                                    offset=Offset(0, 0),
                                    blur_style=ShadowBlurStyle.OUTER,
                                ),
                                )
            case 'r':
                return Container(bgcolor = cor,
                border = border.all(0, color = "#282a36"),#4f72a4
                border_radius = 8,
                padding = 0,
                margin = 0,
                shadow = BoxShadow(
                        spread_radius=1,
                        blur_radius=15,
                        color=colors.BLUE_GREY_300,
                        offset=Offset(0, 0),
                        blur_style=ShadowBlurStyle.OUTER,
                    ),
                content = Row())
    def Criar_tela_mentronomo_nomal(self):
        self.tela_mentronomo_nomal = self.MeuContainer()
        self.tela_mentronomo_nomal.content = Column()
        self.botao_play = IconButton(
                            icon=icons.PLAY_ARROW_ROUNDED,
                            tooltip="Inicia o metrônomo",
                            on_click = self.Play2,
                            data = 'play',
                            scale = 1.5,
                            bgcolor = "#282a36",
                            # bgcolor = "#4a733e",
                            
                        )
        self.botao_pause =   IconButton(
                            icon=icons.PAUSE_ROUNDED,
                            tooltip="Pausa o metrônomo",
                            on_click = self.Metro_normal.Pause,
                            scale = 1.5,
                            bgcolor = "#282a36"
                            # bgcolor = "#ffdb00"
                        )
        self.botao_stope = IconButton(
                            icon=icons.STOP_ROUNDED,
                            tooltip="Para o metrônomo",
                            on_click = self.add_clicked, #self.Metro_normal.Stop,
                            scale = 1.5,
                            bgcolor = "#282a36",
                            data = 'stop metronomo normal',
        
                            # bgcolor = "#"+"80"+"10"+"10"
                        )        
        self.drop_bpm = Dropdown(data = 'valorbpm',
                options=[dropdown.Option(i) for i in range(30,550,1)],
                # alignment = Alignment(0, -1),
                # prefix_text = 'bpm',
                value = 120,
                width = 50,
                color = colors.with_opacity(1,'#282a36'),
                # height = 80,
                text_size = 18,
                border_width = 0,
                on_change = self.Modificar_bpm2, 
                dense = True,                                                  
        )     
        self.bpm = Slider(min = 30, max = 300,opacity = 0,width = 70,
                          value = 120, scale=1.5,
                            on_change = self.Modificar_bpm2 )        
        self.text_bpm = Text(value = self.bpm.value, style=TextThemeStyle.DISPLAY_MEDIUM)
        self.text_vol = Text(f'Vol ({int(10*self.Vol.value)}%)')
        self.tela_mentronomo_nomal.content.controls = [
                    Container(Row([
                    Row([self.text_vol,self.Vol],spacing = 1, 
                        vertical_alignment='center', tight = 1,
                        alignment = MainAxisAlignment.START,
                        
                        ),
                    Row([
        
                        Stack(
                        controls = [
                                
                        self.text_bpm,
                        self.bpm,


                                    ]
                            ),
                        Text('bpm'),
                    ]),
                    
                    # self.drop_bpm,
                    self.botao_play,
                    self.botao_pause,
                    self.botao_stope,
                    self.tap],vertical_alignment = CrossAxisAlignment.CENTER,
                                                alignment=MainAxisAlignment.SPACE_AROUND
                    ),border = border.all(0, color = "#4f72a4"),#4f72a4
                                border_radius = 40, height=70 ),
                    # Row(
                    #         [Column([i],spacing=0, horizontal_alignment= CrossAxisAlignment.CENTER) for i in linha3]
                    #          ,alignment = MainAxisAlignment.SPACE_AROUND),
    
                    Container(
                        content = Row(
                            [
                            # Column([Text('Intervalo'),self.intervalo],spacing=0, 
                            #     horizontal_alignment= CrossAxisAlignment.CENTER),
                            self.ncontinuar,
                            self.tempo,
                            self.inverter,
                            self.tipo_compasso, 
                            self.qtd_compassos,
                            self.tipo_treino,                          
                                
                                
                            ], 
                        alignment = MainAxisAlignment.SPACE_AROUND,
                        ),
                        border = border.all(0, color = "#4f72a4"),#4f72a4
                        border_radius = 40,
                    ),
                    
                
                
                
                    
                    
                    
                    
                    
        ]
        self.tela_mentronomo_nomal.visible = True
        # self.tela_mentronomo_nomal.contet.
    def Criar_tela_tarefas(self):
        self.tarefas = self.MeuContainer()
        self.tarefas.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 300,                                   
                                    scroll = ScrollMode.ADAPTIVE,
                                    
                                    ) 
        # self.tarefas.content = ResponsiveRow(run_spacing=2)
        # self.tarefas.content = GridView(
        #     run_spacing = 0,
        #     expand=0,
        #     max_extent = 10,
        #     spacing = 1, 
        #     padding = 0,
        #     auto_scroll = True,
        #     # child_aspect_ratio = 1,
        #     )    
        # self.tarefas.content = Column(
  
        #     expand=0,
        #     # vertical_alignment = 'start',
        #     spacing = 1,
        #     run_spacing = 2,
        #     # spacing = 1, 
        #     # padding = 0,
        #     # item_extent = 0,
        #     # auto_scroll = True,
        #     # max_extent=10,
        #     height = 500,
        #     wrap=1,
        #     tight =1,
        #     # child_aspect_ratio= 50,
            
        # )
    def Criar_tela_Concluidos(self):
        self.concluidos = self.MeuContainer()
        self.concluidos.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 300,                                   
                                    scroll = ScrollMode.ADAPTIVE,
                                    
                                    )     
    def Criar_tela_Lento(self):
        self.Lento = self.MeuContainer()
        self.Lento.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 420,
                                    scroll = ScrollMode.ALWAYS,
                                    alignment=MainAxisAlignment.START
                                    
                                    )
        # self.Lento.content = ListView(           
        #     expand=1,
        #     spacing = 1, 
        #     padding = 0,
        #     auto_scroll = True,)
    def Criar_tela_Medio(self):
        self.Medio = self.MeuContainer()
        self.Medio.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 420,
                                    scroll = ScrollMode.ALWAYS,
                                    alignment=MainAxisAlignment.START
                                    
                                    )
        # self.Medio.content = ListView()
    def Criar_tela_Rapido(self):
        self.Rapido = self.MeuContainer()
        self.Rapido.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 420,
                                    scroll = ScrollMode.ALWAYS,
                                    alignment=MainAxisAlignment.START
                                    
                                    )
        # self.Rapido.content = ListView()
    def Criar_tela_Speed(self):
        self.Speed = self.MeuContainer()
        self.Speed.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 420,
                                    scroll = ScrollMode.ALWAYS,
                                    alignment=MainAxisAlignment.START
                                    
                                    ) 
        # self.Rapido.content = ListView()
    def Definir_tela_inicial(self):
        aba = self.filter.tabs[self.filter.selected_index].text    
        match aba:
            case "Todos":
                self.tarefas.visible = True
                self.tela_mentronomo_nomal.visible = False
                self.Lento.visible = False
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = False   
                self.concluidos.visible = False                         
            case "Metrônomo Normal":
                self.tarefas.visible = False
                self.tela_mentronomo_nomal.visible = True
                self.Lento.visible = False
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = False
                self.concluidos.visible = False                
            case "Lento":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = True 
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = False     
                self.concluidos.visible = False                                                        
            case "Médio":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = False 
                self.Medio.visible = True
                self.Rapido.visible = False
                self.Speed.visible = False
                self.concluidos.visible = False                
            case "Rápido":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = False 
                self.Medio.visible = False
                self.Rapido.visible = True
                self.Speed.visible = False
                self.concluidos.visible = False                 
            case "Speed Burst":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = False 
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = True
                self.concluidos.visible = False                 


            case 'Ativos':
                self.Lento.visible = True
                self.Medio.visible = True
                self.Rapido.visible = True
                self.Speed.visible = True
                self.tarefas.visible = True
                self.tela_mentronomo_nomal.visible = False
                self.concluidos.visible = False

            case 'Concluídos':
                self.concluidos.visible = True
                self.Lento.visible = False
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = False                
                self.tarefas.visible = False
                self.tela_mentronomo_nomal.visible = False 
                

            case _:
                self.tarefas.visible = True
                self.tela_mentronomo_nomal.visible = False
                self.Lento.visible = False

     
        super().update()
    def Botao(self, min, max,divisions, data, value):#, min, max,divisions, data, value
        return Slider(min = min, max = max, divisions = divisions,value = value, 
                        #   scale = 0.5,
                        #   width = 300,
                        # height=1,
                        # inactive_color='red',
                        thumb_color = 'red',
                        round =3,
                            on_change= self.add_clicked,
                            data = data,
                           )  
    def pt(self):
        def bb():
            a = self.pomodoro.value
            while True:
                if self.pomodoro.value != a:
                    print(self.pomodoro.value)
                    a = self.pomodoro.value
                sleep(0.3)
        Thread(target=bb, daemon=False).start()
    def Menu_bar(self):
        self._barra = Row(
            wrap=True,
            height=28,
            controls = [
                TextButton('Importar'),
                TextButton('Exportar'),
                TextButton('Selecionar Planilha'),
                TextButton('menu 4'),
                TextButton('menu 5'),
            ]


        ) 
        return  self._barra


def main(page: Page):
    page.title = "ToDo App"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    page.bgcolor = '#000000', #'#282a36'
    page.theme = theme.Theme( font_family="Verdana")
    page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 900
    page.window_height = 1000

    
    app = Layout(page)
    page.on_keyboard_event = app.Teclas
    page.add(app)
    app.Barra_App
    page.appbar = app.barra_app



    page.update() 

# app(target=main, view=AppView.WEB_BROWSER, port=51770)
# app(port=8550, target=main)
app(target=main, view=AppView.WEB_BROWSER)


