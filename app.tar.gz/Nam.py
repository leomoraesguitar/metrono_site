

from flet import*
from time import sleep, time
from winsound import MessageBeep, MB_ICONHAND

class Nam (UserControl):
    def __init__(self):
        super().__init__()
        self.Nam = Container()
        self.interno = Column()
        self.botao = Column([
                Text('Nome', color  = 'white'),
                Stack(
                    controls = [
                        Container(
                            rotate = 3.14*0.5,
                            
                            shape = BoxShape.CIRCLE,
                            bgcolor= '#222222',
                            height = 60,
                            width = 60,
                            border = border.all(5, color = colors.with_opacity(0.2,'gray')),                        
                            shadow = BoxShadow(
                                spread_radius=0,
                                blur_radius=20,
                                color=colors.with_opacity(1,'black'),
                                offset=Offset(0, 0),
                                blur_style=ShadowBlurStyle.NORMAL),

                            gradient=LinearGradient(
                                    begin=Alignment(-1, -1),
                                    end=Alignment(-0.1, -0.1),
                                    
                                    colors=[
                                        "#777777",
                                        "black",
                                        # "0xff870160",
                                        # "0xffac255e",
                                        # "0xffca485c",
                                        # "0xffe16b5c",
                                        # "0xfff39060",
                                        # "0xffffb56b",
                                    ],
                                    tile_mode=GradientTileMode.MIRROR,
                                    rotation=3.14*1.5,
                                )
                        
                        ),
                    Container(
                        rotate = 3.14*0.5,
                        content= Column([Container(expand = 0,shape = BoxShape.CIRCLE,height = 6, width = 6,bgcolor= 'blue')], alignment='center'),
                        shape = BoxShape.CIRCLE,                        
                        height = 60,
                        width = 60,                            
                        )

                    ]

                ),
                
                Text('valor', color  = 'white'),
            ],horizontal_alignment = 'center', spacing=0,
            )
       

        
 


    def build(self):
        self.Nam.width = 600
        self.Nam.height = 400
        self.Nam.bgcolor = '#1d1e22'
        self.Nam.border = border.all(3, color = 'black')    
        self.Nam.border_radius = 20
        self.Nam.alignment = Alignment(0,0)



        self.col1 = Column(
            controls = [
                Container(
                    height=230,
                    margin =  margin.all(10),
                    content = Column([
                        Row([Text('NEURAL AMP MODELER', color  = 'white', size = 25)], vertical_alignment= 'center', alignment='center', height=50),
                        Container(height = 0.8, width = 400,  bgcolor = colors.with_opacity(0.1,'white')),
                        Row([self.botao,self.botao,self.botao,self.botao,self.botao,self.botao,],alignment=MainAxisAlignment.SPACE_BETWEEN),
                        Row([
                            VerticalDivider(width=85, opacity = 0),
                            Switch(
                                    scale=0.65,                                   
                                    inactive_track_color = 'black',
                                    inactive_thumb_color = '#555555', 
                                    # track_color = 'black',
                                    value = True,                                  
                            ),
                            VerticalDivider(width=105, opacity = 0),

                            Switch(
                                    scale=0.65,                                   
                                    inactive_track_color = 'black',
                                    inactive_thumb_color = '#555555', 
                                    # thumb_color = 'black',
                                    value = True,                                  
                            ),
                            VerticalDivider(width=105, opacity = 0),

                            Switch(
                                    scale=0.65,                                   
                                    inactive_track_color = 'black',
                                    inactive_thumb_color = '#555555', 
                                    # thumb_color = 'black',                                  
                            )
                            
                            
                            
                            ],height=20),
                        Row([
                            VerticalDivider(width=100),
                            Text('Gate', color  = 'white'),
                            VerticalDivider(width=140),
                            Text('EQ', color  = 'white'),
                            VerticalDivider(width=120),
                            Text('Normalize', color  = 'white')]),

                                ],height=20),
                    ),
                Divider(height = 3, color = colors.with_opacity(0.1,'white')),
                Container(
                    content= Column([
                        Container(bgcolor='black',width= 400,height=20,border = border.only(bottom=border.BorderSide(3, colors.with_opacity(0.3,'white')))),
                        Container(bgcolor='black',width= 400,height=20,border = border.only(bottom=border.BorderSide(3, colors.with_opacity(0.3,'white')))),
                        

                    ],horizontal_alignment='center')
                ),

            ],
            horizontal_alignment= 'center',


        )




        self.interno.controls = [Container(     
                            bgcolor = '#1d1e22',
                            width = 550,
                            height = 350,
                            expand = 0,
                            border_radius = 50,

                            border = border.all(1, color = colors.with_opacity(0.1,'white')),                        
                            shadow = BoxShadow(
                                spread_radius=0,
                                blur_radius=0.5,
                                color=colors.with_opacity(1,'gray'),
                                offset=Offset(-5, -5),
                                blur_style=ShadowBlurStyle.SOLID),

                            content = self.col1,
                                      
                            )]
        
        self.interno.alignment = 'center'









        self.Nam.content = self.interno
        return self.Nam



def main_test(page: Page):
    page.title = "NAM"
    # page.window_title_bar_hidden = True
    page.window_movable = True
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    # page.theme_mode = ThemeMode.LIGHT
    page.window_width = 600
    page.window_height = 460
    


    n = Nam()
    page.add(n)
    page.update()



if __name__ == '__main__':
    app(target=main_test)