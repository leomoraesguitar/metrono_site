from flet import(
UserControl,
colors,
Text,
Slider,
Container,
Column,
Stack,
CrossAxisAlignment,
border,
Switch,
BoxShadow,
ShadowBlurStyle,
Offset,
Row,

)
# Switch(label_position = 'stretch', label = 'Continuar', data = 'Continuar')

class Switch_new(UserControl):
    def __init__(self,
        nome = '',
        nome_size = 20,
        data = None,
        value = None, 
        horizontal = False,
   
 
                 ):
        super().__init__()
        # self.page = pae
        self.nome_size = nome_size       
        self.data = data
        self.value = value
        self._horizontal = horizontal
        self.sw = Switch(value = self.value, 
                         data=  self.data,
                         scale = 1.3,
                         on_change = self.change_botao,
                         )
    
        self.nome = Text(nome,
                        size=self.nome_size, 
                        scale = 1.6,
                        # width=700,
                         
                           )
       
    def build(self):
        if self._horizontal:
            return  Row([self.nome,  self.sw]
            ,
            alignment='center',
            horizontal_alignment='center',
            spacing=9,
            # tight = True,
            # width=400,
            scale=0.5,
            )
        else:
            return Column([self.nome,  self.sw]
            ,
            alignment='center',
            horizontal_alignment='center',
            spacing=9,
            # tight = True,
            # width=400,
            scale=0.5,
            )
        

    def Exibir_atributos(self, objeto):
        for i in objeto.__dict__.keys():
            print(i) 
    def change_botao(self,e):
        self.value =  self.sw.value
        super().update()
