
from flet import*
from time import sleep, time
from winsound import MessageBeep, MB_ICONHAND
from funcoes_leo.funcoes import Data, Thread
from contador_flet import Contador




class Compassos(UserControl):
    def __init__(self,
        inicio = 100,
        meta = 170,
        passo_set = 0,
        passo_fim = 0,
        tipo_compasso = 4,
        qtd_compassos = 1,
        bpm_atual = 100,
        inverter = False,

    
    ):
        
        '''
            para desativar o modo progressivo, anule self.inicio_set ou self.meta_set
            defina pelo menos dois dos parãmetros "duracao", "passo_set", "intervalo" e o programa caluculará o que está nulo
            
        
            
        '''
        super().__init__()
        self.continuar_treinando = False
        self.intervalo = None
        self.inverter_set = inverter
        self.progressivo = True
        self.meta_set = meta
        self.inicio_set = inicio
        self.passo_set = passo_set
        self.passo_fim_set = passo_fim
        self.new_bpm = bpm_atual
        self.qtd_compassos = int(qtd_compassos)
        self.tipo_compasso = int(tipo_compasso)
        self.pause_compassos = False
        self.parar_compassos = False
        # self.Calcular()
        self.Iniciar_contantes()
        self.Duracao_total()
        # self.tempo_restante = float(self.t_total) + self.intervalo


        self.quado_saida = Row([Text(),Text(),])
        self.saida_treinamento = Row(visible=False, alignment='start')


    @property
    def Parar(self):
        return self.parar_compassos
    
    @Parar.setter
    def Parar(self, valor: bool):
        self.parar_compassos = valor
        self.update()


    @property
    def Pause(self):
        return self.pause_compassos
    
    @Pause.setter
    def Pause(self, valor: bool):
        self.pause_compassos = valor
        self.update()


    def did_mount(self):
        Thread(target=self.Treinamento_compassos, daemon=False).start()
        # Thread(target=self.Timer, daemon=False).start()
        # self.Treinamento()

    def build(self):
        return Column([self.saida_treinamento, self.quado_saida])
   
    def Timer(self):
        # t = Contador(self.t_total)
        self.quado_saida.visible = True
        while self.tempo_restante >= 0:
            horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(self.tempo_restante)
            self.quado_saida.controls = [Text(f"Tempo restante: {horas2}:{minutos2}:{segundos2}", color  = 'green', size = 20)]
            super().update()
            self.tempo_restante += -1
            sleep(1)
        
    def Calcular(self):
        if self.meta_set == 0 or self.inicio_set == 0:
            self.progressivo = False
        elif self.t_total == 0 and self.passo_set != 0 and self.intervalo != 0:
            self.t_total = int(((self.meta_set - self.inicio_set)/self.passo_set)*self.intervalo)
        elif self.t_total != 0 and self.passo_set != 0 and self.intervalo == 0:
            self.intervalo = int(self.passo_set*self.t_total/(self.meta_set - self.inicio_set))
        elif self.t_total != 0 and self.passo_set == 0 and self.intervalo != 0:
            self.passo_set = int(((self.meta_set - self.inicio_set)/self.t_total)*self.intervalo)
        else:
            self.tempo_restante = 0
            self.t_total = 0
            self.intervalo = 0


    def Duracao_total2(self):
        t = 0
        for i in range(self.inicio_set, self.meta_set,self.passo_set):
            t += 60*self.qtd_compassos*self.tipo_compasso/i
        self.duracao_total = t

    def Duracao_total(self):
        t = 0
        i = self.inicio_set
        ii = 0
        valor_passo = self.passo_set
        while i <= self.meta_set:   
            t += 60*self.qtd_compassos*self.tipo_compasso/i
            ii = self.Variador_de_passo(i, ii)  
            i +=  self.passo_set      

        self.duracao_total = t   
        self.passo_set = valor_passo     

    def Duracao_compassos(self):
        return 60*self.qtd_compassos*self.tipo_compasso/self.new_bpm
    
    def Exibir_tempo_restante(self):
        self.contar = Contador(self.duracao_total, 'white', 15)
        self.quado_saida.controls = [Row([Text('Tempo restante'),self.contar]), Text()]
        super().update() 

    def Treinamento_compassos(self):
        self.quado_saida.visible = True
        # self.saida_respiro.visible = False
        self.saida_treinamento.visible = True
        horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(self.duracao_total)
        if self.passo_fim_set == 0:
            pp = f'{self.passo_set}'  
        else:
            pp = f'{self.passo_set} a {self.passo_fim_set}'
        self.saida_treinamento.controls = [Text(f'[Início: {self.inicio_set} bpm] -  [Meta: {self.meta_set} bpm] - [Passo: {pp}] - [compasso: {self.tipo_compasso}/4] - [qtd. compassos: {self.qtd_compassos}] - \n[Duração total: {horas2}:{minutos2}:{segundos2}]')]     
        Thread(target=self.Exibir_tempo_restante, daemon=False).start()

        super().update()

        if self.inverter_set:
            self.passo_set = -1*self.passo_set
            self.new_bpm = self.meta_set - self.passo_set
        else:
            self.new_bpm = self.inicio_set - self.passo_set

        ii = 0
        while self.new_bpm > self.inicio_set if self.inverter_set else self.new_bpm < self.meta_set:
            # teste = self.new_bpm > self.inicio_set if self.inverter_set else self.new_bpm < self.meta_set
            self.new_bpm += self.passo_set
            self.quado_saida.controls[1] = Text(f'Andamento atual: {self.new_bpm:.1f} bpm', color = 'green', size  = 20)
            super().update()
            ii = self.Variador_de_passo(self.new_bpm, ii)

            # Para caso o de o botão pause ser pressionado
            while self.pause_compassos:
                self.contar.Pause = True
                sleep(0.1)
            self.contar.Pause = False


            sleep(self.Duracao_compassos())
            # Para caso o de o botão Stop ser pressionado
            if self.parar_compassos:
                break

        # para quando a bpm passa da meta
        if not self.parar_compassos:
            if self.new_bpm > self.meta_set if self.inverter_set else self.new_bpm < self.meta_set:
                self.new_bpm = self.meta_set
                self.quado_saida.controls[1] = Text(f'({self.new_bpm} bpm)')
                super().update()

            if self.new_bpm == self.meta_set:
                MessageBeep(MB_ICONHAND)


        # self.quado_saida.controls = [Text('Treino Finalizado...')]
        self.Testar_continuidade()
        super().update()


    def Exibir_tempo_restante2(self):
        # self.saida_treinamento.visible = True
        horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(self.tempo_restante)
        self.saida_treinamento.controls[0] = Text(f"Tempo restante: {horas2}:{minutos2}:{segundos2}", color  = 'green', size = 20)
        super().update()

    def converter_segundos_para_horas_min_segundos(self, segundos):
        def Algarismos(numero, qtd=2):
            numero = int(numero)
            return str(numero).zfill(qtd)
        horas = segundos // 3600  # 3600 segundos em uma hora
        horas = Algarismos(horas)
        segundos %= 3600
        minutos = segundos // 60  # 60 segundos em um minuto
        minutos = Algarismos(minutos)
        segundos %= 60
        segundos = Algarismos(segundos)

        return horas, minutos, segundos   

    def Iniciar_contantes(self):
        if self.inverter_set:
            self.passo_fim_set = 0

        distancia_bpm = self.meta_set - self.inicio_set
        self.dist_passo = self.passo_set - self.passo_fim_set if self.passo_fim_set != 0 else 0
        self.constante_de_tempo = ((self.meta_set - self.inicio_set)*self.Duracao_compassos())
        self.x = [0.25, 0.5, 0.75, 0.9, 1]
        self.incrementos = [y*distancia_bpm +  self.inicio_set for y in self.x]

    def Variador_de_passo(self, bpm, ii):
        if self.dist_passo != 0:
            if ii >= 3:
                if bpm >= self.incrementos[ii]:
                    self.passo_set = self.passo_fim_set
                    self.tempo_restante = int(self.constante_de_tempo/self.passo_set)
                    print(f'passou dos {self.x[ii]*100}% da meta')

            elif bpm >= self.incrementos[ii] and bpm < self.incrementos[ii+1]:
                self.passo_set = self.passo_fim_set + \
                    (1-self.x[ii])*self.dist_passo
                self.tempo_restante = int(
                    ((self.meta_set - bpm)*self.Duracao_compassos())/self.passo_set)
                print(f'passou dos {self.x[ii]*100}% da meta')
                ii += 1
        return ii  

    def Testar_continuidade(self):
        if self.continuar_treinando == False:
            self.parar_compassos = True
            self.saida_treinamento.visible = False
            # self.saida_treinamento.controls = None
            self.quado_saida.visible = False
            # self.quado_saida.controls = None
        super().update()



def main_test(page: Page):
    page.title = "Teste"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750


    c = Compassos(80,85, 1,0.5, inverter= True)
    c.continuar_treinando = True
    # c.inverter_set = True


    page.add(c)
    page.update()



if __name__ == '__main__':
    app(target=main_test)            
