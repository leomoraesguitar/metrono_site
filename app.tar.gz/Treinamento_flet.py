
from flet import*
from time import sleep, time
from winsound import MessageBeep, MB_ICONHAND
from funcoes_leo.funcoes import Data, Thread
from contador_flet import Contador




class Treinamento(UserControl):
    def __init__(self,
        duracao = 0,
        inicio = 100,
        meta = 170,
        passo_set = 0,
        intervalo = 0,
        passo_fim = 0,
        bpm_atual = 100,
        inverter = False,
        page = '',

    
    ):
        
        '''
            para desativar o modo progressivo, anule self.inicio_set ou self.meta_set.
            Defina pelo menos dois dos parãmetros "duracao", "passo_set", "intervalo" e o programa calculará o parâmentro que está nulo
            
        
            
        '''
        super().__init__()
        self.page = page
        self.t_total = duracao
        self.continuar_treinando = False
        self.intervalo = intervalo
        self.inverter_set = inverter
        self.progressivo = True
        self.meta_set = meta
        self.inicio_set = inicio
        self.passo_set = passo_set
        self.passo_fim_set = passo_fim
        self.new_bpm = bpm_atual
        self.pause_treinamento = False
        self.parar_treinamento = False
        self.Calcular()
        self.Iniciar_contantes()
        self.tempo_restante = float(self.t_total) #+ self.intervalo


        self.quado_saida = Row()
        self.saida_treinamento = Column(visible=False)


    @property
    def Pause(self):
        return self.pause_treinamento
    @Pause.setter
    def Pause(self, valor:bool):
        self.pause_treinamento = valor
        self.update()
    @property
    def Parar(self):
        return self.parar_treinamento
    @Parar.setter
    def Parar(self, valor:bool):
        self.parar_treinamento = valor
        # self.update()        



    def did_mount(self):
        print('did_mount')
        # self.page.update
        Thread(target=self.Treinamento, daemon=False).start()
        # Thread(target=self.Timer, daemon=False).start()
    #     # self.Treinamento()
    # def will_unmount(self):
    #     print('will_unmount')
    #     self.running = False
        # return super().will_unmount()

    def build(self):
        print('build')
        return Column([self.saida_treinamento,self.quado_saida])  
   
    def Timer(self):
        # t = Contador(self.t_total)
        self.quado_saida.visible = True
        while self.tempo_restante >= 0:
            horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(self.tempo_restante)
            self.quado_saida.controls[0] = Text(f"Tempo restante: {horas2}:{minutos2}:{segundos2}", color  = 'green', size = 20)
            self.update()
            self.tempo_restante += -1
            while self.pause_treinamento:
                sleep(0.1)            
            sleep(1)
        
    def Calcular(self):
        if self.meta_set == 0 or self.inicio_set == 0:
            self.progressivo = False
        elif self.t_total == 0 and self.passo_set != 0 and self.intervalo != 0:
            self.t_total = int(((self.meta_set - self.inicio_set)/self.passo_set)*self.intervalo)
        elif self.t_total != 0 and self.passo_set != 0 and self.intervalo == 0:
            self.intervalo = int(self.passo_set*self.t_total/(self.meta_set - self.inicio_set))
        elif self.t_total != 0 and self.passo_set == 0 and self.intervalo != 0:
            self.passo_set = int(((self.meta_set - self.inicio_set)/self.t_total)*self.intervalo)
        else:
            self.tempo_restante = 0
            self.t_total = 0
            self.intervalo = 0

    def Textar_inversao(self):
        if self.inverter_set:
            self.passo_set = -1*self.passo_set
            self.new_bpm = self.meta_set - self.passo_set
        else:
            self.new_bpm = self.inicio_set - self.passo_set

    def Treinamento(self, tarefa_exec=''):
        self.quado_saida.visible = True
        # self.saida_respiro.visible = False
        self.saida_treinamento.visible = True
        horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(self.t_total)
        if self.passo_fim_set == 0:
            pp = f'{self.passo_set}'  
        else:
            pp = f'{self.passo_set} a {self.passo_fim_set}'
        self.saida_treinamento.controls = [Text(f'[Duração: {horas2}:{minutos2}:{segundos2}] - [Início: {self.inicio_set} bpm] -  [Meta: {self.meta_set} bpm] - [Passo: {pp}]  - [Intervalo: {self.intervalo} s]')]
        self.quado_saida.controls = [Text(), Text()]
        super().update()
        # print('Treino iniciado...')
        # print(f'tarefa_exec = {tarefa_exec}')

        # print(f'dist_passo = {dist_passo} \npasso = {self.passo} \nbpm = {bpm}\n')
        # def Finalizacao_treino():
            # self.saida_treinamento.controls = [Text('Treino Finalizado...')]
            # self.Piscar_infos
            # self.EscreveTxt(tarefa_exec)
            # self.EscrevePlanilha(tarefa_exec)
            # self.quado_saida.controls = None

        ii = 0
        
        # self.new_bpm = self.inicio_set

        self.Textar_inversao()

        if self.tempo_restante == 0 and self.t_total == 0 and self.intervalo == 0:
            self.saida_treinamento.controls = [Text('Apenas um dos parãmetros "duracao", "passo_set" e "intervalo" pode ser nulo')]
        if tarefa_exec == '':
            tarefa_exec = f'{Data()} .-. {"sem nome"} .-. {round(self.tempo_restante/60,1)}min .-. BPM({self.inicio_set} a  ) .-. passo:   .-. intervalo:  s'

        if self.progressivo:
            Thread(target=self.Timer, daemon=False).start()
            while self.new_bpm > self.inicio_set if self.inverter_set else self.new_bpm < self.meta_set:
                # self.Exibir_tempo_restante()

                self.new_bpm += self.passo_set
                self.quado_saida.controls[1] = Text(f'Andamento atual: {self.new_bpm:.1f} bpm', size = 18)
                super().update()

                sleep(self.intervalo)
                # self.tempo_restante -= self.intervalo

                ii = self.Variador_de_passo(self.new_bpm, ii)
                try:
                    self.update()
                except:
                    pass    


                # Para caso o de o botão pause ser pressionado
                while self.pause_treinamento:
                    sleep(0.1)

                # Para caso o de o botão Stop ser pressionado
                if self.parar_treinamento or self.tempo_restante <= 0:
                    break

            # para quando a bpm passa da meta
            if self.new_bpm < self.meta_set if self.inverter_set else self.new_bpm > self.meta_set:
                self.new_bpm = self.meta_set
                self.quado_saida.controls[1] = Text(f'Andamento atual: {self.new_bpm:.1f} bpm', size = 18)
                super().update()


            if self.new_bpm == self.meta_set or self.tempo_restante == 0:
                sleep(5)
                MessageBeep(MB_ICONHAND)

        else:
            while self.tempo_restante >= 0:
                self.Exibir_tempo_restante()
                sleep(1)
                self.tempo_restante -= 1
                while self.pause_treinamento:
                    sleep(0.1)
                if self.parar_treinamento or self.tempo_restante <= 0:
                    break

            if self.tempo_restante == 0:
                MessageBeep(MB_ICONHAND)

        # Thread(target=Finalizacao_treino, daemon=True).start()
        self.saida_treinamento.controls = [Text('Treino Finalizado...')]
        self.Testar_continuidade()
        super().update()
    
    def Exibir_tempo_restante(self):
        # self.saida_treinamento.visible = True
        horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(self.tempo_restante)
        self.saida_treinamento.controls[0] = Text(f"Tempo restante: {horas2}:{minutos2}:{segundos2}", color  = 'green', size = 20)
        super().update()
    @classmethod
    def converter_segundos_para_horas_min_segundos(self, segundos):
        def Algarismos(numero, qtd=2):
            numero = int(numero)
            return str(numero).zfill(qtd)
        horas = segundos // 3600  # 3600 segundos em uma hora
        horas = Algarismos(horas)
        segundos %= 3600
        minutos = segundos // 60  # 60 segundos em um minuto
        minutos = Algarismos(minutos)
        segundos %= 60
        segundos = Algarismos(segundos)

        return horas, minutos, segundos   

    def Iniciar_contantes(self):
        if self.inverter_set:
            self.passo_fim_set = 0

        distancia_bpm = self.meta_set - self.inicio_set
        self.dist_passo = self.passo_set - self.passo_fim_set if self.passo_fim_set != 0 else 0
        self.constante_de_tempo = ((self.meta_set - self.inicio_set)*self.intervalo)
        self.x = [0.25, 0.5, 0.75, 0.9, 1]
        self.incrementos = [y*distancia_bpm +  self.inicio_set for y in self.x]

    def Variador_de_passo(self, bpm, ii):
        if self.dist_passo != 0:
            if ii >= 3:
                if bpm >= self.incrementos[ii]:
                    self.passo_set = self.passo_fim_set
                    self.tempo_restante = int(self.constante_de_tempo/self.passo_set)
                    print(f'passou dos {self.x[ii]*100}% da meta')

            elif bpm >= self.incrementos[ii] and bpm < self.incrementos[ii+1]:
                self.passo_set = self.passo_fim_set + \
                    (1-self.x[ii])*self.dist_passo
                self.tempo_restante = int(
                    ((self.meta_set - bpm)*self.intervalo)/self.passo_set)
                print(f'passou dos {self.x[ii]*100}% da meta')
                ii += 1
        return ii  

    def Testar_continuidade(self):
        # if self.continuar_treinando == False:
        self.parar_treinamento = True
        self.saida_treinamento.visible = False
        # self.saida_treinamento.controls = None
        self.quado_saida.visible = False
        # self.quado_saida.controls = None




def main_test(page: Page):
    page.title = "Teste"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750


    t = Treinamento(20,80,120, intervalo = 5, passo_fim = 1, inverter=True)
    t.continuar_treinando = True

    page.add(t)
    page.update()



if __name__ == '__main__':
    app(target=main_test)            
