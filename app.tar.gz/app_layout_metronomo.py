# from board import Board
# from data_store import DataStore
from flet import (
    ButtonStyle,
    Column,
    Container,
    Control,
    IconButton,
    Page,
    PopupMenuButton,
    PopupMenuItem,
    RoundedRectangleBorder,
    Row,
    Text,
    TextButton,
    TextField,
    InputBorder,
    border,
    border_radius,
    colors,
    MainAxisAlignment,
    icons,
    padding,
    Tabs,
    Tab,
    Checkbox,
    Dropdown,
    Column,
    Container,
    Slider,
    FloatingActionButton,
    NavigationRail,
    NavigationRailDestination,
    IconButton,
    Page,
    Row,
    Tab,
    Tabs,
    Text,
    TextField,
    UserControl,
    colors,
    icons,
    padding,
    margin,    
    alignment,    
    border_radius, 
    dropdown,
    CrossAxisAlignment,
    ScrollMode,
    
)
from sidebar import Sidebar
from controlador_metronomo import Metronomo_Control, Thread, Escrever_json, Ler_json, Juntar
from time import sleep
#é na verdade uma classe filha ed Row
class AppLayout(Row):
    def __init__(self, Salvar_cofig, tabs_changed, add_clicked,tasks):
        super().__init__()
        self.Largura_tela_central = 800
        self.alignment = MainAxisAlignment.START
        self.width = 50
        self.expand = 0
        self.tasks = tasks
        self.add_clicked = add_clicked
        self.Salvar_cofig = Salvar_cofig
        self.tabs_changed = tabs_changed
        self.new_task = TextField(hint_text="Nome da tarefa", 
                                        color = colors.BLUE, 
                                        border = InputBorder.OUTLINE, 
                                        border_width = 5, 
                                        border_radius = 5,
                                        expand=True, max_length = 55)
        self.barra_lateral =  Sidebar(self.Salvar_cofig)
        self.filter = Tabs(
            selected_index=0,
            on_change=self.tabs_changed,
            tabs=[Tab(text="Todos"), Tab(text="Ativos"), Tab(text="Concluídos")],
        )
        self.continuar = Checkbox(label = 'Continuar')
        self.pomodoro_ativar = Checkbox(label = 'Pomodoro:')
        self.pomodoro = Dropdown(options=[dropdown.Option(i) for i in range(1,30,1)], width = 55, value = 3)
        self.descanso = Dropdown(options=[dropdown.Option(i) for i in range(1,30,1)], width = 150, value = 1, prefix_text = 'Descanso:  ')
        self.Linha_pomodoro = Row([self.continuar,self.pomodoro_ativar,self.pomodoro,self.descanso ])
        self.saida_tempo_de_treino = Row([Text()])
        self.saida_tempo_pomodoro = Row([Text()])
        self.saida_tempo_restante = Row([Text()])
        self.saida_respiracao = Row([Text()])
        self.saida_TEXT = Row([Text()])
        self.saida = Column(
            width=self.Largura_tela_central,
            controls=[self.saida_tempo_de_treino,
                      self.saida_tempo_pomodoro,
                      self.saida_tempo_restante,
                      self.saida_respiracao,
                      self.saida_TEXT                      
                      ],                
                            
        )
        self.bpm_display = Text()
        self.Tela_tarefas =Column(
            width=self.Largura_tela_central,
            expand = 0,
            alignment = MainAxisAlignment.START,
            spacing=-5,
            # tight = 1,
            controls=[
                Row(vertical_alignment = CrossAxisAlignment.START,
                    controls=[                        
                        self.new_task,
                        FloatingActionButton(icon=icons.ADD, on_click=self.add_clicked),       
                    ],                    
                ),
                self.bpm_display,
                self.Linha_pomodoro,
                self.saida,
                self.filter,
                Column(
                    spacing=0,
                    height = self.Largura_tela_central,
                    alignment = MainAxisAlignment.START,
                    # auto_scroll = True,
                    scroll = ScrollMode.ADAPTIVE,
                    controls=[                        
                        self.tasks,
                    ],
                ),
            ],
        )
                #controles da linha (incluse a ordem)
        self.controls = [
            # self.barra_lateral, 
                        self.Tela_tarefas
                            ]
