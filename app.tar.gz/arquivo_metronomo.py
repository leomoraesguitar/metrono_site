# import os
# import json
# from datetime import datetime
# import PySimpleGUI as sg
from funcoes_leo.funcoes import Data, Juntar, Escrever_json, Ler_json, os, Thread, SalvarPickle


# def Data():
#     current_time = datetime.now()
#     formatted_time = current_time.strftime('%d-%m-%Y-%H:%M:%S')
#     return formatted_time

# def Juntar(a, b):
#         return os.path.join(a, b)

def ListExportTarefas(qtd_tarefas):
    lt = []
    for i in range(qtd_tarefas):
        lt.extend([f'-TR-{i}-', f'-DR-{i}-', f'-BPMI-{i}-',
                  f'-BPMF-{i}-', f'-PASSO-{i}-'])
    return lt


# def Escrever_json(nomedodicionario, nomedoarquivo):
#     if nomedoarquivo[-4:] != 'json':
#         nomedoarquivo = nomedoarquivo+'.json'
#     with open(nomedoarquivo, 'w') as f2:
#         json.dump(nomedodicionario, f2, indent=4)

# def Ler_json(nomedoarquivo):  # retorna um dicionário
#     if nomedoarquivo[-4:] != 'json':
#         nomedoarquivo = nomedoarquivo+'.json'
#     with open(nomedoarquivo, 'r') as f2:
#         try:
#             a = json.load(f2)
#             return a
#         except json.JSONDecodeError as e:
#             print(f"Erro ao decodificar JSON: {e}")
#             return {}

# config = Juntar(os.getcwd(),r'config_metronomo.json')
config = 'config_metronomo.json'
try:
    nome_da_credencial = 'client_secret.json'
except:
    print(f'O arquivo "client_secret.json" não foi encontrado')  


def Arquivo():
    try:
        # if os.path.exists(config):
        # variável que armazena as informações do arquivo json
        # print('existe')
        arquiv = Ler_json(config)
        # a = 1//0
        inicializar = False
        print('leu o arquivo json')
    except:
        print('Não leu o arquivo json')

        arquiv = {}  
        Escrever_json(arquiv, config)
        inicializar = True
    return inicializar, arquiv, config


if __name__ == "__main__":
    # print(Arquivo())
    pass
    # print(nome_da_credencial)
