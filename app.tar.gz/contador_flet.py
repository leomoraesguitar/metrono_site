
from flet import*
from time import sleep
# from winsound import MessageBeep, MB_ICONHAND
# from funcoes_leo.funcoes import Data


class Contador(UserControl):
    def __init__(self, 
                 segundos = 10,
                 cor = 'green',
                 size = 20

    ):
        super().__init__()
        self.segundos = segundos
        self.cor = cor
        self.size = size
        self.saida = Row(visible=False)
        self.pause_contador = False
    


    @property
    def Pause(self):
        return self.pause_contador
    
    @Pause.setter
    def Pause(self, valor: bool):
        self.pause_contador = valor
        self.update()

    def did_mount(self):
        self.Cont()

    def build(self):
        return self.saida


    def Cont(self):
        self.saida.visible = True
        while self.segundos >= 0:
            horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(self.segundos)
            self.saida.controls = [Text(f"{horas2}:{minutos2}:{segundos2}", color  = self.cor, size = self.size)]
            super().update()
            self.segundos += -1
            sleep(1)
            while self.pause_contador:
                sleep(0.1)
        self.saida.visible = False
        # super().update()




    def converter_segundos_para_horas_min_segundos(self, segundos):
        def Algarismos(numero, qtd=2):
            numero = int(numero)
            return str(numero).zfill(qtd)
        horas = segundos // 3600  # 3600 segundos em uma hora
        horas = Algarismos(horas)
        segundos %= 3600
        minutos = segundos // 60  # 60 segundos em um minuto
        minutos = Algarismos(minutos)
        segundos %= 60
        segundos = Algarismos(segundos)

        return horas, minutos, segundos
    



    
def main_test(page: Page):
    page.title = "Teste"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750


    c = Contador()

    page.add(c)
    page.update()



if __name__ == '__main__':
    app(target=main_test)            
