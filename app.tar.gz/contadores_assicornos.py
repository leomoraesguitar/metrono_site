import asyncio
import flet as ft

class Countdown(ft.UserControl):
    def __init__(self, minutos, texto = ''):
        super().__init__()
        self.minutos = minutos
        self.segundos = 60*minutos
        self.texto = texto

    async def did_mount_async(self):
        self.running = True
        asyncio.create_task(self.update_timer())

    async def will_unmount_async(self):
        self.running = False

    async def update_timer(self):
        while self.segundos and self.running:
            h, mins = divmod(self.segundos, 60*60)
            mins, secs = divmod(mins, 60)
            if self.texto != '':
                self.countdown.value = "{:s} {:02d}:{:02d}:{:02d}".format(self.texto,h, mins, secs)
            else:
                self.countdown.value = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)

            await self.update_async()
            await asyncio.sleep(1)
            self.segundos -= 1

    def build(self):
        self.countdown = ft.Text()
        return self.countdown

async def main(page: ft.Page):
    await page.add_async(Countdown(40, 'Volte a treinar por '))

ft.app(target=main)