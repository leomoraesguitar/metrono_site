import flet
from flet import (
    Checkbox,
    Dropdown,
    Column,
    Container,
    Slider,
    FloatingActionButton,
    NavigationRail,
    NavigationRailDestination,
    IconButton,
    Page,
    Row,
    Tab,
    Tabs,
    Text,
    TextField,
    UserControl,
    colors,
    icons,
    padding,
    margin,    
    alignment,    
    border_radius,    
)

from os import environ

from time import sleep, time
from winsound import MessageBeep, MB_ICONHAND

# import keyboard as kb
from arquivo_metronomo import nome_da_credencial, Thread, Data, Escrever_json, Ler_json
from re import search
# from googlesheets import AtualizarCelulas, LerCelulas
from googlesheets_leo import AtualizarCelulas, LerCelulas

# from controlador_metronomo import Metronomo_Control
from metronomo import Metronomo
from layout2 import Layout as lt
from os import environ
environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'
from saidas import Saidas


# from logs import lg
__docformat__ = "restructuredtext"


class Metronomo_Control_flet(Metronomo):
    def __init__(self):
        super().__init__()


        # UserControl().__init__()

    #     # self.update = update
        self.saida = Column()
        self.display = {}
        self.metronomo_inciado = False
        self.pomodoro_habilitado = False
        self.pausar_pomodoro = False
        self.treino_habilitado = False
        self.treinando = False
        # self.pause = False
        self.continuar = False
        self.tf = None
        self.ti = None
        self.iniciar_medicao_bpm = False
        self.nome_planilha = lt().DefaultValores('nome_planilha')

        # self.b = 0
        # self.v = False
        # self.window = window
        self.inverter = False
        self.meta = None
        self.inicio = None
        self.passo = None
        self.passo_fim = None
        self.tempo = None
        self.intervalo = None
        self.t_total = None
        self.event = None
        self.n_treino = None
        self.nome_treino = None
        self.progressivo = True
        self.tipo_de_treino = None
        self.play_tarefas = False
        self.tarefa_play = None
        self.tarefa_pause = None
        self.tempo_pomodoro = None
        self.tempo_descanso = None
        self.tempo_compasso = None
        self.bpm_atual = 120
        self.parar = False  
        self.contando = False      
    

    def Exibir(self, tempo_de_treino = 'testando...',
                        tempo_pomodoro = 'tempo_pomodoro' ,
                        contagem = 'contagem',
                        tempo_restante = 'tempo_restante',
                        respiracao = 'respiracao',
                        TEXT = 'TEXT'):
        saida = Saidas(tempo_de_treino = tempo_de_treino,
                        tempo_pomodoro = tempo_pomodoro,
                        contagem = contagem,
                        tempo_restante = tempo_restante,
                        respiracao = respiracao,
                        TEXT = TEXT )
        self.saida.controls = [saida]
        # 'self.update()

    @property
    def Pausar(self):
        self.pause = not self.pause


    def ModificarBPM(self, bpm):
        # bpm+=1
        if bpm <= 1:
            bpm = 1

        self.setBpm = bpm
        self.Atualizar(True)

 
        # treinamento
    @classmethod
    def converter_segundos_para_horas_min_segundos(self, segundos):
        def Algarismos(numero, qtd=2):
            numero = int(numero)
            return str(numero).zfill(qtd)
        horas = segundos // 3600  # 3600 segundos em uma hora
        horas = Algarismos(horas)
        segundos %= 3600
        minutos = segundos // 60  # 60 segundos em um minuto
        minutos = Algarismos(minutos)
        segundos %= 60
        segundos = Algarismos(segundos)

        return horas, minutos, segundos

    @classmethod
    def EscreveTxt(self, texto):
        try:
            with open(self.nometarefastxt, 'a') as arq:
                arq.write(f'{texto}\n')
        except:
            with open(self.nometarefastxt, 'w') as arq:
                arq.write(f'{texto}\n')
        print(f'A tarefa foi salva em {self.nometarefastxt}')

    def EscrevePlanilha(self, texto):
        # texto = f'11-10-2023-14:56:53 .-. Estágio 3 .-. 5min .-. BPM(140 a 150) .-. passo: 0.1 .-. intervalo: 3.0s'
        # print(texto)
        b = texto.split(' .-. ')
        d, m, y = b[0].split('-')[:3]
        h = b[0].split('-')[3]
        data = f'{d}/{m}/{y} {h}'
        nome = b[1]
        duracao = b[2][:-3]

        # if self.progressivo:    # or nome == 'sem nome'
        try:
            resultado = search(r'BPM\((\d+) a (\d+)\)', b[3])
            print(f'resultado = {resultado}')
            bpm_in = resultado.group(1)
            bpm_fim = resultado.group(2)
            passo = b[4][7:]
            intervalo = b[5][10:-1]
        except:
            resultado = search(r'BPM\((\d+(\.\d+)?) a', b[3])
            print(f'resultado = {resultado}')
            bpm_in = resultado.group(1).split('.')[0]
            bpm_fim = ''
            passo = ''
            intervalo = ''

        valores = [[data, nome, duracao, bpm_in, bpm_fim, passo, intervalo]]

        n_linhas = 1+len(p := LerCelulas(self.nome_planilha,
                         'metronomo!A:h', nome_da_credencial))
        AtualizarCelulas(
            self.nome_planilha, f'metronomo!A{n_linhas}:h', valores, nome_da_credencial)

    @property
    def Treinar(self):
        # self.window = window
        self.inicio = float(self.inicio)
        if self.progressivo:
            self.meta = float(self.meta)
            self.passo = float(self.passo)

            if not self.tempo:
                self.tempo_de_treino = int(
                    ((self.meta - self.inicio)/self.passo)*self.intervalo)
                self.t_total = self.tempo_de_treino
                horas, minutos, segundos = self.converter_segundos_para_horas_min_segundos(
                    self.tempo_de_treino)
                # self.window['-tempo_de_treino-'].update(
                #     f"Duração do treino: {horas}:{minutos}:{segundos}")

            else:
                # self.t_total = self.intervalo*60
                self.intervalo = round(
                    (self.t_total*self.passo)/(self.meta - self.inicio), 3)
                # print(f'tempo intervalo = {self.intervalo}')
                horas, minutos, segundos = self.converter_segundos_para_horas_min_segundos(
                    self.t_total)
                # self.window['-tempo_de_treino-'].update(
                #     f"Duração do treino: {horas}:{minutos}:{segundos}     Intervalo: {self.intervalo} segundos")

            if self.inverter:
                self.setBpm = self.meta
                # self.window['-bpm-'].update(self.meta)

                self.meta2 = self.inicio
                self.passo = -1*self.passo

            else:
                self.setBpm = self.inicio
                # self.window['-bpm-'].update(self.inicio)
                self.meta2 = self.meta

            # self.tempo_restante = float(self.t_total) + float(self.intervalo)

            if not self.inverter and self.passo_fim not in [0, '', None]:
                distancia_bpm = self.meta - self.inicio
                self.dist_passo = self.passo - self.passo_fim
                self.constante_de_tempo = (
                    (self.meta - self.inicio)*self.intervalo)
                self.x = [0.25, 0.5, 0.75, 0.9, 1]
                self.incrementos = [y*distancia_bpm +
                                    self.inicio for y in self.x]
                ii = 0

            else:
                self.dist_passo = 0

        else:
            self.setBpm(self.inicio)
            self.window['-bpm-'].update(self.inicio)

    @property
    def Restaurar_cores(self):
        self.window['Pause'].update(
            button_color=lt().Default_cor('cor_de_fundo_botoes'))
        if self.tipo_de_treino == 'tarefas':
            self.window[self.tarefa_play].update(button_color='#5f6766')
            self.window[self.tarefa_pause].update(button_color='#5f6766')

    @property
    def Limpar_saida(self):
        for hh in ['-tempo_de_treino-', '-contagem-', '-tempo_pomodoro-', '-tempo_restante-', '-TEXT-']:
            self.window[hh].update("")

    @property
    def Testar_continuidade(self):
        if self.continuar == False and not self.play_tarefas:
            self.pomodoro_habilitado = False
            self.treinando = False
            self.setOn = False
            self.Limpar_saida
        elif self.play_tarefas:
            # self.pomodoro_habilitado = False
            self.treinando = False
            self.setOn = False
        self.Restaurar_cores
        self.metronomo_inciado = False

    @property
    def Exibir_tempo_restante(self):
        horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(
            self.tempo_restante)
        # self.window['-tempo_restante-'].update(
        #     f"Tempo restante: {horas2}:{minutos2}:{segundos2}")

    @property
    def Piscar_infos(self):
        # fazer o nome ficar pisacando na tela
        for i in range(4):
            self.window['-tempo_restante-'].update(text_color='#ffff80')
            sleep(0.2)
            self.window['-tempo_restante-'].update(text_color='red')
            sleep(0.2)
        self.window['-tempo_restante-'].update(text_color='#4ab580')
        # if self.tipo_de_treino == 'tarefas':
        #     self.window[self.event].update(button_color='#5f6766')

    def Variador_de_passo(self, bpm, ii):
        if self.dist_passo != 0:
            if ii >= 3:
                if bpm >= self.incrementos[ii]:
                    self.passo = self.passo_fim
                    self.tempo_restante = int(
                        self.constante_de_tempo/self.passo)
                    print(f'passou dos {self.x[ii]*100}% da meta')

            elif bpm >= self.incrementos[ii] and bpm < self.incrementos[ii+1]:
                self.passo = self.passo_fim + \
                    (1-self.x[ii])*self.dist_passo
                self.tempo_restante = int(
                    ((self.meta - bpm)*self.intervalo)/self.passo)
                print(f'passou dos {self.x[ii]*100}% da meta')
                ii += 1
        return ii

    def Limpar(self, key):
        self.window[key].update('')

    def Executar_tarefas(self, tarefas_dic):
        lista_tarefas_play = tarefas_dic['lista_tarefas_play']
        lista_tarefas_pause = tarefas_dic['lista_tarefas_pause']
        self.play_tarefas = True
        self.parar = False
        if self.pomodoro_habilitado:
            Thread(target=self.Pomodoro, daemon=True).start()

        for j, i in enumerate(lista_tarefas_play):
            print(f'tarefa {i[6:]} iniciada...')

            self.setOn = True

            for i3, i33 in zip(lista_tarefas_play, lista_tarefas_pause):
                self.window[i3].update(button_color='#5f6766')
                self.window[i33].update(button_color='#5f6766')

            self.event = i
            self.tipo_de_treino = 'tarefas'
            self.play_tarefas = True
            self.tarefa_play = i
            self.tarefa_pause = f'-pause-{i[6:]}'
            self.treinando = True
            self.treino_habilitado = True

            self.t_total = tarefas_dic['t_total'][j]
            self.passo = tarefas_dic['passo'][j]
            self.meta = tarefas_dic['meta'][j]
            self.inicio = tarefas_dic['inicio'][j]
            self.nome_treino = tarefas_dic['nome_treino'][j]
            self.progressivo = tarefas_dic['progressivo'][j]

            intervalo_bpm = round(
                (float(self.t_total)*float(self.passo))/(float(self.meta) - float(self.inicio)), 3)
            tarefa_exec = f'{Data()} .-. {self.nome_treino} .-. {self.t_total}min .-. BPM({self.inicio} a {self.meta}) .-. passo: {self.passo} .-. intervalo: {intervalo_bpm}s'
            self.Treinar
            self.Ini_Thread('beep')
            self.window[i].update(button_color='red')

            self.Treinamento(tarefa_exec)

            if self.parar:
                break

            # horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(
            #     self.tempo_descanso*60)
            # self.window['-tempo_de_treino-'].update(
            #     f'Faça uma pausa de {horas2}:{minutos2}:{segundos2}')

            # self.contando = True
            # Thread(target=self.Barra_de_progresso, daemon=True).start()
            # self.Contagem2(self.tempo_descanso*60)
            # self.contando = False
            # # self.Limpar('-tempo_restante-')

            sleep(1)
            if self.parar:
                break

        self.pomodoro_habilitado = False
        self.treinando = False
        self.setOn = False
        self.Limpar_saida

    # treinamento da lista de tarefas

    def Treinamento(self, tarefa_exec=''):
        print('Treino iniciado...')
        # print(f'tarefa_exec = {tarefa_exec}')

        # print(f'dist_passo = {dist_passo} \npasso = {self.passo} \nbpm = {bpm}\n')
        def Finalizacao_treino():
            # self.window['-tempo_restante-'].update('Treino Finalizado...')
            # self.Piscar_infos
            self.EscreveTxt(tarefa_exec)
            self.EscrevePlanilha(tarefa_exec)
            # self.window['-tempo_restante-'].update('')

        ii = 0
        self.tempo_restante = float(self.t_total)

        if tarefa_exec == '':
            tarefa_exec = f'{Data()} .-. {"sem nome"} .-. {round(self.tempo_restante/60,1)}min .-. BPM({self.inicio} a  ) .-. passo:   .-. intervalo:  s'

        if self.progressivo:
            while (teste := (bpm := self.getBpm) > self.meta2 if self.inverter else (bpm := self.getBpm) < self.meta2):
                self.Exibir_tempo_restante
                sleep(self.intervalo)
                self.tempo_restante -= self.intervalo

                ii = self.Variador_de_passo(bpm, ii)
                self.ModificarBPM(new_bpm := bpm+self.passo)

                # Para caso o de o botão pause ser pressionado
                while self.pause:
                    sleep(0.1)

                # Para caso o de o botão Stop ser pressionado
                if self.treinando == False or self.treino_habilitado == False or self.tempo_restante <= 0:
                    break

            # para quando a bpm passa da meta
            if (teste2 := bpm < self.meta2 if self.inverter else bpm > self.meta2):
                self.ModificarBPM(self.meta2)
                bpm = self.meta2

            if bpm == self.meta2 or self.tempo_restante == 0:
                MessageBeep(MB_ICONHAND)

        else:
            while self.tempo_restante >= 0:
                self.Exibir_tempo_restante
                sleep(1)
                self.tempo_restante -= 1
                while self.pause:
                    sleep(0.1)
                if self.treinando == False or self.treino_habilitado == False or self.tempo_restante <= 0:
                    break

            if self.tempo_restante == 0:
                MessageBeep(MB_ICONHAND)

        Thread(target=Finalizacao_treino, daemon=True).start()
        self.Testar_continuidade

    def Treinamento_compassos(self):
        print('Treino compassos iniciado...')

        # self.setBpm = self.inicio

        # self.setBpm = meta
        self.cont_tempos = 0
        self.cont_compassos = 0
        ii = 0
        # print(f'\nself.treinando = {self.treinando}\nself.treino_habilitado = {self.treino_habilitado}')
        while (teste := (bpm := self.getBpm) > self.meta2 if self.inverter else (bpm := self.getBpm) < self.meta2):
            # if self.dist_passo != 0:
            #     if ii >= 3:
            #         if bpm >= self.incrementos[ii]:
            #             self.passo = self.passo_fim
            #             self.tempo_restante = int(
            #                 self.constante_de_tempo/self.passo)
            #             print(f'passou dos {self.x[ii]*100}% da meta')

            #     elif bpm >= self.incrementos[ii] and bpm < self.incrementos[ii+1]:
            #         self.passo = self.passo_fim + \
            #             (1-self.x[ii])*self.dist_passo
            #         self.tempo_restante = int(
            #             ((self.meta - bpm)*self.intervalo)/self.passo)
            #         print(f'passou dos {self.x[ii]*100}% da meta')
            #         ii += 1
            ii = self.Variador_de_passo(bpm, ii)
            # print(f'bpm = {bpm}\nteste = {teste}')
            while self.cont_tempos != self.tipo_compasso*self.qtd_compassos:
                sleep(0.01)

            self.cont_tempos = 0
            new_bpm = bpm + self.passo
            self.ModificarBPM(new_bpm)

            # Para caso o de o botão pause ser pressionado
            while self.pause:
                sleep(0.1)
            # Para caso o de o botão Stop ser pressionado
            if self.treinando == False or self.treino_habilitado == False:
                break

        # para quando a bpm passa da meta
        if (teste2 := bpm < self.meta2 if self.inverter else bpm > self.meta2):
            self.ModificarBPM(self.meta2)
            bpm = self.meta2

        if bpm == self.meta2:
            MessageBeep(MB_ICONHAND)

            self.window['-tempo_restante-'].update('Treino Finalizado...')
            # self.EscreveTxt(tarefa_exec)
            # self.EscrevePlanilha(tarefa_exec)

            # fazer o nome ficar pisacando na tela
            # for i in range(4):
            #     self.window['-tempo_restante-'].update(text_color='#ffff80')
            #     sleep(0.5)
            #     self.window['-tempo_restante-'].update(text_color='red')
            #     sleep(0.5)
            # self.window['-tempo_restante-'].update(text_color='#4ab580')
            self.Piscar_infos
            self.Testar_continuidade
        # if self.continuar == False:
        #     self.pomodoro_habilitado = False
        #     self.treinando = False
        #     self.setOn = False

    def Treinamento2(self, tarefa_exec):
        print('Treino iniciado...')

        if self.inverter:
            lista = [
                i/10 for i in range(self.meta*10, (self.inicio-1)*10, int(self.passo*(-10)))]
        else:
            lista = [
                i/10 for i in range(self.inicio*10, (self.meta+1)*10, int(self.passo*10))]

        self.tempo_restante = float(self.t_total) + float(self.intervalo)

        for i in lista:
            horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(
                self.tempo_restante - float(self.intervalo))
            self.window['-tempo_restante-'].update(
                f"Tempo restante: {horas2}:{minutos2}:{segundos2}")
            # a = time.time()
            while self.pause:
                sleep(0.1)
                # print(self.pause)

            self.ModificarBPM(i)

            # self.window['-bpm-'].update(i)
            # print(i)
            # print(f'intervalo = {self.intervalo}')
            sleep(self.intervalo)  # -10.092530717849731)
            # print(self.treinando )
            self.tempo_restante -= self.intervalo

            # or  self.getBpm >= self.meta:
            if self.treinando == False or self.treino_habilitado == False:
                # print(
                # f'self.treinando = {self.treinando} - self.treino_habilitado = {self.treino_habilitado}')
                # self.window['-tempo_restante-'].update('Treino Finalizado...')
                # for i in range(8):
                #     self.window['-tempo_restante-'].update(text_color = '#ffff80')
                #     sleep(0.5)
                #     self.window['-tempo_restante-'].update(text_color = 'red')
                #     sleep(0.5)

                # sg.popup('Treino Finalizado...', auto_close = True, auto_close_duration = 3)
                break
            # print(time.time()-a)

        if i == lista[-1]:
            MessageBeep(MB_ICONHAND)
            # self.window[event].update(button_color = 'red')

            self.window['-tempo_restante-'].update('Treino Finalizado...')
            self.EscreveTxt(tarefa_exec)
            self.EscrevePlanilha(tarefa_exec)

            for i in range(4):
                self.window['-tempo_restante-'].update(text_color='#ffff80')
                sleep(0.5)
                self.window['-tempo_restante-'].update(text_color='red')
                sleep(0.5)
            self.window['-tempo_restante-'].update(text_color='#ffff80')

        if self.continuar == False:
            self.pomodoro_habilitado = False
            self.treinando = False
            self.setOn = False

        # print('Treino Finalizado...')
    def Pomodoro(self):

        self.display['-tempo_pomodoro-'] = 'Pomodoro inciado...'
        while self.pomodoro_habilitado:
            self.Contagem(self.tempo_pomodoro*60)
            if self.pomodoro_habilitado == False:
                break
            MessageBeep(MB_ICONHAND)

            if self.pomodoro_habilitado == False:
                break


            ##########################################
            # horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(
            #     self.tempo_descanso*60)
            # self.display['-tempo_pomodoro-'] = f'Faça uma pausa de {horas2}:{minutos2}:{segundos2}'
            self.contando = True
            # Thread(target=self.Barra_de_progresso, daemon=True).start()

            if self.pomodoro_habilitado == False:
                break
            self.Pausar
            if self.pomodoro_habilitado == False:
                break

            # self.Contagem(self.tempo_descanso*60)
            self.Barra2(self)
            if self.pomodoro_habilitado == False:
                break
            MessageBeep(MB_ICONHAND)
            if self.pomodoro_habilitado == False:
                break
            horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(
                self.tempo_pomodoro*60)
            self.display['-tempo_pomodoro-'] = f'Volte a treinor por {horas2}:{minutos2}:{segundos2} '
            if self.pomodoro_habilitado == False:
                break

            self.Pausar

        self.display['-tempo_pomodoro-'] = ''

    def Barra2(self, e=''):
        while self.contando:
            sleep(1)
            

    def Barra_de_progresso(self):
        SYMBOL_SQUARE = '█'
        largura_janela = self.window.TKroot.winfo_width()
        print(largura_janela)
        nova_largura = int(largura_janela/10)+12
        print(nova_largura)

        # self.display['-TEXT-'].set_size((nova_largura, 1))
        inc = -1
        # self.window['-respiracao-'].update(visible=True)
        # self.window['-TEXT-'].update(visible=True)
        while self.contando:
            inc = inc+1
            if inc <= 93:
                sleep(0.01)
                if inc == 0:
                    self.window['-respiracao-'].update(text_color='green')
                    self.window['-TEXT-'].update(text_color='green')
                    self.window['-respiracao-'].update('»»»    INSPIRE    «««')

                self.window['-TEXT-'].update(SYMBOL_SQUARE * inc)
            else:
                sleep(0.1)
                if inc == 94:
                    self.window['-respiracao-'].update(text_color='yellow')
                    self.window['-TEXT-'].update(text_color='yellow')
                    self.window['-respiracao-'].update('«««    EXPIRE    »»»')
                inc2 = int(175-inc)
                self.window['-TEXT-'].update(SYMBOL_SQUARE * inc2)
            if inc == 174:
                inc = -1
        self.window['-respiracao-'].update('')
        self.window['-TEXT-'].update('')
        self.window['-respiracao-'].update(visible=False)
        self.window['-TEXT-'].update(visible=False)

    def Contagem(self, tempo):
        tempo = int(round(tempo, 0))
        print(tempo)
        for i in range(tempo):
            while self.pausar_pomodoro:
                sleep(0.1)

            h1, h2, h3 = self.converter_segundos_para_horas_min_segundos(tempo-i)
            self.display['-contagem-'] = f'({h1}:{h2}:{h3})'

            sleep(1)

            if self.pomodoro_habilitado == False:
                break
        self.display['-contagem-'] = ''

    def Contagem2(self, tempo):
        tempo = int(round(tempo, 0))
        for i in range(tempo):
            while self.pausar_pomodoro:
                sleep(0.1)

            h1, h2, h3 = self.converter_segundos_para_horas_min_segundos(
                tempo-i)
            self.window['-tempo_de_treino-'].update(f'Faça uma pausa de {h1}:{h2}:{h3}')

            sleep(1)

            if self.pomodoro_habilitado == False:
                break
        self.window['-tempo_de_treino-'].update('')

    @property
    def Tap(self):
        print('tap pressionado')
        if not self.iniciar_medicao_bpm:
            self.ti = time()
            self.iniciar_medicao_bpm = not self.iniciar_medicao_bpm
        else:
            self.tf = time()
            # print(f'delta T = {self.tf-self.ti}')
            novo_bpm = round(int(60/(self.tf-self.ti)), 0)
            self.ModificarBPM(novo_bpm)
            self.ti = None
            self.tf = None
            self.iniciar_medicao_bpm = not self.iniciar_medicao_bpm

    def Prints(self, texto):
        self.window['-TEXT-'].update(texto)
        self.window['-TEXT-'].update(visible=True)

    def Ini_Thread(self, controle, argu=''):
        if controle == 'pomodoro':
            self.setOn = False
            sleep(0.3)
            self.setOn = True
            if self.pomodoro_habilitado:
                print('self.tempo_pomodoro:', (self.tempo_pomodoro), (self.tempo_descanso))
                if self.tempo_pomodoro != '' and self.tempo_descanso != '':
                    try:
                        self.tempo_pomodoro, self.tempo_descanso = float(
                            self.tempo_pomodoro), float(self.tempo_descanso)
                    except TypeError:
                        print('Erro na conversão dos tempo_pomodoro e tempo_descanso', TypeError)
                        self.tempo_pomodoro, self.tempo_descanso = 3, 1
                    Thread(target=self.Pomodoro, daemon=False).start()
            else:
                print('pomodoro desabilitado')

        elif controle == 'beep':
            if not self.metronomo_inciado:
                Thread(target=self.beep, daemon=False).start()
                self.metronomo_inciado = True
            else:
                print('metronomo já iniciado')

        elif controle == 'Treinamento':
            self.Treinar
            print('vai reinar')
            if self.passo_fim < self.passo or self.passo == -1:
                if self.metronomo_inciado:
                    if not self.treinando:
                        self.treinando = True
                        Thread(target=self.Treinamento,
                               args=argu, daemon=False).start()

        elif controle == 'Executar tarefas':
            self.Treinar
            if not self.treinando:
                self.treinando = True
                Thread(target=self.Executar_tarefas,
                       args=argu, daemon=False).start()

            else:
                raise ValueError(
                    "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")

        elif controle == 'compassos':
            self.Treinar
            if self.passo_fim < self.passo:
                if self.metronomo_inciado:
                    if not self.treinando:
                        self.treinando = True
                        Thread(target=self.Treinamento_compassos,
                               daemon=False).start()

            else:
                # raise ValueError(
                #     "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")
                self.Prints(
                    "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")

    def Play(self, e = ''):
        self.Ini_Thread('pomodoro')
        # print('self.getOn:',self.getOn() )
        self.Ini_Thread('beep')
        # Ini_Thread().Tr_Pomodoro()
        # Ini_Thread().Tr_Beep()
        # print('tempo-compasso =', self.tempo_compasso)
        if self.tempo_compasso == 'Tempo' and self.treino_habilitado:
            self.tipo_de_treino = 'treinamento'
            self.Ini_Thread('Treinamento')
        elif self.tempo_compasso == 'Compassos' and self.treino_habilitado:
            self.tipo_de_treino = 'compassos'
            self.Ini_Thread('compassos')

    def Play_tarefas(self):
        self.Ini_Thread('pomodoro')
        self.Ini_Thread('beep')
        self.treino_habilitado = True
        self.inverter = False
        self.tempo = True
        self.passo_fim = 0
        # try:
        intervalo_bpm = round(
            (float(self.t_total)*float(self.passo))/(float(self.meta) - float(self.inicio)), 3)

        if self.metronomo_inciado:
            self.nome_treino = 'sem nome' if self.nome_treino == '' else self.nome_treino
            tarefa_exec = f'{Data()} .-. {self.nome_treino} .-. {self.t_total}min .-. BPM({self.inicio} a {self.meta}) .-. passo: {self.passo} .-. intervalo: {intervalo_bpm}s'
            self.Ini_Thread('Treinamento', [(tarefa_exec)])

    def Pause(self, e = ''):
        self.Pausar
        if self.pomodoro_habilitado:
            self.pausar_pomodoro = not self.pausar_pomodoro

    def Stop(self, e = ''):
        # if window != '':
        #     for hh in ['-tempo_de_treino-', '-contagem-', '-tempo_pomodoro-', '-tempo_restante-', '-TEXT-']:
        #         self.window[hh].update("")
        #     self.window['-TEXT-'].update(visible=False)
        
        self.setOn = False
        self.treinando = False
        self.pomodoro_habilitado = False
        self.treinando_compassos = False
        self.metronomo_inciado = False

        self.ModificarBPM(self.bpm_atual)
        self.parar = True   


# m = Metronomo_Control_flet()
# # m.setOn = True
# m.pomodoro_habilitado = True
# m.tempo_pomodoro = 3
# m.tempo_descanso = 1
# m.Play()        