from metronomo import Metronomo
from flet import*
from Swhitch_new import Switch_new
from controlador_metronomo_flet import Escrever_json, Ler_json, Metronomo_Control_flet, Thread

class Quadro(UserControl):
    def __init__(self, 
                #  page, 
                content = None,
                 width = None, 
                 height = None,
                 expand = 1,
                 bgcolor = None,
                 border_color = 'white',
                 
                 ):
        super().__init__()
        # self._page = page
        self._content = content
        self._width = width
        self._height = height
        self._bgcolor = bgcolor
        self._border_color = border_color
        self._expand = expand
        self._bgcolor = bgcolor
    
    def build(self):
        return Container(
        content = self._content,
        alignment=Alignment(0,0),
        border= border.all(1, color = self._border_color),
        width= self._width,
        height= self._height,
        expand = self._expand,
        bgcolor = self._bgcolor
        )



class Drop_new(UserControl):
    def __init__(self, 
        opitions = [], 
        value = None,
        width_person = None,
        on_change = None,
        data = None,

                
                ):
        super().__init__()
        self._opitions  = opitions
        self.value = value
        self._width = 30 if opitions == [] else 80
        self.on_change = on_change
        self.data = data

        if width_person != None:
            self._width = width_person         
        self._drop = Dropdown(        
                alignment= Alignment(-1, 1),
                options=[dropdown.Option(i) for i in self._opitions],
                text_size = 15,
                border_width = 0,
                border=None,
                # border_color='white',
                expand=0,
                scale=1,
                autofocus = 0,
                value = self.value,
                width = self._width,
                # aspect_ratio = 1,
                height = 40,
                dense = True,
                text_style = TextStyle(weight = 'bold'),
                on_change=self.mudou,
                                                  
        )


    def build(self):
        return self._drop
    def mudou(self, e):
        self.value = self._drop.value
        if self.on_change != None:
            self.enviar_change(e)
        super().update()
    def enviar_change(self,e):
        self.on_change(self, e)



    


class New_task(UserControl):
    def __init__(self,
        task_delete,
        ):
        super().__init__()
        self.task_delete = task_delete



    def build(self):
        remover_tarefa = IconButton(icon=icons.DELETE, on_click = self.clicked, data ='del')
        nome_tarefa = TextField(hint_text = 'nome da tarefa', width = 230)
        duracao_tarefa = Drop_new([0.1,0.3,0.5]+[i for i in range(1,31)], 3, width_person = 75)
        inicio_tarefa = Drop_new([i for i in range(30,301)], 70, width_person = 75)
        fim_tarefa = Drop_new([i for i in range(30,311)], 170, width_person = 75)
        passo_tarefa = Drop_new([0.1,0.3,0.5,0.7,0.9]+[i for i in range(1,20)], 3, width_person = 75)
        # tamanho_botao_acao_tarefas = 
        play_parefa = IconButton(icon=icons.PLAY_ARROW, on_click = self.clicked, data ='play tarefa')
        pause_parefa = IconButton(icon=icons.PAUSE, on_click = self.clicked, data ='pause tarefa')

        linha_tarefa = [
            remover_tarefa,
            nome_tarefa,
            duracao_tarefa,
            inicio_tarefa,
            fim_tarefa,
            passo_tarefa,
            play_parefa,
            pause_parefa
        ]
        linha_tarefa = Row([Quadro(i) for i in linha_tarefa], alignment='center')
        linha_tarefa = Quadro(linha_tarefa, height = 50)
        return linha_tarefa
    
    def clicked(self, e):
        # data = e.control.data
        self.task_delete(self,e)

        # match data:
        #     case 'del':
        #         self.task_delete(self)
        #     case 'play tarefa':
        #         pass
        #     case 'pause tarefa':
        #         pass



class Layout(UserControl, Metronomo):
    def __init__(self,
        page,
        ):
        super().__init__() 
        self.page = page
        self.Metro_normal = Metronomo_Control_flet()

        self.col_tarefas = Column()
        self.Importar = TextButton('Importar', on_click=self.acoes_botoes_layout, data = 'Importar')
        self.Exportar = TextButton('Exportar', on_click=self.acoes_botoes_layout, data = 'Exportar')
        self.Selecionar_planilha = TextButton('Selecionar Planilha', on_click=self.acoes_botoes_layout, data = 'Selecionar Planilha')

        cor_botoes_bpm = colors.PINK_50
        self.Bot_m1 = OutlinedButton('+1', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m1')
        self.Bot_m5 = OutlinedButton('+5', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m5')
        self.Bot_m10 = OutlinedButton('+10', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m10')
        self.Bot_m_1 = OutlinedButton('-1', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m_1')
        self.Bot_m_5 = OutlinedButton('-5', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m_5')
        self.Bot_m_10 = OutlinedButton('-10', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m_10')
        self.display_bpm = Dropdown(data = 'valorbpm',
                    alignment= Alignment(0, 1),
                    options=[dropdown.Option(i) for i in range(30,550,1)],
                    text_size = 20,
                    border=1,
                    border_color='white',
                    prefix_text = 'bpm: ',
                    # expand=1,
                    value = 55,
                    width = 120,
                    # aspect_ratio = 0.5,
                    # height = 200,
                    # content_padding = 0,
                    text_style = TextStyle(weight = 'bold'),
                    on_change=self.acoes_botoes_layout
                                                    
            )

        self.vol  =  Slider(min = 0, max = 1, divisions=11, label='{value}', width=130, on_change=self.acoes_botoes_layout, data = 'vol')
        self.Inverter = Checkbox(on_change=self.acoes_botoes_layout, data = 'Inverter')
        self.Treino_habilitado = Checkbox(on_change=self.acoes_botoes_layout, data = 'Treino_habilitado')
        self.Tap = IconButton(icon = icons.CIRCLE,on_click=self.acoes_botoes_layout, data = 'Tap')

        tamanho_slids = 300
        self.meta = Slider(min = 30, max = 300, divisions=271, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'meta')
        self.inicio = Slider(min = 30, max = 301, divisions=271, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'inicio')
        self.passo = Slider(min = 0, max = 5, divisions=51, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'passo')
        self.passo_fim = Slider(min = 0, max = 5, divisions=51, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'passo_fim')



        self.intervalo  =  Slider(min = 1, max = 30, divisions=31, label='{value}', width=300,on_change=self.acoes_botoes_layout, data = 'intervalo')
        self.tempo = Checkbox(on_change=self.acoes_botoes_layout, data = 'tempo')
        self.Tipo_compasso = Drop_new(['2/4', '3/4', '4/4'], '4/4',
                                      on_change=self.acoes_botoes_layout, data = 'Tipo_compasso'
                                      )
        self.qtd_compassos = Drop_new([i for i in range(1,48)], 1,
                                      on_change=self.acoes_botoes_layout, data = 'qtd_compassos'
                                      )


        self.continuar = Checkbox(on_change=self.acoes_botoes_layout, data = 'continuar')
        self.pomodoro_habilitado = Checkbox(on_change=self.acoes_botoes_layout, data = 'pomodoro_habilitado')
        self.tempo_pomodoro = Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 1,
                                       on_change=self.acoes_botoes_layout, data = 'tempo_pomodoro'
                                       )
        self.tempo_descanso = Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 1,
                                       on_change=self.acoes_botoes_layout, data = 'tempo_descanso'
                                       )        

        self.task_lis_select = Dropdown(                
            alignment= Alignment(-1, 1),
            options=[dropdown.Option(i) for i in [ 'musica 1', 'musica 2']],
            text_size = 20,
            border_color=colors.with_opacity(0.2,'white'),
            value = 'musica 1',
            color = colors.with_opacity(1,'white'),
            height = 50,
            content_padding = 0,
            autofocus = 0,
            on_change=self.acoes_botoes_layout, data = 'task_lis_select'

        )

        tamanho_botao = 180
        self.play = IconButton(icon=icons.PLAY_ARROW, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'play')
        self.pause = IconButton(icon=icons.PAUSE, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'pause')
        self.stop = IconButton(icon=icons.STOP, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'stop')
        self.salvar = IconButton(icon=icons.SAVE, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'salvar')
        
        self.quado_saida = Quadro(height = 120)

        self.add_tarefa = OutlinedButton('Add tarefa', on_click=self.acoes_botoes_layout, data = 'add new task')
        self.play_tarefas = OutlinedButton('Play Tarefas',on_click=self.acoes_botoes_layout, data = 'Play Tarefas')


    def acoes_tasks(self, task,e):
        data = e.control.data
        t = task
        match data:
            case 'del':
                self.col_tarefas.controls.remove(task)
            case 'play tarefa':
                print('Apertou play')
                self.Metro_normal.pomodoro_habilitado = self.pomodoro_habilitado.value
                self.Metro_normal.tempo_descanso, self.Metro_normal.tempo_pomodoro = int(self.tempo_descanso.value), float(self.tempo_pomodoro.value)
                # Thread(target=self.check_display, daemon=False).start()
                self.Metro_normal.Play()                
            case 'pause tarefa':
                print('Apertou pause')


        super().update()
        print('ação recebida',data )


    def acoes_botoes_layout(self, e, task = ''):
        # self.Exibir_atributos(e.data)
        # print(e.data)
        try:
            data = e.control.data
        except:
            data = e.data
        

        match data:                    
            case 'Importar':
                print('tempo_pomodoro alterado')
            case 'Exportar':
                print('tempo_pomodoro alterado')
            case 'Selecionar Planilha':
                print('tempo_pomodoro alterado')
            case 'Bot_m1':
                print('tempo_pomodoro alterado')
            case 'Bot_m5':
                print('tempo_pomodoro alterado')
            case 'Bot_m10':
                print('tempo_pomodoro alterado')  
            case 'Bot_m_1':
                print('tempo_pomodoro alterado')
            case 'Bot_m_5':
                print('tempo_pomodoro alterado')
            case 'Bot_m_10':
                print('tempo_pomodoro alterado')
            case 'valorbpm':
                self.Metro_normal.bpm_atual = self.display_bpm.value
            case 'vol':
                print('tempo_pomodoro alterado')
            case 'Inverter':
                print('tempo_pomodoro alterado') 
            case 'Treino_habilitado':
                print('tempo_pomodoro alterado')
            case 'Tap':
                print('tempo_pomodoro alterado')
            case 'meta':
                print('tempo_pomodoro alterado')
            case 'inicio':
                print('tempo_pomodoro alterado')
            case 'passo':
                print('tempo_pomodoro alterado')
            case 'passo_fim':
                print('tempo_pomodoro alterado') 
            case 'intervalo':
                print('tempo_pomodoro alterado')
            case 'tempo':
                print('tempo_pomodoro alterado')
            case 'Tipo_compasso':
                print('tempo_pomodoro alterado')
            case 'qtd_compassos':
                print('tempo_pomodoro alterado')
            case 'continuar':
                print('tempo_pomodoro alterado')
            case 'pomodoro_habilitado':
                print('tempo_pomodoro alterado') 
            case 'tempo_pomodoro':
                print('tempo_pomodoro alterado')
            case 'tempo_descanso':
                print('tempo_pomodoro alterado')
            case 'task_lis_select':
                print('tempo_pomodoro alterado')
            case 'play':
                # self.Metro_normal.bpm_atual = self.display_bpm.value
                # self.Metro_normal.Stop()
                # self.Metro_normal = None
                # self.Metro_normal = Metronomo_Control_flet()
                # for i in self.__dict__.keys():
                #     print(i)
                self.setOn = True
                self.beep()


            case 'pause':
                print('tempo_pomodoro alterado')
            case 'stop':
                print('tempo_pomodoro alterado') 
            case 'salvar':
                print('tempo_pomodoro alterado') 
            case 'add new task':
                self.col_tarefas.controls.append(New_task(self.acoes_tasks)) 
                print('add tarefa')
            case 'Play Tarefas':
                print('tempo_pomodoro alterado') 




        super().update()        

    def build(self):
        menu_bar = Row([
            self.Importar,
            self.Exportar,
            self.Selecionar_planilha,
        ], height=18)        
        quadro_bpm = Quadro(Row([
            self.Bot_m1, 
            self.Bot_m5, 
            self.Bot_m10, 
            self.display_bpm,
            self.Bot_m_1, 
            self.Bot_m_5, 
            self.Bot_m_10,
        ], alignment=MainAxisAlignment.SPACE_AROUND))  


        vol = Row([Text('Vol'),self.vol],spacing=0,)
        inverter = Row([self.Inverter, Text('Inverter')], spacing=0)
        Treino_habilitado= Row([self.Treino_habilitado , Text('Treino_habilitado')], spacing=0)        
        tap = Row([Text('Tap'),self.Tap], spacing=0)   
        quadro_vol = Quadro(Row([vol, inverter, Treino_habilitado, tap], alignment=MainAxisAlignment.SPACE_AROUND))

        meta  =  Row([Text('Meta'),self.meta],spacing=0,)
        inicio  =  Row([Text('Inicio'),self.inicio],spacing=0,)
        passo  =  Row([Text('Passo'),self.passo],spacing=0,)
        passo_fim  =  Row([Text('Passo_fim'),self.passo_fim],spacing=0,)
        col_trainamento = Quadro(Column([meta, inicio, passo, passo_fim], spacing=0),height=200,)


        intervalo = Row([Text('Intervalo'),self.intervalo],spacing=0,)
        tempo = Row([self.tempo, Text('Tempo (min)')], spacing=0)
        Tipo_compasso = Row([Text('Tipo de Compasso'),self.Tipo_compasso])
        qtd_compassos = Row([Text('Qtd de Compasso'),self.qtd_compassos])

        self.tab_compassos = Quadro(Row([Tabs(
            selected_index=0,
            animation_duration=300,
            tabs=[
                Tab(
                    text="Tempo",
                    content=Column([intervalo, tempo])
                ),
                Tab(
                    text="Compassos",
                    # tab_content=Icon(icons.SEARCH),
                    content=Column([Tipo_compasso, qtd_compassos])
                ),
            ],
            width=350,
            height=200,
            # expand=1,
            )
            ]),
            expand = 0,
        )
        

        quadro_trainamento = Quadro(Row([col_trainamento,self.tab_compassos],alignment=MainAxisAlignment.SPACE_AROUND))

        Treinamento = Quadro(Column([quadro_bpm,self.task_lis_select,quadro_vol,quadro_trainamento]))
   

        quadro_botoes = [self.play, self.pause, self.stop, self.salvar]
        quadro_botoes = [Quadro(i, bgcolor = '#888888') for i in quadro_botoes]
        quadro_botoes = Quadro(Row(quadro_botoes,alignment=MainAxisAlignment.SPACE_AROUND))


        botos_tarefas = Row([self.add_tarefa, self.play_tarefas], alignment=MainAxisAlignment.SPACE_AROUND)
        titulos_tarefas = Row([
            VerticalDivider(width=120),
            Text('Treino'),
            VerticalDivider(width=120),
            Text('Duração'),
            VerticalDivider(width=40),
            Text('In'),
            VerticalDivider(width=40),
            Text('Fim'),
            VerticalDivider(width=40),
            Text('Passo'),                                                   
        ])
        
        self.col_tarefas.scroll = ScrollMode.ALWAYS
        Tarefass = Column([botos_tarefas,titulos_tarefas, 
                           Container(self.col_tarefas,
                            alignment=Alignment(-1,-1),
                            border= border.all(1, color = 'white'),
                            height= 305,
        )
                            ], height=350, expand=0)       
        # Tarefass.scroll = ScrollMode.ALWAYS

        for i in range(3):
            t1 = New_task(self.acoes_tasks)
            self.col_tarefas.controls.append(t1)

        
        modos = Tabs(
            selected_index=0,
            animation_duration=300,
            tabs=[
                Tab(
                    text="Treinamento",
                    content=Treinamento
                ),
                Tab(
                    text="Tarefas",
                    # tab_content=Icon(icons.SEARCH),
                    content=Tarefass
                ),
            ],
            width=self.page.window_width-5,
            height=430,
            # expand=1,
            )

        continuar = Row([self.continuar, Text('Continuar')], spacing=0)
        pomodoro = Row([self.pomodoro_habilitado, Text('Pomodoro'),Quadro(self.tempo_pomodoro) ], spacing=0)
        descanso = Row([Text('Descanso'),Quadro(self.tempo_descanso) ], spacing=0)
        quadro_pomodoro = Quadro(Row([continuar, pomodoro, descanso],alignment=MainAxisAlignment.SPACE_AROUND))
    
        return Column([
            menu_bar,
            modos,
            quadro_pomodoro,
            quadro_botoes, 
            self.quado_saida,
        ])

    def Exibir_atributos(self, objeto):
        for i in objeto.__dict__.keys():
            print(i) 

    
    
def main(page: Page):
    page.title = "Exemplo Layout"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = '#000000', #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750
    
    # layout = Quadro(page, 
    #                 width = page.window_width-1,
    #                 height= page.window_height-55,  
    #                 border_color = 'white',
    # )
    # layout.contet = Column(Text('kjhkjhkj', size = 200, color='white'))
    def Exibir_atributos(objeto):
        for i in objeto.__dict__.keys():
            print(i) 
    app = Layout(page)
    # pomodoro_habilitado = Checkbox()
    # pomodoro = Row([pomodoro_habilitado, Text('Pomodoro'),Quadro(Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 1)) ], spacing=0)
    # Exibir_atributos(pomodoro.controls)  
    # print(pomodoro_habilitado.value)          
    page.add(app)
    # page.add(self.menu_bar,modos,quadro_pomodoro,quadro_botoes, quado_saida)
    # page.add(col_tarefas)

 
    page.update() 
# app(target=main, view=AppView.WEB_BROWSER)
app(target=main)
