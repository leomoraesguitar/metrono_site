from flet import*
from Swhitch_new import Switch_new
from controlador_metronomo_flet import Escrever_json, Ler_json, Metronomo_Control_flet, Thread
from metronomo import Metronomo, sleep, time
from winsound import MessageBeep, MB_ICONHAND
from saidas import Saidas
from funcoes_leo.funcoes import Data, Juntar
from os import getcwd
from re import search
from googlesheets_leo import AtualizarCelulas, LerCelulas
import asyncio



class Countdown(UserControl):
    def __init__(self, minutos, texto = ''):
        super().__init__()
        self.minutos = minutos
        self.segundos = 60*minutos
        self.texto = texto
        self.pause = False

    async def did_mount_async(self):
        self.running = True
        if self.minutos != '':
            asyncio.create_task(self.update_timer())
        else:
            self.countdown.value = self.texto
            await self.update_async()

    async def will_unmount_async(self):
        self.running = False

    async def update_timer(self):
        while self.segundos and self.running:
            h, mins = divmod(self.segundos, 60*60)
            mins, secs = divmod(mins, 60)
            h, mins, secs = int(h), int(mins), int(secs)
            if self.texto != '':
                self.countdown.value = "{:s} {:02d}:{:02d}:{:02d}".format(self.texto,h, mins, secs)
            else:
                self.countdown.value = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)

            await self.update_async()
            await asyncio.sleep(1)
            self.segundos -= 1
            while self.pause:
                await asyncio.sleep(0.3)

            

    def build(self):
        self.countdown = Text()
        return self.countdown

class Quadro(UserControl):
    def __init__(self, 
                content = None,
                #  page = Page,
                 width = None, 
                 height = None,
                 expand = 0,
                 bgcolor = None,
                 border_color = 'white',
                 
                 ):
        super().__init__()
        # self.page = page
        self.content = content
        self.width = width
        self.height = height
        self.bgcolor = bgcolor
        self.border_color = border_color
        self.expand = expand
        self.bgcolor = bgcolor
    
    def build(self):
        return Container(
        content = self.content,
        alignment=Alignment(0,0),
        border= border.all(1, color = self.border_color),
        width= self.width,
        height= self.height,
        expand = self.expand,
        bgcolor = self.bgcolor
        )

class Quadro_assync(UserControl):
    def __init__(self, 
                content = None,
                 tipo = 'r', #ou 'c'
                #  page = Page,
                 width = None, 
                 height = None,
                 expand = 1,
                 bgcolor = None,
                 border_color = 'white',
                 
                 ):
        super().__init__()
        # self._page = page
        self.tipo = tipo
        self.content = content #Row(content) if self.tipo == 'r' else Column(content)
        self.width = width
        self.height = height
        self.bgcolor = bgcolor
        self.border_color = border_color
        self.expand = expand
        self.bgcolor = bgcolor
    
    def build(self):
        return Container(
        content = self.content,
        alignment=Alignment(0,0),
        border = border.all(1, color = self.border_color),
        width= self.width,
        height= self.height,
        expand = self.expand,
        bgcolor = self.bgcolor
        )


class Drop_new(UserControl):
    def __init__(self, 
        opitions = [], 
        value = None,
        width_person = None,
        on_change = None,
        data = None,

                
                ):
        super().__init__()
        self.opitions  = opitions
        self.value = value
        self.width = 30 if opitions == [] else 80
        self.on_change = on_change
        self.data = data

        if width_person != None:
            self._width = width_person         
        self._drop = Dropdown(        
                alignment= Alignment(-1, 1),
                options=[dropdown.Option(i) for i in self.opitions],
                text_size = 15,
                border_width = 0,
                border=None,
                # border_color='white',
                expand=0,
                scale=1,
                autofocus = 0,
                value = self.value,
                width = self.width,
                # aspect_ratio = 1,
                height = 40,
                dense = True,
                text_style = TextStyle(weight = 'bold'),
                on_change=self.mudou,
                                                  
        )


    def build(self):
        return self._drop
    async def mudou(self, e):
        self.value = self._drop.value
        if self.on_change != None:
            await self.enviar_change(e)
        await super().update_async()
    async def enviar_change(self,e):
        await self.on_change(self, e)


class New_task(UserControl):
    def __init__(self,
        task_delete,
        ):
        super().__init__()
        self.task_delete = task_delete
        self.nome_tarefa = TextField(hint_text = 'nome da tarefa', width = 200)
        self.duracao_tarefa = Drop_new([0.1,0.3,0.5]+[i for i in range(1,31)], 3, width_person = 75)
        self.inicio_tarefa = Drop_new([i for i in range(30,301)], 70, width_person = 75)
        self.fim_tarefa = Drop_new([i for i in range(30,311)], 170, width_person = 75)
        self.passo_tarefa = Drop_new([0.1,0.3,0.5,0.7,0.9]+[i for i in range(1,20)], 3, width_person = 75)



    def build(self):
        remover_tarefa = IconButton(icon=icons.DELETE, on_click = self.clicked, data ='del')
        # tamanho_botao_acao_tarefas = 
        self.play_parefa = IconButton(icon=icons.PLAY_ARROW, on_click = self.clicked, data ='play tarefa')
        pause_parefa = IconButton(icon=icons.PAUSE, on_click = self.clicked, data ='pause tarefa')

        linha_tarefa = [
            remover_tarefa,
            self.nome_tarefa,
            self.duracao_tarefa,
            self.inicio_tarefa,
            self.fim_tarefa,
            self.passo_tarefa,
            self.play_parefa,
            pause_parefa
        ]
        linha_tarefa = Row([Quadro(i) for i in linha_tarefa], alignment='center', expand=1)
        linha_tarefa = Container(linha_tarefa, height = 50, border= border.all(1, color = 'white'))
        return linha_tarefa
    
    async def clicked(self, e):
        # data = e.control.data
        # if e.control.data == 'play tarefa':
        #     e.control.bgcolor = 'red'
        #     print(e.control.bgcolor)
        # super().update_async()
        await self.task_delete(self,e)

        # match data:
        #     case 'del':
        #         self.task_delete(self)
        #     case 'play tarefa':
        #         pass
        #     case 'pause tarefa':
        #         pass


class Slider_new(UserControl):
    def __init__(self,
                texto = None,
                 min = None,
                 max = None,
                 divisions = None,
                 fator = 1, #valor a ser multiplicado por value
                 digitos = 1,
                 width = 200,
                 on_change = None,
                 data = None, 
                 value = False,
    ):



        super().__init__()
        self.texto = texto
        self.min = min
        self.max = max
        self.divisions = divisions
        self.fator = fator
        self.digitos = digitos
        self.width = width
        self.on_change = on_change
        self.data = data
        self.value = value

        self.passo_fim2 = Slider(min = self.min, max = self.max, divisions=self.divisions,value = self.value, width=self.width,on_change=self.mudou, data = self.data)
        valor = round(self.passo_fim2.value*self.fator,self.digitos)
        if self.digitos == 0:
            valor = int(valor)
        self.texto2 = Text(f'{self.texto} ({valor})')

    async def mudou(self,e):
        valor = round(self.passo_fim2.value*self.fator,self.digitos)
        if self.digitos == 0:
            valor = int(valor)
        self.texto2.value = f'{self.texto} ({valor})'
        self.value = valor
        await self.on_change(e, self)
        await super().update_async()

    def build(self):
        return Row([self.texto2, self.passo_fim2],alignment='start', tight = True, spacing=0,run_spacing = 0, height=30)


config = 'config_metronomo_exemplo.json'
try:
    nome_da_credencial = 'client_secret.json'
except:
    print(f'O arquivo "client_secret.json" não foi encontrado')  


class Layout(UserControl):
    def __init__(self,
        page,
        ):
        super().__init__() 
        self.page = page
        self.Metro_normal = Metronomo()
        self.Modo = 'normal'
        self.pause_lay = False
        self.Iniciar_arquiv()

        #parâmetros do metrônomo
        self.metronomo_iniciado = False
        self.parar = False
        self.play_tarefas = False




        self.col_tarefas = Column()
        self.Importar = TextButton('Importar', on_click=self.acoes_botoes_layout, data = 'Importar')
        self.Exportar = TextButton('Exportar', on_click=self.acoes_botoes_layout, data = 'Exportar')
        self.Selecionar_planilha = TextButton('Selecionar Planilha', on_click=self.acoes_botoes_layout, data = 'Selecionar Planilha')
        #1-vU6ONr6gZTcpOI-inXlzpiwcPqUpDgBgXnPXvjkPjk
        cor_botoes_bpm = colors.PINK_50
        self.Bot_m1 = OutlinedButton('+1', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m1')
        self.Bot_m5 = OutlinedButton('+5', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m5')
        self.Bot_m10 = OutlinedButton('+10', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m10')
        self.Bot_m_1 = OutlinedButton('-1', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m_1')
        self.Bot_m_5 = OutlinedButton('-5', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m_5')
        self.Bot_m_10 = OutlinedButton('-10', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m_10')
        self.display_bpm = Dropdown(data = 'valorbpm',
                    alignment= Alignment(0, 1),
                    options=[dropdown.Option(i) for i in range(30,550,1)],
                    text_size = 20,
                    border=1,
                    border_color='white',
                    prefix_text = 'bpm: ',
                    # expand=1,
                    value = 155,
                    width = 135,
                    # aspect_ratio = 0.5,
                    # height = 200,
                    # content_padding = 0,
                    text_style = TextStyle(weight = 'bold'),
                    on_change=self.acoes_botoes_layout
                                                    
            )

        self.vol  =  Slider(min = 0, max = 10, divisions=10, value = 10,label='{value}', width=130, on_change=self.acoes_botoes_layout, data = 'vol')
        self.inverter = Checkbox(on_change=self.acoes_botoes_layout, data = 'Inverter', value = False)
        self.Treino_habilitado = Checkbox(on_change=self.acoes_botoes_layout, data = 'Treino_habilitado', value = True)
        self.Tap = IconButton(icon = icons.CIRCLE,on_click=self.acoes_botoes_layout, data = 'Tap')

        tamanho_slids = 300
        # self.meta = Slider(min = 30, max = 300, divisions=271, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'meta')
        # self.inicio = Slider(min = 30, max = 301, divisions=271, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'inicio')
        # self.passo = Slider(min = 0, max = 5, divisions=51, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'passo')
        
        # self.passo_fim2 = Slider(min = 0, max = 50, divisions=50,value = 10, width=tamanho_slids-50,on_change=self.acoes_botoes_layout, data = 'passo_fim')
        # self.texto_passo_fim = Text(f'Passo_fim ({self.passo_fim2.value/10:.1f})')
        # self.passo_fim = self.passo_fim2.value/10
        self.meta = Slider_new('Meta',30, 300, 270, 1,0, width = 200, on_change = self.acoes_botoes_layout, data = 'meta',value = 170, )
        self.inicio = Slider_new('Início',30, 300, 270, 1,0, width = 200, on_change = self.acoes_botoes_layout, data = 'inicio',value = 90, )
        self.passo = Slider_new('passo',0, 50, 50, 0.1,1, width = 200, on_change = self.acoes_botoes_layout, data = 'passo',value = 1, )
        self.passo_fim = Slider_new('Passo_fim',0, 50, 50, 0.1,1, width = 200, on_change = self.acoes_botoes_layout, data = 'passo_fim',value = 0, )




        # self.intervalo  =  Slider(min = 1, max = 30, divisions=31, label='{value}', width=300,on_change=self.acoes_botoes_layout, data = 'intervalo')
        self.intervalo  =  Slider_new('',1, 30, 50, 1,1, width = 300, on_change = self.acoes_botoes_layout, data = 'intervalo',value = 1, )
        self.tempo = Checkbox(on_change=self.acoes_botoes_layout, data = 'tempo', value  = False)
        self.Tipo_compasso = Drop_new(['2/4', '3/4', '4/4'], '4/4',
                                      on_change=self.acoes_botoes_layout, data = 'Tipo_compasso'
                                      )
        self.qtd_compassos = Drop_new([i for i in range(1,48)], 1,
                                      on_change=self.acoes_botoes_layout, data = 'qtd_compassos'
                                      )
        self.tempo_compasso = 'Tempo'

        self.continuar = Checkbox(on_change=self.acoes_botoes_layout, data = 'continuar', value = False)
        self.pomodoro_habilitado = Checkbox(on_change=self.acoes_botoes_layout, data = 'pomodoro_habilitado', value = True)
        self.tempo_pomodoro = Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 0.1,
                                       on_change=self.acoes_botoes_layout, data = 'tempo_pomodoro'
                                       )
        self.tempo_descanso = Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 0.5,
                                       on_change=self.acoes_botoes_layout, data = 'tempo_descanso'
                                       )        

        self.task_lis_select = Dropdown(                
            alignment= Alignment(-1, 1),
            options=[dropdown.Option(i) for i in self.arquiv.keys()],
            text_size = 20,
            border_color=colors.with_opacity(0.0,'white'),
            value = 'Padrão',
            color = colors.with_opacity(1,'white'),
            height = 30,
            expand= 1,
            content_padding = 0,
            autofocus = 0,
            on_change=self.acoes_botoes_layout, data = 'task_lis_select'

        )
        self.new_list_task = TextField(hint_text = 'nome da nova lista de tarefas', width = 150, expand= 1,)
        self.add_new_list_tasks = ElevatedButton(text='Add.', width = 80,on_click=self.acoes_botoes_layout, data = 'add new list task')

        tamanho_botao = 180
        self.play = IconButton(icon=icons.PLAY_ARROW, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'play')
        self.pause = IconButton(icon=icons.PAUSE, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'pause')
        self.stop = IconButton(icon=icons.STOP, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'stop')
        self.salvar = IconButton(icon=icons.SAVE, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'salvar')
        
        self.quado_saida = Container(width=775,height = 120, border= border.all(1, color = 'white'),)
        # self.quado_saida = Quadro_assync(width=775,height = 120)
        # self.quado_saida = Container(content = Countdown(40, 'Volte a treinar por '), width=775,height = 120, border= border.all(1, color = 'white'),)
        

        self.add_tarefa = OutlinedButton('Add tarefa', on_click=self.acoes_botoes_layout, data = 'add new task')
        self.play_tarefas = OutlinedButton('Play Tarefas',on_click=self.acoes_botoes_layout, data = 'Play Tarefas')

    def build(self):
        menu_bar = Row([
            self.Importar,
            self.Exportar,
            self.Selecionar_planilha,
        ], height=18)        
        quadro_bpm = Container(Row([
            self.Bot_m1, 
            self.Bot_m5, 
            self.Bot_m10, 
            self.display_bpm,
            self.Bot_m_1, 
            self.Bot_m_5, 
            self.Bot_m_10,
        ], alignment=MainAxisAlignment.SPACE_AROUND),border= border.all(1, color = 'white'),)  


        vol = Row([Text('Vol'),self.vol],spacing=0,)
        inverter = Row([self.inverter, Text('Inverter')], spacing=0)
        Treino_habilitado= Row([self.Treino_habilitado , Text('Treino_habilitado')], spacing=0)        
        tap = Row([Text('Tap'),self.Tap], spacing=0)   
        quadro_vol = Container(Row([vol, inverter, Treino_habilitado, tap], alignment=MainAxisAlignment.SPACE_AROUND),border= border.all(1, color = 'white'))
        
        
        tamanho_slids = 300
        meta  =  Row([Text('Meta'),self.meta],spacing=0,)
        inicio  =  Row([Text('Inicio'),self.inicio],spacing=0,)
        passo  =  Row([Text('Passo'),self.passo],spacing=0,)

        col_trainamento = Container(Column([self.meta, self.inicio, self.passo,  self.passo_fim], spacing=0),height=200)


        intervalo = Row([Text('Intervalo'),self.intervalo],spacing=0,)
        tempo = Row([self.tempo, Text('Tempo (min)')], spacing=0)
        Tipo_compasso = Row([Text('Tipo de Compasso'),self.Tipo_compasso])
        qtd_compassos = Row([Text('Qtd de Compasso'),self.qtd_compassos])

        self.tab_compassos = Container(Row([Tabs(
            selected_index=0,
            animation_duration=300,
            tabs=[
                Tab(
                    text="Tempo",
                    content=Column([intervalo, tempo])
                ),
                Tab(
                    text="Compassos",
                    # tab_content=Icon(icons.SEARCH),
                    content=Column([Tipo_compasso, qtd_compassos])
                ),
            ],
            width=350,
            height=200,
            on_change = self.acoes_botoes_layout,
            data = 'tempo_compasso',
            # expand=1,
            )
            ]),
            expand = 0,
        )
    

        quadro_trainamento = Container(Row([col_trainamento,Container(width = 1,bgcolor='white', height=220, expand=0),self.tab_compassos],alignment=MainAxisAlignment.SPACE_AROUND),border= border.all(1, color = 'white'))

        Treinamento = Container(Column([quadro_bpm,Row([self.task_lis_select, self.new_list_task, self.add_new_list_tasks],height= 35,alignment=MainAxisAlignment.SPACE_BETWEEN),quadro_vol,quadro_trainamento]),border= border.all(1, color = 'white'),)
        # Treinamento = Quadro_assync(Column([quadro_bpm,Row([self.task_lis_select, self.new_list_task, self.add_new_list_tasks],height= 35,alignment=MainAxisAlignment.SPACE_BETWEEN),quadro_vol,quadro_trainamento]))
   

        quadro_botoes = [self.play, self.pause, self.stop, self.salvar]
        quadro_botoes = [Quadro(i, bgcolor = '#888888') for i in quadro_botoes]
        quadro_botoes = Quadro(Row(quadro_botoes,alignment=MainAxisAlignment.SPACE_AROUND))


        botos_tarefas = Row([self.add_tarefa, self.play_tarefas], alignment=MainAxisAlignment.SPACE_AROUND)
        titulos_tarefas = Row([
            VerticalDivider(width=120),
            Text('Treino'),
            VerticalDivider(width=120),
            Text('Duração'),
            VerticalDivider(width=40),
            Text('In'),
            VerticalDivider(width=40),
            Text('Fim'),
            VerticalDivider(width=40),
            Text('Passo'),                                                   
        ])
        
        self.col_tarefas.scroll = ScrollMode.ALWAYS
        Tarefass = Column([
            Container(Row([self.task_lis_select, self.new_list_task, self.add_new_list_tasks],height= 35,alignment=MainAxisAlignment.SPACE_BETWEEN)),
            botos_tarefas,
            titulos_tarefas, 
            Container(self.col_tarefas,
            alignment=Alignment(-1,-1),
            border= border.all(1, color = 'white'),
            height= 305,
        )
                            ], height=350, expand=0)       
        # Tarefass.scroll = ScrollMode.ALWAYS

        # for i in range(3):
        #     t1 = New_task(self.acoes_tasks)
        #     self.col_tarefas.controls.append(t1)
        # for i in self.arquiv['Padrão']:
        #      print(i.values())
                
        for i in self.arquiv['Padrão']:
            t1 = New_task(self.acoes_tasks)
            valor = list(i.values())
            t1.nome_tarefa.value = valor[0]
            t1.duracao_tarefa.value = valor[1]
            t1.inicio_tarefa.value = valor[2]
            t1.fim_tarefa.value = valor[3]
            t1.passo_tarefa.value = valor[4]
            self.col_tarefas.controls.append(t1)



        
        modos = Tabs(
            selected_index=0,
            animation_duration=300,
            tabs=[
                Tab(
                    text="Treinamento",
                    content=Treinamento
                ),
                Tab(
                    text="Tarefas",
                    # tab_content=Icon(icons.SEARCH),
                    content=Tarefass
                ),
            ],
            width=self.page.window_width-5,
            height=430,
            data = 'modos',
            on_change=self.acoes_botoes_layout,
            # expand=1,
            )

        continuar = Row([self.continuar, Text('Continuar')], spacing=0)
        pomodoro = Row([self.pomodoro_habilitado, Text('Pomodoro'),Quadro(self.tempo_pomodoro) ], spacing=0)
        descanso = Row([Text('Descanso'),Quadro(self.tempo_descanso) ], spacing=0)
        quadro_pomodoro = Quadro(Row([continuar, pomodoro, descanso],alignment=MainAxisAlignment.SPACE_AROUND))
    
        return Column([
            menu_bar,
            modos,
            quadro_pomodoro,
            quadro_botoes, 
            self.quado_saida,
        ])

    def Iniciar_arquiv(self):

        # {
        #             'nome':[],
        #             'duração':[],
        #             'bmp_ini':[],
        #             'bpm_fim':[],
        #             'passo':[]
        try:
            self.arquiv = Ler_json(config)
        except:
            self.arquiv = {
                'Padrão':[],
                'música 1':None,
                'música 2':None
            }
            Escrever_json(self.arquiv, config)

    async def Salvar_cofig(self):
        pass

        p = []
        for i in self.col_tarefas.controls:
            chaves = ['nome', 'duração', 'bmp_ini', 'bpm_fim', 'passo']
            l = [i.nome_tarefa.value,i.duracao_tarefa.value,i.inicio_tarefa.value , i.fim_tarefa.value, i.passo_tarefa.value]
            d = {k:j for j,k in zip(l, chaves)}
            p.append(d)
            # self.arquiv['Padrão']['nome'].append(i.nome_tarefa.value)
            # self.arquiv['Padrão']['duração'].append(i.duracao_tarefa.value)  
            # self.arquiv['Padrão']['bmp_ini'].append(i.inicio_tarefa.value)  
            # self.arquiv['Padrão']['bpm_fim'].append(i.fim_tarefa.value)  
            # self.arquiv['Padrão']['passo'].append(i.passo_tarefa.value)  
        self.arquiv = Ler_json(config)
        nome_tarefa = self.task_lis_select.value

        self.arquiv[nome_tarefa] = p
        Escrever_json(self.arquiv, config)
        
    async def acoes_tasks(self, task,e):
        data = e.control.data
        t = task
        match data:
            case 'del':
                self.col_tarefas.controls.remove(task)
            case 'play tarefa':
                print('Apertou play')
                # print(task.nome_tarefa.value)
                # self.Exibir_atributos(task.nome_tarefa)
                def Ler_parametros_tarefas():
                    self.Metro_normal.nome_treino = task.nome_tarefa.value
                    self.Metro_normal.t_total = task.duracao_tarefa.value
                    self.Metro_normal.meta = task.fim_tarefa.value
                    self.Metro_normal.inicio = task.inicio_tarefa.value
                    self.Metro_normal.passo = task.passo_tarefa.value             
                    self.Metro_normal.pomodoro_habilitado = self.pomodoro_habilitado.value
                    self.Metro_normal.tempo_descanso = int(self.tempo_descanso.value)
                    self.Metro_normal.tempo_pomodoro = float(self.tempo_pomodoro.value)
                    self.Metro_normal.tempo_compasso = 'Tempo'
                    # self.Metro_normal.treino_habilitado = True
                # Thread(target=self.check_display, daemon=False).start()
                # self.Metro_normal.Play() 
                # self.tempo_compasso
                if self.Metro_normal.metronomo_inciado:
                    self.Metro_normal.Stop()
                    self.quado_saida.content = None
                    e.control.bgcolor = None

                else:
                    self.Metro_normal.Stop()
                    self.Metro_normal = None
                    self.Metro_normal = Metronomo_Control_flet()
                    Ler_parametros_tarefas()
                    # for i in self.col_tarefas.controls:
                    #     if i  == task:
                    #         i.play_parefa.bgcolor = 'red'
                    #         print('achou')
                    #         await super().update_async()
                    # e.control.bgcolor = 'red'
                    # await super().update_async()
                    await self.Play2(tarefas = True) 
                    # print(task.controls)
            case 'pause tarefa':
                self.quado_saida.content.pause = not self.quado_saida.content.pause 
                self.Metro_normal.Pause()


        await super().update_async()
        print('ação recebida',data )

    async def Att(self):
        await super().update_async()
    # def Att(self):
    #     super().update()        
    def up_bpm(self, bpm):        
        new_bpm = self.display_bpm.value + bpm
        if new_bpm <=30:
            new_bpm = 30
        elif  new_bpm>549:
            new_bpm = 549
        # print(new_bpm)
        # print(type(new_bpm))
        # print('tipo self.Metro_normal.setBpm(new_bpm) = ', type(self.Metro_normal.setBpm(new_bpm)))    
        self.display_bpm.value = new_bpm
        self.Metro_normal.setBpm(new_bpm)

    async def acoes_botoes_layout(self, e, task = ''):
        # self.Exibir_atributos(e.data)
        # print(e.data)
        try:
            data = e.control.data
        except:
            data = e.data        

        match data:                    
            case 'Importar':
                print('tempo_pomodoro alterado')
            case 'Exportar':
                print('tempo_pomodoro alterado')
            case 'Selecionar Planilha':
                print('tempo_pomodoro alterado')
            case 'Bot_m1':
                print('+1')
                self.up_bpm(1)


            case 'Bot_m5':
                self.up_bpm(5)
            case 'Bot_m10':
                self.up_bpm(10)
            case 'Bot_m_1':
                self.up_bpm(-1)
            case 'Bot_m_5':
                self.up_bpm(-5)
            case 'Bot_m_10':
                self.up_bpm(-10)
            case 'valorbpm':
                self.Metro_normal.setBpm(self.display_bpm.value)
            case 'vol':
               self.Metro_normal.setVolume(e.control.value/10)
            case 'Inverter':
                print('tempo_pomodoro alterado') 
            case 'Treino_habilitado':
                print('tempo_pomodoro alterado')
            case 'Tap':
                print('tempo_pomodoro alterado')
            case 'meta':
                print('meta = ', self.meta.value)
            case 'inicio':
                print('inicio = ', self.inicio.value)
            case 'passo':
                print('passo = ', self.passo.value)
            case 'passo_fim':
                # self.passo_fim = self.passo_fim2.value/10
                # self.texto_passo_fim.value = f'Passo_fim ({self.passo_fim2.value/10:.1f})'
                print('passo_fim = ',self.passo_fim.value)


            case 'intervalo':
                print('tempo_pomodoro alterado')
            case 'tempo':
                print('tempo_pomodoro alterado')
            case 'Tipo_compasso':
                print('tempo_pomodoro alterado')
            case 'qtd_compassos':
                print('tempo_pomodoro alterado')
            case 'continuar':
                print('tempo_pomodoro alterado')
            case 'pomodoro_habilitado':
                # self.pomodoro_habilitado.value = True
                print('pomodoro habilitado alterado')
            case 'tempo_pomodoro':
                print('tempo_pomodoro alterado')
            case 'tempo_descanso':
                print('tempo_pomodoro alterado')
            case 'task_lis_select':
                tarefa = e.control.value
                # print(self.arquiv[tarefa])
                if type(self.arquiv[tarefa]) == list:
                    if len(self.arquiv[tarefa]) >0:
                        self.col_tarefas.controls = None
                        for i in self.arquiv[tarefa]:
                            t1 = New_task(self.acoes_tasks)
                            valor = list(i.values())
                            t1.nome_tarefa.value = valor[0]
                            t1.duracao_tarefa.value = valor[1]
                            t1.inicio_tarefa.value = valor[2]
                            t1.fim_tarefa.value = valor[3]
                            t1.passo_tarefa.value = valor[4]
                            self.col_tarefas.controls.append(t1)
            case 'play':
                # print(e.control)
                self.Metro_normal.setBpm(self.display_bpm.value)
                if self.metronomo_iniciado:
                    self.Stop()
                    self.quado_saida.content = None

                else:
                    self.Stop()
                    self.Metro_normal = None
                    self.Metro_normal = Metronomo()
                    # await self.Play2() 
                    self.Read_values()
                    tempo = float(self.tempo_pomodoro.value)
                    # print('tempo = ', tempo, 'tipo:', type(tempo))
                    self.quado_saida.content =  Countdown(tempo, 'Treine durante ')
                    # print(self.pomodoro_habilitado.value)


                    if self.tempo_compasso == 'Tempo' and self.Treino_habilitado.value:
                        self.tipo_de_treino = 'treinamento'                        
                        await asyncio.gather(self.Ini_Thread('pomodoro'), self.Ini_Thread('beep'), self.Ini_Thread('Treinamento'))

                    elif self.tempo_compasso == 'Compassos' and self.Treino_habilitado.value:
                        self.tipo_de_treino = 'compassos'                        
                        await asyncio.gather(self.Ini_Thread('pomodoro'), self.Ini_Thread('beep'), self.Ini_Thread('compassos'))
                    else:
                        await asyncio.gather(self.Ini_Thread('pomodoro'), self.Ini_Thread('beep'))




    
                # for i in self.__dict__.keys():
                #     print(i)
            case 'add new list task':                
                self.task_lis_select.options.append(dropdown.Option(self.new_list_task.value))
            case 'pause':
                # self.pause_lay = not self.pause_lay

                if self.quado_saida.content != None and not self.Treino_habilitado:
                    self.quado_saida.content.pause = not self.quado_saida.content.pause 
                self.Pausar()
            case 'stop':
                self.Stop()
                self.quado_saida.content = None
                self.Metro_normal = None
                self.Metro_normal = Metronomo() 
            case 'salvar':
                await self.Salvar_cofig()
            case 'add new task':
                self.col_tarefas.controls.append(New_task(self.acoes_tasks)) 
                print('add tarefa')
            case 'Play Tarefas':
                print('tempo_pomodoro alterado')
            case 'tempo_compasso':
                match e.data:
                    case 0:
                        self.tempo_compasso = 'Tempo'
                    case 1:
                        self.tempo_compasso = 'Compassos'
            case 'modos':
                # print(e.data)
                match e.data:
                    case 0:
                        self.Modo = 'normal'
                    case 1:
                        self.Modo = 'tarefas'

        await super().update_async() 


    async def Respiro(self):
        descan = int(self.tempo_descanso.value*60/19.4)
        print(descan)
        # self.Metro_normal.pause = False
        self.parar = False
        width_max = 740
        respiro = Container(content=Text(),bgcolor= colors.YELLOW,width = 0, border_radius=40)
        def Inspire(d):
            # self.quado_saida.content = Text(f'INSPIRE ({d})')
            s = Saidas(f'INSPIRE ({d})')
            # s.saida_tempo_de_treino.visible = True
            s.saida_tempo_de_treino.controls[0].size = 50
            s.saida_tempo_de_treino.controls[0].color = colors.YELLOW
            self.quado_saida.content = Column([s, respiro])
            self.quado_saida.content.alignment= MainAxisAlignment.CENTER

        def Expire(d):
            s = Saidas(f'EXPIRE  ({d})')
            # s.saida_tempo_de_treino.visible = True
            s.saida_tempo_de_treino.controls[0].size = 50            
            s.saida_tempo_de_treino.controls[0].color = colors.GREEN
            self.quado_saida.content = Column([s, respiro])
            self.quado_saida.content.alignment= MainAxisAlignment.CENTER


        for d in range(descan,0,-1):
            a = time()
            Inspire(d)
            await super().update_async()
            for i in range(0,width_max,6):
                respiro.width = i
                await asyncio.sleep(0.001)
                if self.parar:
                    break
                await super().update_async()
            respiro.bgcolor = colors.GREEN
            Expire(d)
            await super().update_async()
            for i in range(width_max,0,-1):
                respiro.width = i
                if self.parar:
                    break                    
                await asyncio.sleep(0.01567)
                await super().update_async()
            respiro.bgcolor = colors.YELLOW
            b = time()-a
            print(b)

        # self.Metro_normal.contando = False
        self.quado_saida.content = None
        respiro.width = 0
        await super().update_async()
   

    def Exibir_atributos(self, objeto):
        for i in objeto.__dict__.keys():
            print(i) 

    # def tempo_compasso(self,e):
    #     print(e.control.data)

    def Read_values(self, tarefas=False):
        # self.Metro_normal.pomodoro_habilitado = self.pomodoro_habilitado.value
        # self.Metro_normal.tempo_pomodoro = self.tempo_pomodoro.value
        # self.Metro_normal.tempo_descanso = self.tempo_descanso.value
        # self.Metro_normal.treino_habilitado = self.Treino_habilitado.value
        # print(f'self.Metro_normal.treino_habilitado = {self.Metro_normal.treino_habilitado}')
        # self.Metro_normal.continuar = self.continuar.value
        self.Metro_normal.setVolume(self.vol.value/10)
        # self.Metro_normal.tempo_compasso = 
        self.Metro_normal.setBpm(self.display_bpm.value)

        if not tarefas:
            # self.Metro_normal.inverter = self.Inverter.value
            # self.Metro_normal.meta = self.meta.value
            # self.Metro_normal.inicio = self.inicio.value
            # self.Metro_normal.passo = self.passo.value
            # self.Metro_normal.passo_fim = self.passo_fim.value
            # self.Metro_normal.tempo = self.tempo.value
            # if self.Metro_normal.tempo:
                # self.Metro_normal.t_total = 60*self.intervalo.value
            # else:
                # self.Metro_normal.intervalo = self.intervalo.value
                # self.Metro_normal.t_total = None

            # self.Metro_normal.qtd_compassos = self.qtd_compassos.value
            # self.Metro_normal.tipo_compasso = self.Tipo_compasso.value

            if self.Tipo_compasso == '2/4':
                self.Tipo_compasso = 2
            elif self.Tipo_compasso == '3/4':
                self.Tipo_compasso = 3
            elif self.Tipo_compasso == '4/4':
                self.Tipo_compasso = 4
            else:
                self.Tipo_compasso = 4

        # else:
        #     # self.Metro_normal.n_treino = self.Metro_normal.event[6:]
        #     # self.Metro_normal.nome_treino = 
        #     self.Metro_normal.nome_planilha = self.Selecionar_planilha.value
        #     self.Metro_normal.t_total = 60*Ler(f'-DR-{self.Metro_normal.n_treino}-', 'float', 1)  # duração
        #     # print(f'self.tempo_restante = {self.Metro_normal.t_total}')
        #     self.Metro_normal.meta = self.meta.value
        #     self.Metro_normal.inicio = self.inicio.value
        #     self.Metro_normal.passo = self.passo.value



        if self.meta == -100 or self.inicio == -100 or self.passo == -1 or self.passo_fim == 0:
            self.progressivo = False
            if self.t_total == None:
                self.t_total = self.intervalo
        else:
            self.progressivo = True

    async def Play2(self, e='', tarefas = False):
        self.Read_values(tarefas)
        # Thread(target=self.check_display, daemon=False).start()
        tempo = float(self.tempo_pomodoro.value)
        print('tempo = ', tempo, 'tipo:', type(tempo))
        self.quado_saida.content =  Countdown(tempo, 'Volte a treinar por ')
        
        if tarefas:
            self.Metro_normal.Play_tarefas()   
        else:
            self.Metro_normal.Play()
        await super().update_async()

    async def Ini_Thread(self, controle, argu=''):
        if controle == 'pomodoro':
            self.Metro_normal.setOn = False
            # await asyncio.sleep(0.3)
            self.Metro_normal.setOn = True
            if self.pomodoro_habilitado.value:
                print('self.tempo_pomodoro:', (self.tempo_pomodoro.value), (self.tempo_descanso.value))
                if self.tempo_pomodoro.value != '' and self.tempo_descanso.value != '':
                    try:
                        self.tempo_pomodoro.value, self.tempo_descanso.value = float(
                            self.tempo_pomodoro.value), float(self.tempo_descanso.value)
                    except TypeError:
                        print('Erro na conversão dos tempo_pomodoro e tempo_descanso', TypeError)
                        self.tempo_pomodoro.value, self.tempo_descanso.value = 3, 1
                    # Thread(target=self.Pomodoro, daemon=False).start()#########################################
                    await self.Pomodoro()
            else:
                print('pomodoro desabilitado')

        elif controle == 'beep':
            if not self.metronomo_inciado:
                Thread(target=self.Metro_normal.beep, daemon=False).start()
                self.metronomo_inciado = True
            else:
                print('metronomo já iniciado')

        elif controle == 'Treinamento':
            await self.Treinar()
            # print('vai reinar')
            if self.passo_fim.value < self.passo.value or self.passo.value == -1:
                if self.metronomo_inciado:
                    if not self.treinando:
                        self.treinando = True
                        # Thread(target=self.Treinamento, args=argu, daemon=False).start()
                        await self.Treinamento(argu)

        elif controle == 'Executar tarefas':
            await self.Treinar()
            if not self.treinando:
                self.treinando = True
                Thread(target=self.Executar_tarefas,
                    args=argu, daemon=False).start()

            else:
                raise ValueError(
                    "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")

        elif controle == 'compassos':
            await self.Treinar()
            if self.passo_fim < self.passo:
                if self.metronomo_inciado:
                    if not self.treinando:
                        self.treinando = True
                        Thread(target=self.Treinamento_compassos,
                            daemon=False).start()

            else:
                # raise ValueError(
                #     "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")
                self.Prints(
                    "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")


    async def Treinamento(self, tarefa_exec=''):
        print('Treino iniciado...')
        # print(f'tarefa_exec = {tarefa_exec}')

        # print(f'dist_passo = {dist_passo} \npasso = {self.passo} \nbpm = {bpm}\n')
        def Finalizacao_treino():
            self.quado_saida.content = Text('Treino Finalizado...')
            # self.Piscar_infos
            self.EscreveTxt(tarefa_exec)
            # self.EscrevePlanilha(tarefa_exec)
            self.quado_saida.content = None

        ii = 0
        self.tempo_restante = float(self.t_total)

        if tarefa_exec == '':
            tarefa_exec = f'{Data()} .-. {"sem nome"} .-. {round(self.tempo_restante/60,1)}min .-. BPM({self.inicio} a  ) .-. passo:   .-. intervalo:  s'

        if self.progressivo:
            while (teste := (bpm := self.Metro_normal.getBpm) > self.meta2 if self.inverter.value else (bpm := self.Metro_normal.getBpm) < self.meta2):
                await self.Exibir_tempo_restante()
                await asyncio.sleep(self.intervalo.value)
                self.tempo_restante -= self.intervalo.value

                ii = self.Variador_de_passo(bpm, ii)
                self.up_bpm(self.passo.value)
                # await super().update_async()

                # Para caso o de o botão pause ser pressionado
                while self.Metro_normal.pause:
                    await asyncio.sleep(0.1)

                # Para caso o de o botão Stop ser pressionado
                if self.treinando == False or self.Treino_habilitado.value == False or self.tempo_restante <= 0:
                    break

            # para quando a bpm passa da meta
            if (teste2 := bpm < self.meta2 if self.inverter.value else bpm > self.meta2):
                self.up_bpm(self.meta2)
                bpm = self.meta2

            if bpm == self.meta2 or self.tempo_restante == 0:
                MessageBeep(MB_ICONHAND)

        else:
            while self.tempo_restante >= 0:
                self.Exibir_tempo_restante()
                await asyncio.sleep(1)
                self.tempo_restante -= 1
                while self.pause:
                    await asyncio.sleep(0.1)
                if self.treinando == False or self.Treino_habilitado.value == False or self.tempo_restante <= 0:
                    break

            if self.tempo_restante == 0:
                MessageBeep(MB_ICONHAND)

        Thread(target=Finalizacao_treino, daemon=True).start()
        self.Testar_continuidade()

    def Testar_continuidade(self):
        if self.continuar.value == False and not self.play_tarefas:
            self.pomodoro_habilitado.value = False
            self.treinando = False
            self.Metro_normal.setOn = False
            self.quado_saida.content = None
        elif self.play_tarefas:
            # self.pomodoro_habilitado = False
            self.treinando = False
            self.Metro_normal.setOn = False
        # self.Restaurar_cores
        self.metronomo_inciado = False

    def Variador_de_passo(self, bpm, ii):
        if self.dist_passo != 0:
            if ii >= 3:
                if bpm >= self.incrementos[ii]:
                    self.passo = self.passo_fim
                    self.tempo_restante = int(
                        self.constante_de_tempo/self.passo)
                    print(f'passou dos {self.x[ii]*100}% da meta')

            elif bpm >= self.incrementos[ii] and bpm < self.incrementos[ii+1]:
                self.passo = self.passo_fim + \
                    (1-self.x[ii])*self.dist_passo
                self.tempo_restante = int(
                    ((self.meta - bpm)*self.intervalo)/self.passo)
                print(f'passou dos {self.x[ii]*100}% da meta')
                ii += 1
        return ii
    
    async def Exibir_tempo_restante(self):
        horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(self.tempo_restante)
        self.quado_saida.content = Text(f"Tempo restante: {horas2}:{minutos2}:{segundos2}")
        await super().update_async()

    @classmethod    
    @property
    def nometarefastxt(self):
        return Juntar(getcwd(), 'tarefas.txt')
    @classmethod    
    def EscreveTxt(self, texto):
        try:
            with open(self.nometarefastxt, 'a') as arq:
                arq.write(f'{texto}\n')
        except:
            with open(self.nometarefastxt, 'w') as arq:
                arq.write(f'{texto}\n')
        print(f'A tarefa foi salva em {self.nometarefastxt}')

    def EscrevePlanilha(self, texto):
        # texto = f'11-10-2023-14:56:53 .-. Estágio 3 .-. 5min .-. BPM(140 a 150) .-. passo: 0.1 .-. intervalo: 3.0s'
        # print(texto)
        b = texto.split(' .-. ')
        d, m, y = b[0].split('-')[:3]
        h = b[0].split('-')[3]
        data = f'{d}/{m}/{y} {h}'
        nome = b[1]
        duracao = b[2][:-3]

        # if self.progressivo:    # or nome == 'sem nome'
        try:
            resultado = search(r'BPM\((\d+) a (\d+)\)', b[3])
            print(f'resultado = {resultado}')
            bpm_in = resultado.group(1)
            bpm_fim = resultado.group(2)
            passo = b[4][7:]
            intervalo = b[5][10:-1]
        except:
            resultado = search(r'BPM\((\d+(\.\d+)?) a', b[3])
            print(f'resultado = {resultado}')
            bpm_in = resultado.group(1).split('.')[0]
            bpm_fim = ''
            passo = ''
            intervalo = ''

        valores = [[data, nome, duracao, bpm_in, bpm_fim, passo, intervalo]]

        n_linhas = 1+len(p := LerCelulas(self.nome_planilha,
                         'metronomo!A:h', nome_da_credencial))
        AtualizarCelulas(
            self.Selecionar_planilha.value, f'metronomo!A{n_linhas}:h', valores, nome_da_credencial)


    # def Contador_sincrono(self, minutos, texto):
    #     segundos = 60*minutos
    #     while segundos >= 0:
    #         h, mins = divmod(segundos, 60*60)
    #         mins, secs = divmod(mins, 60)
    #         h, mins, secs = int(h), int(mins), int(secs)
    #         if texto != '':
    #             contador = "{:s} {:02d}:{:02d}:{:02d}".format(self.texto,h, mins, secs)
    #         else:
    #             contador = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)

    #         self.update_async()
    #         await asyncio.sleep(1)
    #         segundos -= 1
    #         while self.pause:
    #             await asyncio.sleep(0.3)


    
    @classmethod
    def converter_segundos_para_horas_min_segundos(self, segundos):
        def Algarismos(numero, qtd=2):
            numero = int(numero)
            return str(numero).zfill(qtd)
        horas = segundos // 3600  # 3600 segundos em uma hora
        horas = Algarismos(horas)
        segundos %= 3600
        minutos = segundos // 60  # 60 segundos em um minuto
        minutos = Algarismos(minutos)
        segundos %= 60
        segundos = Algarismos(segundos)

        return horas, minutos, segundos
    
    async def Treinar(self):
        if self.progressivo:
            if not self.tempo.value:
                # print('self.meta.value:', type(self.meta.value), self.meta.value)
                # print('self.inicio.value:', type(self.inicio.value), self.inicio.value)
                # print('self.passo.value:', type(self.passo.value), self.passo.value)
                # print('self.intervalo.value:', type(self.intervalo.value), self.intervalo.value)
                self.tempo_de_treino = int(((self.meta.value - self.inicio.value)/self.passo.value)*self.intervalo.value)
                self.t_total = self.tempo_de_treino
                horas, minutos, segundos = self.converter_segundos_para_horas_min_segundos(self.tempo_de_treino)
                self.quado_saida.content = Text(f"Duração do treino: {horas}:{minutos}:{segundos}")


            else:

                self.intervalo = round((self.t_total*self.passo.value)/(self.meta.value - self.inicio.value), 3)
                horas, minutos, segundos = self.converter_segundos_para_horas_min_segundos(self.t_total)
                self.quado_saida.content = Text(f"Duração do treino: {horas}:{minutos}:{segundos}")

            if self.inverter.value:
                self.Metro_normal.setBpm(self.meta.value)
                self.display_bpm.value = self.meta.value
                self.meta2 = self.inicio.value
                self.passo2 = -1*self.passo.value

            else:
                self.Metro_normal.setBpm(self.inicio.value)
                self.display_bpm.value = self.inicio.value
                self.meta2 = self.meta.value


            if not self.inverter.value and self.passo_fim.value not in [0, '', None]:
                distancia_bpm = self.meta.value - self.inicio.value
                self.dist_passo = self.passo.value - self.passo_fim.value
                self.constante_de_tempo = ((self.meta.value - self.inicio.value)*self.intervalo.value)
                self.x = [0.25, 0.5, 0.75, 0.9, 1]
                self.incrementos = [y*distancia_bpm +  self.inicio for y in self.x]
                ii = 0

            else:
                self.dist_passo = 0

        else:
            self.Metro_normal.setBpm(self.inicio.value)
            self.display_bpm.value = self.inicio.value
        
        await super().update_async()


    def Pausar(self):
        self.Metro_normal.pause = not self.Metro_normal.pause

    async def Pomodoro(self):
        self.quado_saida.content =  Countdown('', 'Pomodoro inciado...')
        texto = 'Pomodoro inciado...'
        while self.pomodoro_habilitado.value:
            # self.quado_saida.content =  Countdown(self.tempo_pomodoro.value, 'Pomodoro inciado...')
            segundos = self.tempo_pomodoro.value*60
            while segundos >= 0:
                h, mins = divmod(segundos, 60*60)
                mins, secs = divmod(mins, 60)
                h, mins, secs = int(h), int(mins), int(secs)
                if texto != '':
                    contador = "{:s} {:02d}:{:02d}:{:02d}".format(texto,h, mins, secs)
                else:
                    contador = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)
                self.quado_saida.content = Text(contador)
                await self.update_async()
                await asyncio.sleep(1)
                segundos -= 1
                while self.Metro_normal.pause:
                    await asyncio.sleep(0.3)


            if self.pomodoro_habilitado.value == False:
                break
            MessageBeep(MB_ICONHAND)
            self.Pausar()
            # self.quado_saida.content =  Countdown(self.tempo_descanso.value, 'Faça uma pausa de')
            
            await self.Respiro()
            
            # segundos = self.tempo_descanso.value*60
            # texto = 'Faça uma pausa de'
            # self.Metro_normal.pause = False
            # while segundos >= 0:
            #     h, mins = divmod(segundos, 60*60)
            #     mins, secs = divmod(mins, 60)
            #     h, mins, secs = int(h), int(mins), int(secs)
            #     if texto != '':
            #         contador = "{:s} {:02d}:{:02d}:{:02d}".format(texto,h, mins, secs)
            #     else:
            #         contador = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)
            #     self.quado_saida.content = Text(contador)
            #     await self.update_async()
            #     await asyncio.sleep(1)
            #     segundos -= 1
            #     while self.Metro_normal.pause:
            #         await asyncio.sleep(0.3)
            # self.Metro_normal.pause = True

            ##########################################
            # horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(
            #     self.tempo_descanso*60)
            # self.display['-tempo_pomodoro-'] = f'Faça uma pausa de {horas2}:{minutos2}:{segundos2}'
            # self.contando = True
            # Thread(target=self.Barra_de_progresso, daemon=True).start()

            if self.pomodoro_habilitado == False:
                break
            MessageBeep(MB_ICONHAND)

            # self.Contagem(self.tempo_descanso*60)
            # self.Barra2(self) #### adiocinar respiro aqui
            if self.pomodoro_habilitado == False:
                break
            self.Pausar()
            texto = 'Volte a treinor por '



        self.quado_saida.content =  None



    async def Play_tarefas(self):
        self.Ini_Thread('pomodoro')
        self.Ini_Thread('beep')
        self.Treino_habilitado.value = True
        self.inverter.value = False
        self.tempo.value = True
        self.passo_fim.value = 0
        # try:
        intervalo_bpm = round(
            (float(self.t_total)*float(self.passo))/(float(self.meta) - float(self.inicio)), 3)

        if self.metronomo_inciado:
            self.nome_treino = 'sem nome' if self.nome_treino == '' else self.nome_treino
            tarefa_exec = f'{Data()} .-. {self.nome_treino} .-. {self.t_total}min .-. BPM({self.inicio} a {self.meta}) .-. passo: {self.passo} .-. intervalo: {intervalo_bpm}s'
            self.Ini_Thread('Treinamento', [(tarefa_exec)])

    def Stop(self):
        self.Metro_normal.setOn = False
        self.treinando = False
        # self.pomodoro_habilitado.value = False
        self.treinando_compassos = False
        self.metronomo_inciado = False
        self.parar = True  


    async def Teclas(self, e: KeyboardEvent):
        if self.Modo == 'normal':
            match e.key:
                case ' ':

                    self.Metro_normal.setBpm(self.display_bpm.value)
                    if self.metronomo_iniciado:
                        self.Stop()
                        self.quado_saida.content = None

                    else:
                        self.Stop()
                        self.Metro_normal = None
                        self.Metro_normal = Metronomo()
                        # await self.Play2() 
                        self.Read_values()
                        tempo = float(self.tempo_pomodoro.value)
                        # print('tempo = ', tempo, 'tipo:', type(tempo))
                        self.quado_saida.content =  Countdown(tempo, 'Treine durante ')
                        # print(self.pomodoro_habilitado.value)


                        if self.tempo_compasso == 'Tempo' and self.Treino_habilitado.value:
                            self.tipo_de_treino = 'treinamento'                        
                            await asyncio.gather(self.Ini_Thread('pomodoro'), self.Ini_Thread('beep'), self.Ini_Thread('Treinamento'))

                        elif self.tempo_compasso == 'Compassos' and self.Treino_habilitado.value:
                            self.tipo_de_treino = 'compassos'                        
                            await asyncio.gather(self.Ini_Thread('pomodoro'), self.Ini_Thread('beep'), self.Ini_Thread('compassos'))
                        else:
                            await asyncio.gather(self.Ini_Thread('pomodoro'), self.Ini_Thread('beep'))

              
                    print('pressionou space') 
                case 'Enter':
                    self.Metro_normal.Stop()            
                    print('pressionou enter')
                case 'P':
                    self.Metro_normal.Pause()               
                    print('pressionou P')
                case 'Numpad 7':
                    self.up_bpm(1)
                case 'Numpad 8':
                    self.up_bpm(5)                 
   
                case 'Numpad 9':
                    self.up_bpm(10)                  

                case 'Numpad 1':
                    self.up_bpm(-1)                  
                case 'Numpad 2':
                    self.up_bpm(-5)                    
   
                case 'Numpad 3':
                    self.up_bpm(-10)                   
 
                case 'Numpad 5':
                    self.Tap

                # case 'Numpad 4':
                #     self.check_display()                                                                                         
   
        await super().update_async()




    
def main(page: Page):
    page.title = "Exemplo Layout"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = '#000000', #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750
    
    # layout = Quadro(page, 
    #                 width = page.window_width-1,
    #                 height= page.window_height-55,  
    #                 border_color = 'white',
    # )
    # layout.contet = Column(Text('kjhkjhkj', size = 200, color='white'))
    def Exibir_atributos(objeto):
        for i in objeto.__dict__.keys():
            print(i) 
    app = Layout(page)
    # pomodoro_habilitado = Checkbox()
    # pomodoro = Row([pomodoro_habilitado, Text('Pomodoro'),Quadro(Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 1)) ], spacing=0)
    # Exibir_atributos(pomodoro.controls)  
    # print(pomodoro_habilitado.value)          
    page.add(app)
    # page.add(self.menu_bar,modos,quadro_pomodoro,quadro_botoes, quado_saida)
    # page.add(col_tarefas)

    page.update() 
# app(target=main, view=AppView.WEB_BROWSER)




async def main2(page: Page):
    page.title = "Metrônomo"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750

    app = Layout(page)
    page.on_keyboard_event = app.Teclas
    
    # page.window_focused = False
    # print(page.window_focused)

    # page.add(app)
    # page.update()

    # await page.add_async(TextButton(visible=False, autofocus=True))
    await page.add_async(app)
    await page.add_async(Countdown(40, 'Volte a treinar por '))




app(target=main2)