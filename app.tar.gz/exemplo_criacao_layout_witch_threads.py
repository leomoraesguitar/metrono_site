from flet import*
from Swhitch_new import Switch_new
from controlador_metronomo_flet import Escrever_json, Ler_json, Thread
from metronomo import Metronomo, sleep, time
from winsound import MessageBeep, MB_ICONHAND
# from saidas import Saidas
from funcoes_leo.funcoes import Data, Juntar
from os import getcwd
from re import search
from googlesheets_leo import AtualizarCelulas, LerCelulas
from pomodoro_flet import Pomodoro
import asyncio
__docformat__ = "restructuredtext"


class Countdown(UserControl):
    def __init__(self, minutos, texto = ''):
        super().__init__()
        # self.page = Page
        self.minutos = minutos
        self.segundos = 60*minutos
        self.texto = texto
        self.pause = False

    def did_mount(self):
        self.running = True
        if self.minutos != '':            
            Thread(target=self.update_timer, daemon=True).start()

        else:
            self.countdown.value = self.texto
            self.update()

    def will_unmount(self):
        self.running = False

    def update_timer(self):
        while self.segundos and self.running:
            h, mins = divmod(self.segundos, 60*60)
            mins, secs = divmod(mins, 60)
            h, mins, secs = int(h), int(mins), int(secs)
            if self.texto != '':
                self.countdown.value = "{:s} {:02d}:{:02d}:{:02d}".format(self.texto,h, mins, secs)
            else:
                self.countdown.value = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)

            self.update()
            sleep(1)
            self.segundos -= 1
            while self.pause:
                sleep(0.3)

            

    def build(self):
        self.countdown = Text()
        return self.countdown

class Quadro(UserControl):
    def __init__(self, 
                content = None,
                #  page = Page,
                 width = None, 
                 height = None,
                 expand = 0,
                 bgcolor = None,
                 border_color = 'white',
                 
                 ):
        super().__init__()
        # self.page = page
        self.content = content
        self.width = width
        self.height = height
        self.bgcolor = bgcolor
        self.border_color = border_color
        self.expand = expand
        self.bgcolor = bgcolor
    
    def build(self):
        return Container(
        content = self.content,
        alignment=Alignment(0,0),
        border= border.all(1, color = self.border_color),
        width= self.width,
        height= self.height,
        expand = self.expand,
        bgcolor = self.bgcolor
        )

class Quadro_assync(UserControl):
    def __init__(self, 
                content = None,
                 tipo = 'r', #ou 'c'
                #  page = Page,
                 width = None, 
                 height = None,
                 expand = 1,
                 bgcolor = None,
                 border_color = 'white',
                 
                 ):
        super().__init__()
        # self._page = page
        self.tipo = tipo
        self.content = content #Row(content) if self.tipo == 'r' else Column(content)
        self.width = width
        self.height = height
        self.bgcolor = bgcolor
        self.border_color = border_color
        self.expand = expand
        self.bgcolor = bgcolor
    
    def build(self):
        return Container(
        content = self.content,
        alignment=Alignment(0,0),
        border = border.all(1, color = self.border_color),
        width= self.width,
        height= self.height,
        expand = self.expand,
        bgcolor = self.bgcolor
        )


class Drop_new(UserControl):
    def __init__(self, 
        opitions = [], 
        value = None,
        width_person = None,
        on_change = None,
        data = None,

                
                ):
        super().__init__()
        self.opitions  = opitions
        self.value = value
        self.width = 30 if opitions == [] else 80
        self.on_change = on_change
        self.data = data

        if width_person != None:
            self._width = width_person         
        self._drop = Dropdown(        
                alignment= Alignment(-1, 1),
                options=[dropdown.Option(i) for i in self.opitions],
                text_size = 15,
                border_width = 0,
                border=None,
                # border_color='white',
                expand=0,
                scale=1,
                autofocus = 0,
                value = self.value,
                width = self.width,
                # aspect_ratio = 1,
                height = 40,
                dense = True,
                text_style = TextStyle(weight = 'bold'),
                on_change=self.mudou,
                                                  
        )


    def build(self):
        return self._drop
    def mudou(self, e):
        self.value = self._drop.value
        if self.on_change != None:
            self.enviar_change(e)
        super().update()
    def enviar_change(self,e):
        self.on_change(self, e)


class New_task(UserControl):
    def __init__(self,
        task_delete,
        ):
        super().__init__()
        self.task_delete = task_delete
        self.nome_tarefa = TextField(hint_text = 'nome da tarefa', width = 200)
        self.duracao_tarefa = Drop_new([0.1,0.3,0.5]+[i for i in range(1,31)], 3, width_person = 75)
        self.inicio_tarefa = Drop_new([i for i in range(30,301)], 70, width_person = 75)
        self.fim_tarefa = Drop_new([i for i in range(30,311)], 170, width_person = 75)
        self.passo_tarefa = Drop_new([0,0.1,0.3,0.5,0.7,0.9]+[i for i in range(1,20)], 3, width_person = 75)



    def build(self):
        remover_tarefa = IconButton(icon=icons.DELETE, on_click = self.clicked, data ='del')
        # tamanho_botao_acao_tarefas = 
        self.play_parefa = IconButton(icon=icons.PLAY_ARROW, on_click = self.clicked, data ='play tarefa')
        pause_parefa = IconButton(icon=icons.PAUSE, on_click = self.clicked, data ='pause tarefa')

        linha_tarefa = [
            remover_tarefa,
            self.nome_tarefa,
            self.duracao_tarefa,
            self.inicio_tarefa,
            self.fim_tarefa,
            self.passo_tarefa,
            self.play_parefa,
            pause_parefa
        ]
        linha_tarefa = Row([Quadro(i) for i in linha_tarefa], alignment='center', expand=1)
        linha_tarefa = Container(linha_tarefa, height = 50, border= border.all(1, color = 'white'))
        return linha_tarefa
    
    def clicked(self, e):
        # data = e.control.data
        # if e.control.data == 'play tarefa':
        #     e.control.bgcolor = 'red'
        #     print(e.control.bgcolor)
        # super().update_async()
        self.task_delete(self,e)

        # match data:
        #     case 'del':
        #         self.task_delete(self)
        #     case 'play tarefa':
        #         pass
        #     case 'pause tarefa':
        #         pass


class Slider_new(UserControl):
    def __init__(self,
                texto = None,
                 min = None,
                 max = None,
                 divisions = None,
                 fator = 1, #valor a ser multiplicado por value
                 digitos = 1,
                 width = 200,
                 on_change = None,
                 data = None, 
                 value = False,
    ):



        super().__init__()
        self.texto = texto
        self.min = min
        self.max = max
        self.divisions = divisions
        self.fator = fator
        self.digitos = digitos
        self.width = width
        self.on_change = on_change
        self.data = data
        self.value = value

        self.passo_fim2 = Slider(min = self.min, max = self.max, divisions=self.divisions,value = self.value, width=self.width,on_change=self.mudou, data = self.data)
        valor = round(self.passo_fim2.value*self.fator,self.digitos)
        if self.digitos == 0:
            valor = int(valor)
        self.texto2 = Text(f'{self.texto} ({valor})')

    def mudou(self,e):
        valor = round(self.passo_fim2.value*self.fator,self.digitos)
        if self.digitos == 0:
            valor = int(valor)
        self.texto2.value = f'{self.texto} ({valor})'
        self.value = valor
        self.on_change(e, self)
        super().update()

    def build(self):
        return Row([self.texto2, self.passo_fim2],alignment='start', tight = True, spacing=0,run_spacing = 0, height=30)


class Saidas(UserControl):
    def __init__(self,
        texto1 = '',
        texto2 = '',
        texto3 = '',
        texto4 = '',
        texto5 = '',
        texto6 = '',  
        cor = 'white',
        size = 20,                              
                  ):
        super().__init__()
        # self.t1 = texto1
        # self.t2 = texto2
        # self.t3 = texto3
        # self.t4 = texto4
        # self.t5 = texto5
        # self.t6 = texto6
        self._texto1a = Text(texto1, color = cor, size = size, visible=False)
        self._texto2a = Text(texto2, color = cor, size = size, visible=False)
        self._texto3a = Text(texto3, color = cor, size = size, visible=False)
        self._texto4a = Text(texto4, color = cor, size = size, visible=False)
        self._texto5a = Text(texto5, color = cor, size = size, visible=False)
        self._texto6a = Text(texto6, color = cor, size = size, visible=False)
        self.Visibles(                
                 texto1,
                 texto2,
                 texto3,
                 texto4,
                 texto5,
                 texto6
                 )
      
    def build(self):
        self.saida = Row(
            alignment= MainAxisAlignment.START,
            vertical_alignment = 'center',
            
            # height=300,
            tight = True,
            wrap = True,
            expand=1,
            run_spacing = 2,
            # runs_count=1,
            # max_extent=300,
            # child_aspect_ratio=8,
            # spacing=1,
            # run_spacing=10,
            # padding = 0, 
            controls=[
                        self._texto1a, self._texto2a, self._texto3a,self._texto4a,self._texto5a,self._texto6a
                    #   Column([self._texto1a, self._texto2a, self._texto3a],alignment = MainAxisAlignment.START),
                    #   Column([self._texto4a,self._texto5a,self._texto6a],alignment = MainAxisAlignment.START),
                    #   Row([],alignment = MainAxisAlignment.SPACE_AROUND),  
                                     
                      ],                                            
        )
        # self.saida = Container(self.saida, margin=margin.all(6))
        
        return self.saida
    
    def Visibles(self,                 
                 texto1,
                 texto2,
                 texto3,
                 texto4,
                 texto5,
                 texto6
                 ):
        if texto1 != '':
            self._texto1a.visible = True
        if texto2 != '':
            self._texto2a.visible = True
        if texto3 != '':
            self._texto3a.visible = True
        if texto4 != '':
            self._texto4a.visible = True
        if texto5 != '':
            self._texto5a.visible = True
        if texto6 != '':
            self._texto6a.visible = True 
    
      
    @property
    def texto1(self):       
        return self._texto1a.value
    
    @texto1.setter
    def texto1(self, texto):
        self._texto1a.value = texto 
        self._texto1a.size = 20
        self._texto1a.visible = True 
        self._texto1a.no_wrap = True
  
    @texto1.setter
    def texto1_color(self, color):
        self._texto1a.color = color
    @texto1.setter
    def texto1_size(self, size):
        self._texto1a.size = size 
    
    @property
    def texto2(self):       
        return self._texto2a.value
    
    @texto2.setter
    def texto2(self, texto):
        self._texto2a.value = texto 
        self._texto2a.size = 20
        self._texto2a.visible = True 
        self._texto2a.no_wrap = True
  
    @texto2.setter
    def texto2_color(self, color):
        self._texto2a.color = color
    @texto2.setter
    def texto2_size(self, size):
        self._texto2a.size = size 
    
    @property
    def texto3(self):       
        return self._texto3a.value
    
    @texto3.setter
    def texto3(self, texto):
        self._texto3a.value = texto 
        self._texto3a.size = 20
        self._texto3a.visible = True 
        self._texto3a.no_wrap = True
  
    @texto3.setter
    def texto3_color(self, color):
        self._texto3a.color = color
    @texto3.setter
    def texto3_size(self, size):
        self._texto3a.size = size 
    
    @property
    def texto4(self):       
        return self._texto4a.value
    
    @texto4.setter
    def texto4(self, texto):
        self._texto4a.value = texto 
        self._texto4a.size = 20
        self._texto4a.visible = True 
        self._texto4a.no_wrap = True
  
    @texto4.setter
    def texto4_color(self, color):
        self._texto4a.color = color
    @texto4.setter
    def texto4_size(self, size):
        self._texto4a.size = size 
    
    @property
    def texto5(self):       
        return self._texto5a.value
    
    @texto5.setter
    def texto5(self, texto):
        self._texto5a.value = texto 
        self._texto5a.size = 20
        self._texto5a.visible = True 
        self._texto5a.no_wrap = True
  
    @texto5.setter
    def texto5_color(self, color):
        self._texto5a.color = color
    @texto5.setter
    def texto5_size(self, size):
        self._texto5a.size = size 
    
    @property
    def texto6(self):       
        return self._texto6a.value
    
    @texto6.setter
    def texto6(self, texto):
        self._texto6a.value = texto 
        self._texto6a.size = 20
        self._texto6a.visible = True 
        self._texto6a.no_wrap = True
  
    @texto6.setter
    def texto6_color(self, color):
        self._texto6a.color = color
    @texto6.setter
    def texto6_size(self, size):
        self._texto6a.size = size 


class Saidas2(UserControl):
    def __init__(self, 
                 texto1 = '',
                 texto2 = '',
                 texto3 = '',
                 texto4 = '',
                 texto5 = '',
                 texto6 = ''
                 ):
        super().__init__()

        self.texto1 = Text(texto1, size = 20, visible=False)
        self.texto2 = Text(texto1, size = 20, visible=False)
        self.texto3 = Text(texto1, size = 20, visible=False)
        self.texto4 = Text(texto1, size = 20, visible=False)
        self.texto5 = Text(texto1, size = 20, visible=False)
        self.texto6 = Text(texto1, size = 20, visible=False)
        self.Visibles(                
                 texto1,
                 texto2,
                 texto3,
                 texto4,
                 texto5,
                 texto6
                 )
    def build(self):
        self.saida = Row(
            alignment= MainAxisAlignment.START,
            vertical_alignment = 'center',
            
            # height=300,
            tight = True,
            wrap = True,
            expand=1,
            run_spacing = 2,
            # runs_count=1,
            # max_extent=300,
            # child_aspect_ratio=8,
            # spacing=1,
            # run_spacing=10,
            # padding = 0, 
            controls=[
                      self.texto1,self.texto2,self.texto6o3,
                      self.texto4,self.texto5,self.texto6
                    #   Row([],alignment = MainAxisAlignment.SPACE_AROUND),  
                                     
                      ],                                            
        )
        # self.saida = Container(self.saida, margin=margin.all(6))
        
        return self.saida

    def Visibles(self,                 
                 texto1 ,
                 texto2,
                 texto6o3,
                 texto6o4,
                 texto6o5,
                 texto6
                 ):
        if texto1 != '':
            self.texto1.visible = True
        if texto2 != '':
            self.texto2.visible = True
        if texto6o3 != '':
            self.texto3.visible = True
        if texto6o4 != '':
            self.texto4.visible = True
        if texto6o5 != '':
            self.exto5.visible = True
        if texto6 != '':
            self.texto6.visible = True                                                            



    '''
class Pomodoro(UserControl):
    def __init__(self):
        super().__init__()
        self.pomodoro_control_thread = True
        self.tempo_pomodoro_set = 0.1
        self.Metro_normal = Metronomo()
        self.Metro_normal.pause = False
        self.parar = False
        self.tempo_descanso_value = 6
        self.quado_saida = Row()
        self.saida_respiro = Column(visible=False)



    def did_mount(self):
        self.Pomodoro()

    def build(self):
        return  Row([self.quado_saida, self.saida_respiro])  
    def Pomodoro(self):
        texto = 'Pomodoro inciado...'
        self.quado_saida.visible = True        
        self.quado_saida.controls = [Text(texto)]
        super().update()

        while self.pomodoro_control_thread:
            self.quado_saida.visible = True
            
            segundos = self.tempo_pomodoro_set*60
            while segundos >= 0:
                h, mins = divmod(segundos, 60*60)
                mins, secs = divmod(mins, 60)
                h, mins, secs = int(h), int(mins), int(secs)
                if texto != '':
                    contador = "{:s} {:02d}:{:02d}:{:02d}".format(texto,h, mins, secs)
                else:
                    contador = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)

                self.quado_saida.controls = [Text(contador)]
                sleep(1)
                super().update()
                segundos -= 1
                while self.Metro_normal.pause:
                    sleep(0.3)
                if self.parar or not self.pomodoro_control_thread:
                    break

            if self.parar or not self.pomodoro_control_thread:
                self.quado_saida.visible = False
                self.quado_saida.controls = None
                break

            MessageBeep(MB_ICONHAND)

            self.Respiro()
            
            if not self.pomodoro_control_thread:
                break
            MessageBeep(MB_ICONHAND)

            if not self.pomodoro_control_thread:
                break
            texto = 'Volte a treinor por '

        self.quado_saida.controls =  None

    def Respiro(self):
        # self.Metro_normal.pause = True
        # estado_saida_treinamento = self.saida_treinamento.visible
        # estado_saida_quado = self.quado_saida.visible
        # self.saida_treinamento.visible = False
        self.quado_saida.visible = False
        self.saida_respiro.visible = True
        descan = int(self.tempo_descanso_value*60/19.4)
        # print(descan)
        # self.Metro_normal.pause = False
        self.parar = False
        width_max = 740
        respiro = Container(content=Text(),bgcolor= colors.YELLOW,width = 0, border_radius=40)
        def Inspire(d):
            # self.quado_saida.content = Text(f'INSPIRE ({d})')
            s = Saidas(f'INSPIRE ({d})', cor = colors.YELLOW, size = 50)
            # s.saida_tempo_de_treino.visible = True
            # self.saida.texto1_size = 50
            # self.saida.texto1_color= colors.YELLOW
            self.saida_respiro.controls = [Column([s, respiro])]
            # self.quado_saida.content.alignment= MainAxisAlignment.CENTER

        def Expire(d):
            s = Saidas(f'EXPIRE  ({d})', cor = colors.GREEN, size = 50)

            # s.saida_tempo_de_treino.visible = True
            # self.saida.texto1_size = 50
            # self.saida.texto1_color= colors.GREEN
            self.saida_respiro.controls = [Column([s, respiro])]
            # self.quado_saida.content.alignment= MainAxisAlignment.CENTER


        for d in range(descan,0,-1):
            a = time()
            Inspire(d)
            super().update()
            for i in range(0,width_max,6*2):
                respiro.width = i
                sleep(0.001)
                if self.parar:
                    break
                super().update()
            respiro.bgcolor = colors.GREEN
            Expire(d)
            super().update()
            if self.parar:
                break             
            for i in range(width_max,0,-1*2):
                respiro.width = i
                if self.parar:
                    break                    
                sleep(0.01567)
                super().update()
            respiro.bgcolor = colors.YELLOW
            b = time()-a
            print(b)

        # self.saida_treinamento.visible = estado_saida_treinamento
        # self.quado_saida.visible = estado_saida_quado
        # self.saida_respiro.controls = None
        self.saida_respiro.visible = False
        self.quado_saida.visible = True
        self.Metro_normal.pause = False
        respiro.width = 0
        super().update()
    '''




config = 'config_metronomo_exemplo.json'
try:
    nome_da_credencial = 'client_secret.json'
except:
    print(f'O arquivo "client_secret.json" não foi encontrado')  


class Layout(UserControl):
    def __init__(self,
        page,
        ):
        super().__init__() 
        self.page = page
        self.Metro_normal = Metronomo()
        self.Modo = 'normal'
        self.pause_lay = False
        # self.saida = Saidas()
        self.Iniciar_arquiv()

        #parâmetros do metrônomo
        self.metronomo_iniciado = False
        self.parar = False
        self.play_tarefas = False
        self.pomodoro_control_thread = False
        self.iniciar_medicao_bpm = False
        self.t_total = None
        self.Treino_habilitado_set = False
        self.inverter_set = False
        self.tempo_set = False
        self.passo_set = 1
        self.passo_fim_set = 0
        self.intervalo_set = 1
        self.tempo_pomodoro_set = 1
        self.tempo_descanso_set = 1
        self.play_tarefas_set = False





        self.col_tarefas = Column()
        self.Importar = TextButton('Importar', on_click=self.acoes_botoes_layout, data = 'Importar')
        self.Exportar = TextButton('Exportar', on_click=self.acoes_botoes_layout, data = 'Exportar')
        self.Selecionar_planilha = TextButton('Selecionar Planilha', on_click=self.acoes_botoes_layout, data = 'Selecionar Planilha')
        #1-vU6ONr6gZTcpOI-inXlzpiwcPqUpDgBgXnPXvjkPjk
        cor_botoes_bpm = colors.PINK_50
        self.Bot_m1 = OutlinedButton('+1', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m1')
        self.Bot_m5 = OutlinedButton('+5', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m5')
        self.Bot_m10 = OutlinedButton('+10', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m10')
        self.Bot_m_1 = OutlinedButton('-1', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m_1')
        self.Bot_m_5 = OutlinedButton('-5', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m_5')
        self.Bot_m_10 = OutlinedButton('-10', expand=1, on_click=self.acoes_botoes_layout, data = 'Bot_m_10')
        self.display_bpm = Dropdown(data = 'valorbpm',
                    alignment= Alignment(0, 1),
                    options=[dropdown.Option(i) for i in range(30,550,1)],
                    text_size = 20,
                    border=1,
                    border_color='white',
                    prefix_text = 'bpm: ',
                    # expand=1,
                    value = 155,
                    width = 150,
                    # aspect_ratio = 0.5,
                    # height = 200,
                    # content_padding = 0,
                    text_style = TextStyle(weight = 'bold'),
                    on_change=self.acoes_botoes_layout
                                                    
            )

        self.vol  =  Slider(min = 0, max = 10, divisions=10, value = 10,label='{value}', width=130, on_change=self.acoes_botoes_layout, data = 'vol')
        self.inverter = Checkbox(on_change=self.acoes_botoes_layout, data = 'Inverter', value = False)
        self.Treino_habilitado = Checkbox(on_change=self.acoes_botoes_layout, data = 'Treino_habilitado', value = True)
        self.Tap = IconButton(icon = icons.CIRCLE,on_click=self.acoes_botoes_layout, data = 'Tap')

        tamanho_slids = 300
        # self.meta = Slider(min = 30, max = 300, divisions=271, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'meta')
        # self.inicio = Slider(min = 30, max = 301, divisions=271, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'inicio')
        # self.passo = Slider(min = 0, max = 5, divisions=51, label='{value}', width=tamanho_slids,on_change=self.acoes_botoes_layout, data = 'passo')
        
        # self.passo_fim2 = Slider(min = 0, max = 50, divisions=50,value = 10, width=tamanho_slids-50,on_change=self.acoes_botoes_layout, data = 'passo_fim')
        # self.texto_passo_fim = Text(f'Passo_fim ({self.passo_fim2.value/10:.1f})')
        # self.passo_fim = self.passo_fim2.value/10
        self.meta = Slider_new('Meta',30, 300, 270, 1,0, width = 200, on_change = self.acoes_botoes_layout, data = 'meta',value = 170, )
        self.inicio = Slider_new('Início',30, 300, 270, 1,0, width = 200, on_change = self.acoes_botoes_layout, data = 'inicio',value = 168, )
        self.passo = Slider_new('passo',0, 50, 50, 0.1,1, width = 200, on_change = self.acoes_botoes_layout, data = 'passo',value = 1, )
        self.passo_fim = Slider_new('Passo_fim',0, 50, 50, 0.1,1, width = 200, on_change = self.acoes_botoes_layout, data = 'passo_fim',value = 0, )




        # self.intervalo  =  Slider(min = 1, max = 30, divisions=31, label='{value}', width=300,on_change=self.acoes_botoes_layout, data = 'intervalo')
        self.intervalo  =  Slider_new('',1, 30, 50, 1,1, width = 300, on_change = self.acoes_botoes_layout, data = 'intervalo',value = 1, )
        self.tempo = Checkbox(on_change=self.acoes_botoes_layout, data = 'tempo', value  = False)
        self.Tipo_compasso = Drop_new(['2/4', '3/4', '4/4'], '4/4',
                                      on_change=self.acoes_botoes_layout, data = 'Tipo_compasso'
                                      )
        self.qtd_compassos = Drop_new([i for i in range(1,48)], 1,
                                      on_change=self.acoes_botoes_layout, data = 'qtd_compassos'
                                      )
        self.tempo_compasso = 'Tempo'

        self.continuar = Checkbox(on_change=self.acoes_botoes_layout, data = 'continuar', value = False)
        self.pomodoro_habilitado = Checkbox(on_change=self.acoes_botoes_layout, data = 'pomodoro_habilitado', value = True)
        self.tempo_pomodoro = Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 0.1,
                                       on_change=self.acoes_botoes_layout, data = 'tempo_pomodoro'
                                       )
        self.tempo_descanso = Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 0.5,
                                       on_change=self.acoes_botoes_layout, data = 'tempo_descanso'
                                       )        

        self.task_lis_select = Dropdown(                
            alignment= Alignment(-1, 1),
            options=[dropdown.Option(i) for i in self.arquiv.keys()],
            text_size = 20,
            border_color=colors.with_opacity(0.0,'white'),
            value = 'Padrão',
            color = colors.with_opacity(1,'white'),
            height = 30,
            expand= 1,
            content_padding = 0,
            autofocus = 0,
            on_change=self.acoes_botoes_layout, data = 'task_lis_select'

        )
        self.new_list_task = TextField(hint_text = 'nome da nova lista de tarefas', width = 150, expand= 1,)
        self.add_new_list_tasks = ElevatedButton(text='Add.', width = 80,on_click=self.acoes_botoes_layout, data = 'add new list task')

        tamanho_botao = 180
        self.play = IconButton(icon=icons.PLAY_ARROW, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'play')
        self.pause = IconButton(icon=icons.PAUSE, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'pause')
        self.stop = IconButton(icon=icons.STOP, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'stop')
        self.salvar = IconButton(icon=icons.SAVE, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'salvar')
        
        # self.quado_saida = Container(width=775,height = 120, 
        #                              border= border.all(1, color = 'white'),
                                    
        #                             #  margin = margin.all(0),
        #                             # padding = 0,
        #                             # alignment = Alignment(-1,-1),

        # )
        self.quado_saida = Column()
        self.saida_respiro = Column(visible=False)
        self.saida_treinamento = Row(visible=False)

        # self.quado_saida = Quadro_assync(width=775,height = 120)
        # self.quado_saida = Container(content = Countdown(40, 'Volte a treinar por '), width=775,height = 120, border= border.all(1, color = 'white'),)
        

        self.add_tarefa = OutlinedButton('Add tarefa', on_click=self.acoes_botoes_layout, data = 'add new task')
        self.play_tarefas = OutlinedButton('Play Tarefas',on_click=self.acoes_botoes_layout, data = 'Play Tarefas')

    def build(self):
        menu_bar = Row([
            self.Importar,
            self.Exportar,
            self.Selecionar_planilha,
        ], height=18)        
        quadro_bpm = Container(Row([
            self.Bot_m1, 
            self.Bot_m5, 
            self.Bot_m10, 
            self.display_bpm,
            self.Bot_m_1, 
            self.Bot_m_5, 
            self.Bot_m_10,
        ], alignment=MainAxisAlignment.SPACE_AROUND),border= border.all(1, color = 'white'),)  


        vol = Row([Text('Vol'),self.vol],spacing=0,)
        inverter = Row([self.inverter, Text('Inverter')], spacing=0)
        Treino_habilitado= Row([self.Treino_habilitado , Text('Treino_habilitado')], spacing=0)        
        tap = Row([Text('Tap'),self.Tap], spacing=0)   
        quadro_vol = Container(Row([vol, inverter, Treino_habilitado, tap], alignment=MainAxisAlignment.SPACE_AROUND),border= border.all(1, color = 'white'))
        
        
        tamanho_slids = 300
        meta  =  Row([Text('Meta'),self.meta],spacing=0,)
        inicio  =  Row([Text('Inicio'),self.inicio],spacing=0,)
        passo  =  Row([Text('Passo'),self.passo],spacing=0,)

        col_trainamento = Container(Column([self.meta, self.inicio, self.passo,  self.passo_fim], spacing=0),height=200)


        intervalo = Row([Text('Intervalo'),self.intervalo],spacing=0,)
        tempo = Row([self.tempo, Text('Tempo (min)')], spacing=0)
        Tipo_compasso = Row([Text('Tipo de Compasso'),self.Tipo_compasso])
        qtd_compassos = Row([Text('Qtd de Compasso'),self.qtd_compassos])

        self.tab_compassos = Container(Row([Tabs(
            selected_index=0,
            animation_duration=300,
            tabs=[
                Tab(
                    text="Tempo",
                    content=Column([intervalo, tempo])
                ),
                Tab(
                    text="Compassos",
                    # tab_content=Icon(icons.SEARCH),
                    content=Column([Tipo_compasso, qtd_compassos])
                ),
            ],
            width=350,
            height=200,
            on_change = self.acoes_botoes_layout,
            data = 'tempo_compasso',
            # expand=1,
            )
            ]),
            expand = 0,
        )
    

        quadro_trainamento = Container(Row([col_trainamento,Container(width = 1,bgcolor='white', height=220, expand=0),self.tab_compassos],alignment=MainAxisAlignment.SPACE_AROUND),border= border.all(1, color = 'white'))

        Treinamento = Container(Column([quadro_bpm,Row([self.task_lis_select, self.new_list_task, self.add_new_list_tasks],height= 35,alignment=MainAxisAlignment.SPACE_BETWEEN),quadro_vol,quadro_trainamento]),border= border.all(1, color = 'white'),)
        # Treinamento = Quadro_assync(Column([quadro_bpm,Row([self.task_lis_select, self.new_list_task, self.add_new_list_tasks],height= 35,alignment=MainAxisAlignment.SPACE_BETWEEN),quadro_vol,quadro_trainamento]))
   

        quadro_botoes = [self.play, self.pause, self.stop, self.salvar]
        quadro_botoes = [Quadro(i, bgcolor = '#888888') for i in quadro_botoes]
        quadro_botoes = Quadro(Row(quadro_botoes,alignment=MainAxisAlignment.SPACE_AROUND))


        botos_tarefas = Row([self.add_tarefa, self.play_tarefas], alignment=MainAxisAlignment.SPACE_AROUND)
        titulos_tarefas = Row([
            VerticalDivider(width=120),
            Text('Treino'),
            VerticalDivider(width=120),
            Text('Duração'),
            VerticalDivider(width=40),
            Text('In'),
            VerticalDivider(width=40),
            Text('Fim'),
            VerticalDivider(width=40),
            Text('Passo'),                                                   
        ])
        
        self.col_tarefas.scroll = ScrollMode.ALWAYS
        Tarefass = Column([
            Container(Row([self.task_lis_select, self.new_list_task, self.add_new_list_tasks],height= 35,alignment=MainAxisAlignment.SPACE_BETWEEN)),
            botos_tarefas,
            titulos_tarefas, 
            Container(self.col_tarefas,
            alignment=Alignment(-1,-1),
            border= border.all(1, color = 'white'),
            height= 305,
        )
                            ], height=350, expand=0)       
        # Tarefass.scroll = ScrollMode.ALWAYS

        # for i in range(3):
        #     t1 = New_task(self.acoes_tasks)
        #     self.col_tarefas.controls.append(t1)
        # for i in self.arquiv['Padrão']:
        #      print(i.values())
                
        for i in self.arquiv['Padrão']:
            t1 = New_task(self.acoes_tasks)
            valor = list(i.values())
            t1.nome_tarefa.value = valor[0]
            t1.duracao_tarefa.value = valor[1]
            t1.inicio_tarefa.value = valor[2]
            t1.fim_tarefa.value = valor[3]
            t1.passo_tarefa.value = valor[4]
            self.col_tarefas.controls.append(t1)



        
        modos = Tabs(
            selected_index=0,
            animation_duration=300,
            tabs=[
                Tab(
                    text="Treinamento",
                    content=Treinamento
                ),
                Tab(
                    text="Tarefas",
                    # tab_content=Icon(icons.SEARCH),
                    content=Tarefass
                ),
            ],
            width=self.page.window_width-5,
            height=430,
            data = 'modos',
            on_change=self.acoes_botoes_layout,
            # expand=1,
            )

        continuar = Row([self.continuar, Text('Continuar')], spacing=0)
        pomodoro = Row([self.pomodoro_habilitado, Text('Pomodoro'),Quadro(self.tempo_pomodoro) ], spacing=0)
        descanso = Row([Text('Descanso'),Quadro(self.tempo_descanso) ], spacing=0)
        quadro_pomodoro = Quadro(Row([continuar, pomodoro, descanso],alignment=MainAxisAlignment.SPACE_AROUND))
    
        return Column([
            menu_bar,
            modos,
            quadro_pomodoro,
            quadro_botoes, 
            Container(width=775,height = 120, 
                border= border.all(1, color = 'white'),
                content = Column([
                    self.saida_treinamento,
                    self.quado_saida,
                    self.saida_respiro,
                                  ])
                                    
                                    #  margin = margin.all(0),
                                    # padding = 0,
                                    # alignment = Alignment(-1,-1),

            )
            
        ])

    def Iniciar_arquiv(self):

        # {
        #             'nome':[],
        #             'duração':[],
        #             'bmp_ini':[],
        #             'bpm_fim':[],
        #             'passo':[]
        try:
            self.arquiv = Ler_json(config)
        except:
            self.arquiv = {
                'Padrão':[],
                'música 1':None,
                'música 2':None
            }
            Escrever_json(self.arquiv, config)

    def Salvar_cofig(self):
        pass

        p = []
        for i in self.col_tarefas.controls:
            chaves = ['nome', 'duração', 'bmp_ini', 'bpm_fim', 'passo']
            l = [i.nome_tarefa.value,i.duracao_tarefa.value,i.inicio_tarefa.value , i.fim_tarefa.value, i.passo_tarefa.value]
            d = {k:j for j,k in zip(l, chaves)}
            p.append(d)
            # self.arquiv['Padrão']['nome'].append(i.nome_tarefa.value)
            # self.arquiv['Padrão']['duração'].append(i.duracao_tarefa.value)  
            # self.arquiv['Padrão']['bmp_ini'].append(i.inicio_tarefa.value)  
            # self.arquiv['Padrão']['bpm_fim'].append(i.fim_tarefa.value)  
            # self.arquiv['Padrão']['passo'].append(i.passo_tarefa.value)  
        self.arquiv = Ler_json(config)
        nome_tarefa = self.task_lis_select.value

        self.arquiv[nome_tarefa] = p
        Escrever_json(self.arquiv, config)
        
    def acoes_tasks(self, task,e):
        data = e.control.data
        t = task
        match data:
            case 'del':
                self.col_tarefas.controls.remove(task)
            case 'play tarefa':
                print('Apertou play')
                # print(task.nome_tarefa.value)
                # self.Exibir_atributos(task.nome_tarefa)
                def Ler_parametros_tarefas():
                    self.Metro_normal.setVolume(self.vol.value/10)
                    self.pomodoro_control_thread = self.pomodoro_habilitado.value                 
                    self.display_bpm.value = float(task.inicio_tarefa.value)
                    self.Metro_normal.setBpm(self.display_bpm.value)
                    self.parar = False
                    self.t_total = float(task.duracao_tarefa.value)*60
                    self.tempo_pomodoro_set = self.tempo_pomodoro.value
                    self.tempo_descanso_set = self.tempo_descanso.value
                    self.Treino_habilitado_set = True
                    self.inverter_set = False
                    self.tempo_set = True
                    self.nome_treino = task.nome_tarefa.value
                    self.meta_set = float(task.fim_tarefa.value)
                    self.inicio_set = float(task.inicio_tarefa.value)
                    self.passo_set = float(task.passo_tarefa.value)
                    self.passo_fim_set = 0
                    # self.Metro_normal.pomodoro_habilitado = self.pomodoro_habilitado.value
                    # self.Metro_normal.tempo_descanso = int(self.tempo_descanso.value)
                    # self.Metro_normal.tempo_pomodoro = float(self.tempo_pomodoro.value)
                    self.Metro_normal.tempo_compasso = 'Tempo'




                    if self.meta_set == 0 or self.inicio_set == 0 or self.passo_set == 0:
                        self.progressivo = False
                        if self.t_total == None:
                            self.t_total = self.intervalo_set
                    else:
                        self.progressivo = True
                    
       
                if self.metronomo_iniciado:
                    self.Stop()
                    self.Metro_normal = None
                    sleep(0.5)
                    self.Metro_normal = Metronomo()
                    self.quado_saida.controls = None
                    self.saida_respiro.controls = None
                    self.saida_treinamento.controls = None
                    e.control.bgcolor = None

                else:
                    self.Stop()
                    self.Metro_normal = None
                    sleep(0.4)
                    self.Metro_normal = Metronomo()
                    sleep(0.1)
                    Ler_parametros_tarefas()
                    super().update()
                    self.Ini_Thread('pomodoro')
                    self.Ini_Thread('beep')

                    # try:
                    intervalo_bpm = round((self.t_total*self.passo_set)/(self.meta_set - self.inicio_set), 3)

                    if self.metronomo_iniciado:
                        self.nome_treino = 'sem nome' if self.nome_treino == '' else self.nome_treino
                        tarefa_exec = f'{Data()} .-. {self.nome_treino} .-. {self.t_total/60:.0f} min .-. BPM({self.inicio_set:.0f} a {self.meta_set:.0f}) .-. passo: {self.passo_set:.0f} .-. intervalo: {intervalo_bpm}s'
                        # self.t_total = 60*self.t_total
                        self.Ini_Thread('Treinamento', [(tarefa_exec)])



                    # self.Play2(tarefas = True) 
                    # print(task.controls)
            
            case 'pause tarefa':
                # self.quado_saida.content.pause = not self.quado_saida.content.pause 
                # self.Metro_normal.Pause()
                self.Pausar()


        super().update()
        print('ação recebida',data )

    def acoes_botoes_layout(self, e, task = ''):
        # self.Exibir_atributos(e.data)
        # print(e.data)
        try:
            data = e.control.data
        except:
            data = e.data        

        match data:                    
            case 'Importar':
                print('tempo_pomodoro alterado')
            case 'Exportar':
                print('tempo_pomodoro alterado')
            case 'Selecionar Planilha':
                print('tempo_pomodoro alterado')
            case 'Bot_m1':
                self.up_bpm(1)
            case 'Bot_m5':
                self.up_bpm(5)
            case 'Bot_m10':
                self.up_bpm(10)
            case 'Bot_m_1':
                self.up_bpm(-1)
            case 'Bot_m_5':
                self.up_bpm(-5)
            case 'Bot_m_10':
                self.up_bpm(-10)
            case 'valorbpm':
                self.Metro_normal.setBpm(self.display_bpm.value)
            case 'vol':
               self.Metro_normal.setVolume(e.control.value/10)
            case 'Inverter':
                self.inverter_set = self.inverter.value
            case 'Treino_habilitado':
                print('treino alterado')
            case 'Tap':
                print('tap alterado')
                self.Tap_bpm()
            case 'meta':
                # print('meta = ', self.meta.value)
                self.meta_set = self.meta.value
            case 'inicio':
                # print('inicio = ', self.inicio.value)
                self.inicio_set = self.inicio.value
            case 'passo':
                # print('passo = ', self.passo.value)
                self.passo_set = self.passo.value
            case 'passo_fim':
                # self.passo_fim = self.passo_fim2.value/10
                # self.texto_passo_fim.value = f'Passo_fim ({self.passo_fim2.value/10:.1f})'
                print('passo_fim = ',self.passo_fim.value)
                self.passo_fim_set = self.passo_fim.value
            case 'intervalo':
                # print('intervalo alterado')
                self.intervalo_set = self.intervalo.value
            case 'tempo':
                print('tempo alterado')
                self.tempo_set = self.tempo.value
            case 'Tipo_compasso':
                print('Tipo_compasso alterado')
            case 'qtd_compassos':
                print('qtd_compassos alterado')
            case 'continuar':
                print('continuar alterado')
            case 'pomodoro_habilitado':
                self.pomodoro_control_thread = self.pomodoro_habilitado.value
                print('pomodoro habilitado alterado')
            case 'tempo_pomodoro':
                print('tempo_pomodoro alterado')
            case 'tempo_descanso':
                print('tempo_descanso alterado')
            case 'task_lis_select':
                tarefa = e.control.value
                # print(self.arquiv[tarefa])
                if type(self.arquiv[tarefa]) == list:
                    if len(self.arquiv[tarefa]) >0:
                        self.col_tarefas.controls = None
                        for i in self.arquiv[tarefa]:
                            t1 = New_task(self.acoes_tasks)
                            valor = list(i.values())
                            t1.nome_tarefa.value = valor[0]
                            t1.duracao_tarefa.value = valor[1]
                            t1.inicio_tarefa.value = valor[2]
                            t1.fim_tarefa.value = valor[3]
                            t1.passo_tarefa.value = valor[4]
                            self.col_tarefas.controls.append(t1)
            case 'play':
                self.Play3()
            case 'add new list task':                
                self.task_lis_select.options.append(dropdown.Option(self.new_list_task.value))
            case 'pause':
                # self.pause_lay = not self.pause_lay

                # if self.quado_saida.content != None and not self.Treino_habilitado:
                #     self.quado_saida.content.pause = not self.quado_saida.content.pause 
                self.Pausar()
            case 'stop':
                self.Stop()
                self.saida_respiro.controls = None
                self.saida_treinamento.controls = None
                self.quado_saida.controls = None
                self.Metro_normal = None
                self.Metro_normal = Metronomo() 
            case 'salvar':
                self.Salvar_cofig()
            case 'add new task':
                self.col_tarefas.controls.append(New_task(self.acoes_tasks)) 
                print('add tarefa')
            case 'Play Tarefas':
                self.play_tarefas_set = True
                print('pomodoro')
                p = Pomodoro()
                self.quado_saida.controls = [p]
                super().update()
            case 'tempo_compasso':
                # print('tempo-compasso', e.data, type(e.data))
                match e.data:
                    case '0':
                        self.tempo_compasso = 'Tempo'
                    case '1':
                        self.tempo_compasso = 'Compassos'
            case 'modos':
                # print(e.data)
                match e.data:
                    case '0':
                        self.Modo = 'normal'
                    case '1':
                        self.Modo = 'tarefas'

        super().update() 

    def Att(self):
        super().update()
    # def Att(self):
    #     super().update()        
    def up_bpm(self, bpm):        
        new_bpm = self.display_bpm.value + bpm
        if new_bpm <=30:
            new_bpm = 30
        elif  new_bpm>549:
            new_bpm = 549
        # print(new_bpm)
        # print(type(new_bpm))
        # print('tipo self.Metro_normal.setBpm(new_bpm) = ', type(self.Metro_normal.setBpm(new_bpm)))    
        self.display_bpm.options.append(dropdown.Option(new_bpm))
        self.display_bpm.value = new_bpm
        self.Metro_normal.setBpm(new_bpm)
        super().update()

    def Mostrar(self, *texto, cor = 'white', size = 20):
        try:
            if self.quado_saida.content.texto1 == '':
                pass

            for i in texto:
                if self.quado_saida.content.texto1 == '':
                    self.quado_saida.content.texto1 = i
                    self.quado_saida.content.texto1_color = cor
                    self.quado_saida.content.texto1_size = size
    

                elif self.quado_saida.content.texto2 == '':
                    self.quado_saida.content.texto2 = i
                    self.quado_saida.content.texto2_color = cor
                    self.quado_saida.content.texto2_size = size
    

                elif self.quado_saida.content.texto3 == '':
                    self.quado_saida.content.texto3 = i
                    self.quado_saida.content.texto3_color = cor
                    self.quado_saida.content.texto3_size = size
    

                elif self.quado_saida.content.texto4 == '':
                    self.quado_saida.content.texto4 = i
                    self.quado_saida.content.texto4_color = cor
                    self.quado_saida.content.texto4_size = size
    

                elif self.quado_saida.content.texto5 == '':
                    self.quado_saida.content.texto5 = i
                    self.quado_saida.content.texto5_color = cor
                    self.quado_saida.content.texto5_size = size
    

                elif self.quado_saida.content.texto6 == '':
                    self.quado_saida.content.texto6 = i
                    self.quado_saida.content.texto6_color = cor
                    self.quado_saida.content.texto6_size = size


                else:
                    print('limite de saidas atingido')

        except:
            self.quado_saida.content = Saidas(*texto, cor  = cor, size = size)
                            

        super().update()
        return  self.quado_saida.content      

    def Play3(self):
    # print(e.control)
        # print(self.metronomo_iniciado)
        if self.metronomo_iniciado:
            print('metronomo já iniciado')
            self.Stop()
            self.Metro_normal = None
            sleep(0.5)
            self.Metro_normal = Metronomo()
            self.quado_saida.controls = None

        else:
            self.Stop()
            self.Metro_normal = None
            sleep(0.5)
            self.Metro_normal = Metronomo()
            self.Metro_normal.setBpm(self.display_bpm.value)
            # self.Play2() 
            self.Read_values()
            tempo = float(self.tempo_pomodoro.value)
            # print('tempo = ', tempo, 'tipo:', type(tempo))
            # self.quado_saida.content =  Countdown(tempo, 'Treine durante ')
            # print(self.pomodoro_habilitado.value)
            # self.Mostrar('ahora vai')

            self.Ini_Thread('pomodoro')
            self.Ini_Thread('beep')



            if self.tempo_compasso == 'Tempo' and self.Treino_habilitado.value:
                self.tipo_de_treino = 'treinamento'                        
                self.Ini_Thread('Treinamento')

            elif self.tempo_compasso == 'Compassos' and self.Treino_habilitado.value:
                self.tipo_de_treino = 'compassos'                        
                self.Ini_Thread('compassos')        

    def Respiro(self):
        self.Metro_normal.pause = True
        estado_saida_treinamento = self.saida_treinamento.visible
        estado_saida_quado = self.quado_saida.visible
        self.saida_treinamento.visible = False
        self.quado_saida.visible = False
        self.saida_respiro.visible = True
        descan = int(self.tempo_descanso.value*60/19.4)
        # print(descan)
        # self.Metro_normal.pause = False
        self.parar = False
        width_max = 740
        respiro = Container(content=Text(),bgcolor= colors.YELLOW,width = 0, border_radius=40)
        def Inspire(d):
            # self.quado_saida.content = Text(f'INSPIRE ({d})')
            s = Saidas(f'INSPIRE ({d})', cor = colors.YELLOW, size = 50)
            # s.saida_tempo_de_treino.visible = True
            # self.saida.texto1_size = 50
            # self.saida.texto1_color= colors.YELLOW
            self.saida_respiro.controls = [Column([s, respiro])]
            # self.quado_saida.content.alignment= MainAxisAlignment.CENTER

        def Expire(d):
            s = Saidas(f'EXPIRE  ({d})', cor = colors.GREEN, size = 50)

            # s.saida_tempo_de_treino.visible = True
            # self.saida.texto1_size = 50
            # self.saida.texto1_color= colors.GREEN
            self.saida_respiro.controls = [Column([s, respiro])]
            # self.quado_saida.content.alignment= MainAxisAlignment.CENTER


        for d in range(descan,0,-1):
            a = time()
            Inspire(d)
            super().update()
            for i in range(0,width_max,6*2):
                respiro.width = i
                sleep(0.001)
                if self.parar:
                    break
                super().update()
            respiro.bgcolor = colors.GREEN
            Expire(d)
            super().update()
            if self.parar:
                break             
            for i in range(width_max,0,-1*2):
                respiro.width = i
                if self.parar:
                    break                    
                sleep(0.01567)
                super().update()
            respiro.bgcolor = colors.YELLOW
            b = time()-a
            print(b)

        self.saida_treinamento.visible = estado_saida_treinamento
        self.quado_saida.visible = estado_saida_quado
        self.saida_respiro.controls = None
        self.saida_respiro.visible = False
        self.Metro_normal.pause = False
        respiro.width = 0
        super().update()
  
    def Exibir_atributos(self, objeto):
        for i in objeto.__dict__.keys():
            print(i) 

    # def tempo_compasso(self,e):
    #     print(e.control.data)

    def Read_values(self, tarefas=False):
        self.Metro_normal.setVolume(self.vol.value/10)
        self.pomodoro_control_thread = self.pomodoro_habilitado.value
        self.Treino_habilitado_set = self.Treino_habilitado.value
        # self.Metro_normal.tempo_compasso = 
        self.Metro_normal.setBpm(self.display_bpm.value)
        self.parar = False
        self.tempo_pomodoro_set = self.tempo_pomodoro.value
        self.tempo_descanso_set = self.tempo_descanso.value
        self.meta_set = self.meta.value
        self.inicio_set = self.inicio.value 
        self.tempo_set = self.tempo.value
        self.passo_set = self.passo.value
        self.passo_fim_set = self.passo_fim.value
        self.intervalo_set = self.intervalo.value

        if not tarefas:
            if self.Tipo_compasso.value == '2/4':
                self.Tipo_compasso.value = 2
            elif self.Tipo_compasso.value == '3/4':
                self.Tipo_compasso.value = 3
            elif self.Tipo_compasso.value == '4/4':
                self.Tipo_compasso.value = 4
            else:
                self.Tipo_compasso.value = 4

        if self.meta_set == -100 or self.inicio_set == -100 or self.passo_set == 0:
            self.progressivo = False
            if self.t_total == None:
                self.t_total = self.intervalo.value
        else:
            self.progressivo = True
    '''
    def Play2(self, e='', tarefas = False):
        self.Read_values(tarefas)
        # Thread(target=self.check_display, daemon=False).start()
        tempo = float(self.tempo_pomodoro.value)
        print('tempo = ', tempo, 'tipo:', type(tempo))
        self.quado_saida.content =  Countdown(tempo, 'Volte a treinar por ')
        
        if tarefas:
            self.Metro_normal.Play_tarefas()   
        else:
            self.Metro_normal.Play()
        super().update()
    '''
    '''
    def Play_tarefas(self):
        self.Ini_Thread('pomodoro')
        self.Ini_Thread('beep')
        self.Treino_habilitado.value = True
        self.inverter.value = False
        self.tempo.value = True
        self.passo_fim.value = 0
        # try:
        intervalo_bpm = round(
            (float(self.t_total)*float(self.passo))/(float(self.meta) - float(self.inicio)), 3)

        if self.metronomo_iniciado:
            self.nome_treino = 'sem nome' if self.nome_treino == '' else self.nome_treino
            tarefa_exec = f'{Data()} .-. {self.nome_treino} .-. {self.t_total}min .-. BPM({self.inicio} a {self.meta}) .-. passo: {self.passo} .-. intervalo: {intervalo_bpm}s'
            self.Ini_Thread('Treinamento', [(tarefa_exec)])
    '''


    def Stop(self):
        self.Metro_normal.setOn = False
        self.treinando = False
        self.pomodoro_control_thread = False
        self.metronomo_iniciado = False
        self.parar = True 

        # sleep(0.5)

        # self.parar = False  
        # self.pomodoro_habilitado.value = not self.pomodoro_habilitado.value

    def Pausar(self):
        self.Metro_normal.pause = not self.Metro_normal.pause

    def Pomodoro(self):
        texto = 'Pomodoro inciado...'
        self.quado_saida.visible = True        
        self.quado_saida.controls = [Text(texto)]
        super().update()

        while self.pomodoro_control_thread:
            self.quado_saida.visible = True
            # self.quado_saida.content =  Countdown(self.tempo_pomodoro.value, 'Pomodoro inciado...')
            segundos = self.tempo_pomodoro_set*60
            while segundos >= 0:
                h, mins = divmod(segundos, 60*60)
                mins, secs = divmod(mins, 60)
                h, mins, secs = int(h), int(mins), int(secs)
                if texto != '':
                    contador = "{:s} {:02d}:{:02d}:{:02d}".format(texto,h, mins, secs)
                else:
                    contador = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)

                self.quado_saida.controls = [Text(contador)]
                sleep(1)
                super().update()
                segundos -= 1
                while self.Metro_normal.pause:
                    sleep(0.3)
                if self.parar or not self.pomodoro_control_thread:
                    break

            if self.parar or not self.pomodoro_control_thread:
                self.quado_saida.visible = False
                self.quado_saida.controls = None
                break

            MessageBeep(MB_ICONHAND)
            # self.Pausar()
            # self.quado_saida.content =  Countdown(self.tempo_descanso.value, 'Faça uma pausa de')
            
            self.Respiro()
            
            if not self.pomodoro_control_thread:
                break
            MessageBeep(MB_ICONHAND)

            if not self.pomodoro_control_thread:
                break
            # self.Pausar()
            texto = 'Volte a treinor por '

        self.quado_saida.controls =  None

    def Ini_Thread(self, controle, argu=''):
        if controle == 'pomodoro':
            self.Metro_normal.setOn = False
            # sleep(0.3)
            self.Metro_normal.setOn = True
            if self.pomodoro_control_thread:
                # print('self.tempo_pomodoro:', (self.tempo_pomodoro.value), (self.tempo_descanso.value))
                if self.tempo_pomodoro_set != '' and self.tempo_descanso_set != '':
                    try:
                        self.tempo_pomodoro_set, self.tempo_descanso_set = float(
                            self.tempo_pomodoro_set), float(self.tempo_descanso_set)
                    except TypeError:
                        print('Erro na conversão dos tempo_pomodoro e tempo_descanso', TypeError)
                        self.tempo_pomodoro_set, self.tempo_descanso_set = 3, 1


                    Thread(target=self.Pomodoro, daemon=False).start()#########################################
                    # self.Pomodoro()
            else:
                print('pomodoro_control_thread desabilitado')

        elif controle == 'beep':
            if not self.metronomo_iniciado:
                Thread(target=self.Metro_normal.beep, daemon=False).start()
                self.metronomo_iniciado = True
            else:
                print('metronomo já iniciado')

        elif controle == 'Treinamento':
            self.Treinar()
            # print('vai reinar')
            if self.passo_fim_set < self.passo_set or self.passo_set == -1:
                if self.metronomo_iniciado:
                    if not self.treinando:
                        self.treinando = True
                        Thread(target=self.Treinamento, args=argu, daemon=False).start()
                        # self.Treinamento(argu)

        elif controle == 'Executar tarefas':
            self.Treinar()
            if not self.treinando:
                self.treinando = True
                Thread(target=self.Executar_tarefas, args=argu, daemon=False).start()

            else:
                raise ValueError(
                    "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")

        elif controle == 'compassos':
            self.Treinar()
            if self.passo_fim_set < self.passo_set:
                if self.metronomo_iniciado:
                    if not self.treinando:
                        self.treinando = True
                        Thread(target=self.Treinamento_compassos,
                            daemon=False).start()

            else:
                # raise ValueError(
                #     "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")
                self.Prints(
                    "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")
    
    def Treinar(self):
        if self.progressivo:
            if not self.tempo_set:
                # print('self.meta.value:', type(self.meta.value), self.meta.value)
                # print('self.inicio.value:', type(self.inicio.value), self.inicio.value)
                # print('self.passo.value:', type(self.passo.value), self.passo.value)
                # print('self.intervalo.value:', type(self.intervalo.value), self.intervalo.value)
                self.tempo_de_treino = int(((self.meta_set - self.inicio_set)/self.passo_set)*self.intervalo_set)
                self.t_total = self.tempo_de_treino
                horas, minutos, segundos = self.converter_segundos_para_horas_min_segundos(self.tempo_de_treino)
                self.quado_saida.content = Text(f"Duração do treino: {horas}:{minutos}:{segundos}")
                self.intervalo2 = self.intervalo_set

            else:

                self.intervalo2 = round((self.t_total*self.passo_set)/(self.meta_set - self.inicio_set), 3)
                horas, minutos, segundos = self.converter_segundos_para_horas_min_segundos(self.t_total)
                self.quado_saida.content = Text(f"Duração do treino: {horas}:{minutos}:{segundos}")

            if self.inverter.value:
                self.Metro_normal.setBpm(self.meta_set)
                self.display_bpm.value = self.meta_set
                self.meta2 = self.inicio_set
                self.passo_set = -1*self.passo_set

            else:
                self.Metro_normal.setBpm(self.inicio_set)
                self.display_bpm.value = self.inicio_set
                self.meta2 = self.meta_set
                # self.passo2 = self.passo_set


            if not self.inverter_set and self.passo_fim_set not in [0, '', None]:
                distancia_bpm = self.meta_set - self.inicio_set
                self.dist_passo = self.passo_set - self.passo_fim_set
                self.constante_de_tempo = ((self.meta_set - self.inicio_set)*self.intervalo2)
                self.x = [0.25, 0.5, 0.75, 0.9, 1]
                self.incrementos = [y*distancia_bpm +  self.inicio_set for y in self.x]
                ii = 0

            else:
                self.dist_passo = 0

        else:
            self.Metro_normal.setBpm(self.inicio_set)
            self.display_bpm.value = self.inicio_set
        
        super().update()

    def Treinamento(self, tarefa_exec=''):
        self.quado_saida.visible = True
        # self.saida_respiro.visible = False
        self.saida_treinamento.visible = True
        self.saida_treinamento.controls = [Text('Treino iniciado...'), Text()]
        super().update()
        print('Treino iniciado...')
        # print(f'tarefa_exec = {tarefa_exec}')

        # print(f'dist_passo = {dist_passo} \npasso = {self.passo} \nbpm = {bpm}\n')
        def Finalizacao_treino():
            self.saida_treinamento.controls = [Text('Treino Finalizado...')]
            # self.Piscar_infos
            self.EscreveTxt(tarefa_exec)
            # self.EscrevePlanilha(tarefa_exec)
            self.quado_saida.controls = None

        ii = 0
        self.tempo_restante = float(self.t_total) + self.intervalo2

        if tarefa_exec == '':
            tarefa_exec = f'{Data()} .-. {"sem nome"} .-. {round(self.tempo_restante/60,1)}min .-. BPM({self.inicio} a  ) .-. passo:   .-. intervalo:  s'

        if self.progressivo:
            while (teste := (bpm := self.Metro_normal.getBpm) > self.meta2 if self.inverter_set else (bpm := self.Metro_normal.getBpm) < self.meta2):
                self.Exibir_tempo_restante()


                sleep(self.intervalo2)
                self.tempo_restante -= self.intervalo2

                ii = self.Variador_de_passo(bpm, ii)
                self.up_bpm(self.passo_set)
                self.saida_treinamento.controls[1] = Text(f'({self.display_bpm.value} bpm)') if self.Modo == 'tarefas' else Text()
                super().update()


                # Para caso o de o botão pause ser pressionado
                while self.Metro_normal.pause:
                    sleep(0.1)

                # Para caso o de o botão Stop ser pressionado
                if self.treinando == False or self.Treino_habilitado_set == False or self.tempo_restante <= 0:
                    break

            # para quando a bpm passa da meta
            if (teste2 := bpm < self.meta2 if self.inverter_set else bpm > self.meta2):
                bpm = self.meta2
                self.display_bpm.options.append(dropdown.Option(bpm))
                self.display_bpm.value = bpm
                self.Metro_normal.setBpm(bpm)
                super().update()

            if bpm == self.meta2 or self.tempo_restante == 0:
                # self.saida_treinamento.controls = [Text('Treino finalizado...')]
                MessageBeep(MB_ICONHAND)

        else:
            while self.tempo_restante >= 0:
                self.Exibir_tempo_restante()
                sleep(1)
                self.tempo_restante -= 1
                while self.pause:
                    sleep(0.1)
                if self.treinando == False or self.Treino_habilitado_set == False or self.tempo_restante <= 0:
                    break

            if self.tempo_restante == 0:
                MessageBeep(MB_ICONHAND)

        Thread(target=Finalizacao_treino, daemon=True).start()
        self.Testar_continuidade()
        self.saida_treinamento.visible = False
        self.saida_treinamento.controls = None
        self.quado_saida.visible = False
        self.quado_saida.controls = None
        super().update()

    def Treinamento_compassos(self):
        self.quado_saida.visible = False
        self.saida_respiro.visible = False
        self.saida_treinamento.visible = True
        self.saida_treinamento.controls = [Text('Treino compassos iniciado...')]
        super().update()
        print('Treino compassos iniciado...')

        # self.setBpm = self.inicio

        # self.setBpm = meta
        # self.cont_tempos = 0
        # self.cont_compassos = 0
        ii = 0
        # print(f'\nself.treinando = {self.treinando}\nself.treino_habilitado = {self.treino_habilitado}')
        while (teste := (bpm := self.Metro_normal.getBpm) > self.meta2 if self.inverter_set else (bpm := self.Metro_normal.getBpm) < self.meta2):
            # if self.dist_passo != 0:
            #     if ii >= 3:
            #         if bpm >= self.incrementos[ii]:
            #             self.passo = self.passo_fim
            #             self.tempo_restante = int(
            #                 self.constante_de_tempo/self.passo)
            #             print(f'passou dos {self.x[ii]*100}% da meta')

            #     elif bpm >= self.incrementos[ii] and bpm < self.incrementos[ii+1]:
            #         self.passo = self.passo_fim + \
            #             (1-self.x[ii])*self.dist_passo
            #         self.tempo_restante = int(
            #             ((self.meta - bpm)*self.intervalo)/self.passo)
            #         print(f'passou dos {self.x[ii]*100}% da meta')
            #         ii += 1
            ii = self.Variador_de_passo(bpm, ii)
            # print(f'bpm = {bpm}\nteste = {teste}')
            while self.Metro_normal.cont_tempos != self.Tipo_compasso.value*self.qtd_compassos.value:
                sleep(0.01)

            self.Metro_normal.cont_tempos = 0
            self.up_bpm(self.passo.value)


            # Para caso o de o botão pause ser pressionado
            while self.Metro_normal.pause:
                sleep(0.1)
            # Para caso o de o botão Stop ser pressionado
            if self.treinando == False or self.Treino_habilitado.value == False:
                break

        # para quando a bpm passa da meta
        if (teste2 := bpm < self.meta2 if self.inverter_set else bpm > self.meta2):
            self.up_bpm(self.meta2)
            bpm = self.meta2

        if bpm == self.meta2:
            MessageBeep(MB_ICONHAND)


            self.saida_treinamento.controls = [Text('Treino Finalizado...')]
            super().update()
            # self.EscreveTxt(tarefa_exec)
            # self.EscrevePlanilha(tarefa_exec)

            # fazer o nome ficar pisacando na tela
            # for i in range(4):
            #     self.window['-tempo_restante-'].update(text_color='#ffff80')
            #     sleep(0.5)
            #     self.window['-tempo_restante-'].update(text_color='red')
            #     sleep(0.5)
            # self.window['-tempo_restante-'].update(text_color='#4ab580')
            # self.Piscar_infos
            self.Testar_continuidade()
            self.saida_treinamento.visible = False


        # if self.continuar == False:
        #     self.pomodoro_habilitado = False
        #     self.treinando = False
        #     self.setOn = False

    def Testar_continuidade(self):
        if self.continuar.value == False and not self.play_tarefas_set:
            self.pomodoro_control_thread = False
            self.treinando = False
            self.Metro_normal.setOn = False
            self.quado_saida.controls = None
        elif self.play_tarefas_set:
            # self.pomodoro_habilitado = False
            self.treinando = False
            self.Metro_normal.setOn = False
        # self.Restaurar_cores
        self.metronomo_iniciado = False

    def Variador_de_passo(self, bpm, ii):
        if self.dist_passo != 0:
            if ii >= 3:
                if bpm >= self.incrementos[ii]:
                    self.passo_set = self.passo_fim_set
                    self.tempo_restante = int(
                        self.constante_de_tempo/self.passo_set)
                    print(f'passou dos {self.x[ii]*100}% da meta')

            elif bpm >= self.incrementos[ii] and bpm < self.incrementos[ii+1]:
                self.passo_set = self.passo_fim_set + \
                    (1-self.x[ii])*self.dist_passo
                self.tempo_restante = int(
                    ((self.meta_set - bpm)*self.intervalo2)/self.passo_set)
                print(f'passou dos {self.x[ii]*100}% da meta')
                ii += 1
        return ii
    
    def Exibir_tempo_restante(self):
        self.saida_treinamento.visible = True
        tempo = self.tempo_restante
        horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(tempo)
        self.saida_treinamento.controls[0] = Text(f"Tempo restante: {horas2}:{minutos2}:{segundos2}")
        super().update()

    @classmethod    
    @property
    def nometarefastxt(self):
        return Juntar(getcwd(), 'tarefas.txt')
    @classmethod    
    def EscreveTxt(self, texto):
        try:
            with open(self.nometarefastxt, 'a') as arq:
                arq.write(f'{texto}\n')
        except:
            with open(self.nometarefastxt, 'w') as arq:
                arq.write(f'{texto}\n')
        print(f'A tarefa foi salva em {self.nometarefastxt}')

    def EscrevePlanilha(self, texto):
        # texto = f'11-10-2023-14:56:53 .-. Estágio 3 .-. 5min .-. BPM(140 a 150) .-. passo: 0.1 .-. intervalo: 3.0s'
        # print(texto)
        b = texto.split(' .-. ')
        d, m, y = b[0].split('-')[:3]
        h = b[0].split('-')[3]
        data = f'{d}/{m}/{y} {h}'
        nome = b[1]
        duracao = b[2][:-3]

        # if self.progressivo:    # or nome == 'sem nome'
        try:
            resultado = search(r'BPM\((\d+) a (\d+)\)', b[3])
            print(f'resultado = {resultado}')
            bpm_in = resultado.group(1)
            bpm_fim = resultado.group(2)
            passo = b[4][7:]
            intervalo = b[5][10:-1]
        except:
            resultado = search(r'BPM\((\d+(\.\d+)?) a', b[3])
            print(f'resultado = {resultado}')
            bpm_in = resultado.group(1).split('.')[0]
            bpm_fim = ''
            passo = ''
            intervalo = ''

        valores = [[data, nome, duracao, bpm_in, bpm_fim, passo, intervalo]]

        n_linhas = 1+len(p := LerCelulas(self.nome_planilha,
                         'metronomo!A:h', nome_da_credencial))
        AtualizarCelulas(
            self.Selecionar_planilha.value, f'metronomo!A{n_linhas}:h', valores, nome_da_credencial)
    
    @classmethod
    def converter_segundos_para_horas_min_segundos(self, segundos):
        def Algarismos(numero, qtd=2):
            numero = int(numero)
            return str(numero).zfill(qtd)
        horas = segundos // 3600  # 3600 segundos em uma hora
        horas = Algarismos(horas)
        segundos %= 3600
        minutos = segundos // 60  # 60 segundos em um minuto
        minutos = Algarismos(minutos)
        segundos %= 60
        segundos = Algarismos(segundos)

        return horas, minutos, segundos
    def Tap_bpm(self):
        print('tap pressionado')
        if not self.iniciar_medicao_bpm:
            self.ti = time()
            self.iniciar_medicao_bpm = not self.iniciar_medicao_bpm
        else:
            self.tf = time()
            # print(f'delta T = {self.tf-self.ti}')
            new_bpm = round(int(60/(self.tf-self.ti)), 0)
  
            if new_bpm <=30:
                new_bpm = 30
            elif  new_bpm>549:
                new_bpm = 549
            # print(new_bpm)
            # print(type(new_bpm))
            # print('tipo self.Metro_normal.setBpm(new_bpm) = ', type(self.Metro_normal.setBpm(new_bpm)))    
            self.display_bpm.options.append(dropdown.Option(new_bpm))
            self.display_bpm.value = new_bpm
            self.Metro_normal.setBpm(new_bpm)
            super().update()


            self.ti = None
            self.tf = None
            self.iniciar_medicao_bpm = not self.iniciar_medicao_bpm
    def Teclas(self, e: KeyboardEvent):
        if self.Modo == 'normal':
            match e.key:
                case ' ':
                    self.Play3()              
                    print('pressionou space') 
                case 'Enter':
                    self.Metro_normal.Stop()            
                    print('pressionou enter')
                case 'P':
                    self.Metro_normal.Pause()               
                    print('pressionou P')
                case 'Numpad 7':
                    self.up_bpm(1)
                case 'Numpad 8':
                    self.up_bpm(5)                 
   
                case 'Numpad 9':
                    self.up_bpm(10)                  

                case 'Numpad 1':
                    self.up_bpm(-1)                  
                case 'Numpad 2':
                    self.up_bpm(-5)                    
   
                case 'Numpad 3':
                    self.up_bpm(-10)                   
 
                case 'Numpad 5':
                    self.Tap_bpm()

                # case 'Numpad 4':
                #     self.check_display()                                                                                         
   
        super().update()
        

    
def main(page: Page):
    page.title = "Exemplo Layout"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = '#000000', #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750
    
    # layout = Quadro(page, 
    #                 width = page.window_width-1,
    #                 height= page.window_height-55,  
    #                 border_color = 'white',
    # )
    # layout.contet = Column(Text('kjhkjhkj', size = 200, color='white'))
    def Exibir_atributos(objeto):
        for i in objeto.__dict__.keys():
            print(i) 
    app = Layout(page)
    # pomodoro_habilitado = Checkbox()
    # pomodoro = Row([pomodoro_habilitado, Text('Pomodoro'),Quadro(Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 1)) ], spacing=0)
    # Exibir_atributos(pomodoro.controls)  
    # print(pomodoro_habilitado.value)          
    page.add(app)
    # page.add(self.menu_bar,modos,quadro_pomodoro,quadro_botoes, quado_saida)
    # page.add(col_tarefas)

    page.update() 
# app(target=main, view=AppView.WEB_BROWSER)


def main2(page: Page):
    page.title = "Metrônomo"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750

    app = Layout(page)
    page.on_keyboard_event = app.Teclas
    
    page.window_focused = True
    # print(page.window_focused)
    s = Saidas()
    s.texto1 = 'Pomodoro iniciado ............. (00:00:00)'
    s.texto1_color = 'green'
    # s.texto1_size = 12
    s.texto2 = '22222222222222222222'
    s.texto2_color = 'yellow'
    s.texto3 = '333333333333333333'
    s.texto4 = '444444444444444444'
    s.texto5 = '555555555555555'
    s.texto6 = '666666666666666666'
    quado_saida = Container(width=775,height = 120, 
                                     border= border.all(1, color = 'white'),
                                    #  margin = margin.all(0),
                                    # padding = 0,
                                    # alignment = Alignment(-1,-1),
    )
    
    page.add(app)
    def Mostrar(*texto):
        quado_saida.content = Saidas(*texto, cor  = 'white', size = 25)
        # quado_saida.content.texto1_size = 30
        page.update()

    def Mostrar2(*texto):
        return Saidas(*texto)
     

    # page.add(quado_saida)
    
    # Mostrar('cú assssssssssssss   ddddddddddddd', 'bunda', 'buceta', 'cabaço', 'sexo')
    # page.add(b)
    # page.add(quado_saida)
    # s = Container(s, bgcolor = 'red')



    page.update()

    # page.add_async(TextButton(visible=False, autofocus=True))
    # page.add_async(app)
    # page.add(Countdown(40, 'Volte a treinar por '))

def main3(page: Page):
    page.title = "texte"
    page.horizontal_alignment = "center"
    page.window_width = 780
    page.window_height = 750



    quado_saida = Container(width=775,height = 120, 
                                     border= border.all(1, color = 'white'),
                                    #  margin = margin.all(0),
                                    # padding = 0,
                                    # alignment = Alignment(-1,-1),
    )
    

    def Mostrar(*texto):
        quado_saida.content = Saidas(*texto, cor  = 'white', size = 25)
        # quado_saida.content.texto1_size = 30
        page.update()

    # Mostrar('mina pica')
    def add_view(*texto, cor  = 'white', size = 20):
        try:
            if quado_saida.content.texto1 == '':
                pass

            for i in texto:  
                if quado_saida.content.texto1 == '':
                    quado_saida.content.texto1 = i
                    quado_saida.content.texto1_color = cor
                    quado_saida.content.texto1_size = size
    

                elif quado_saida.content.texto2 == '':
                    quado_saida.content.texto2 = i
                    quado_saida.content.texto2_color = cor
                    quado_saida.content.texto2_size = size
    

                elif quado_saida.content.texto3 == '':
                    quado_saida.content.texto3 = i
                    quado_saida.content.texto3_color = cor
                    quado_saida.content.texto3_size = size
    

                elif quado_saida.content.texto4 == '':
                    quado_saida.content.texto4 = i
                    quado_saida.content.texto4_color = cor
                    quado_saida.content.texto4_size = size
    

                elif quado_saida.content.texto5 == '':
                    quado_saida.content.texto5 = i
                    quado_saida.content.texto5_color = cor
                    quado_saida.content.texto5_size = size
    

                elif quado_saida.content.texto6 == '':
                    quado_saida.content.texto6 = i
                    quado_saida.content.texto6_color = cor
                    quado_saida.content.texto6_size = size

                else:
                    print('limite de saidas atingido')

        except:
            quado_saida.content = Saidas(*texto, cor  = cor, size = size)
                            
        page.update()



    add_view('asaddsasdaa', 'aaaaaaaa',cor = 'green', size = 20)  
    add_view('vvvvvvvvvvvvv', 'iiiiiiiiiiiii', cor  = 'yellow', size = 20)  
    add_view('ccccccccccccc', 'vvvvvvvvvvvv', cor  = 'red', size = 10)  


    page.add(quado_saida)

    page.update()

def main_test(page: Page):
    page.title = "Metrônomo"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750


    p = Pomodoro()



    page.add(p)
  


    page.update()



app(target=main_test)