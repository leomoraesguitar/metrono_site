from flet import*
from Swhitch_new import Switch_new
from controlador_metronomo_flet import Escrever_json, Ler_json, Thread
from metronomo import Metronomo, sleep, time
from winsound import MessageBeep, MB_ICONHAND
# from saidas import Saidas
from funcoes_leo.funcoes import Data, Juntar
from os import getcwd
from re import search
from googlesheets_leo import AtualizarCelulas, LerCelulas
from pomodoro_flet import Pomodoro
from Treinamento_flet import Treinamento
from Treinamento_compassos_flet import Compassos
from meus_controles import*
import asyncio
__docformat__ = "restructuredtext"


config = 'config_metronomo_exemplo.json'
config_gerais = 'config_gerais_metronomo.json'
try:
    nome_da_credencial = 'client_secret.json'
except:
    print(f'O arquivo "client_secret.json" não foi encontrado')  


class Layout(UserControl):
    def __init__(self,
        page,
        ):
        super().__init__() 
        self.page = page
        self.Metro_normal = Metronomo()
        self.Modo = 'normal'
        self.pause_lay = False
        # self.saida = Saidas()
        self.Iniciar_arquiv()
        self.arquiv_config = Ler_json(config_gerais)


        #parâmetros do metrônomo
        self.metronomo_iniciado = False
        self.parar = False
        self.play_tarefas = False
        self.pomodoro_control_thread = False
        self.iniciar_medicao_bpm = False
        self.t_total = None
        self.Treino_habilitado_set = False
        self.inverter_set = False
        self.tempo_set = False
        self.passo_set = 1
        self.passo_fim_set = 0
        self.intervalo_set = 1
        self.tempo_pomodoro_set = 1
        self.tempo_descanso_set = 1
        self.play_tarefas_set = False
        # self.th_t = Thread(daemon=False)



        self.col_tarefas = Column(tight=True, spacing=0)
        self.Importar = TextButton('Importar', on_click=self.acoes_botoes_layout, data = 'Importar')
        self.Exportar = TextButton('Exportar', on_click=self.acoes_botoes_layout, data = 'Exportar')
        self.Selecionar_planilha = TextButton('Selecionar Planilha', on_click=self.acoes_botoes_layout, data = 'Selecionar Planilha')
        #1-vU6ONr6gZTcpOI-inXlzpiwcPqUpDgBgXnPXvjkPjk
        cor_botoes_bpm = colors.PINK_50
        # self.Bot_m1 = TextButton('+1', expand=0, on_click=self.acoes_botoes_layout, data = 'Bot_m1', height = 40, width=80 )
        self.Bot_m1 = Botao('+1', on_click=self.acoes_botoes_layout, data = 'Bot_m1', width=80 )
        self.Bot_m5 = Botao('+5',  on_click=self.acoes_botoes_layout, data = 'Bot_m5',  width=80)
        self.Bot_m10 = Botao('+10',  on_click=self.acoes_botoes_layout, data = 'Bot_m10',  width=80)
        self.Bot_m_1 = Botao('-1',  on_click=self.acoes_botoes_layout, data = 'Bot_m_1', width=80)
        self.Bot_m_5 = Botao('-5', on_click=self.acoes_botoes_layout, data = 'Bot_m_5', width=80)
        self.Bot_m_10 = Botao('-10',  on_click=self.acoes_botoes_layout, data = 'Bot_m_10',  width=80)
        self.display_bpm = Dropdown(data = 'valorbpm',
                    alignment= Alignment(0, 1),
                    options=[dropdown.Option(i) for i in range(30,550,1)],
                    text_size = 20,
                    border=0,
                    border_radius = 20,
                    border_color=colors.with_opacity(0.1,'white'),
                    prefix_text = 'bpm: ',
                    # expand=1,
                    value = self.arquiv_config["bpm"],
                    width = 150,
                    # aspect_ratio = 0.5,
                    # height = 200,
                    # content_padding = 0,
                    text_style = TextStyle(weight = 'bold'),
                    on_change=self.acoes_botoes_layout
                                                    
            )
        self.display_bpm.options.append(dropdown.Option(self.arquiv_config["bpm"]))        

        self.vol  =  Slider(active_color = '#004499',thumb_color = '#333333',min = 0, max = 10, divisions=10, value = self.arquiv_config["vol"],label='{value}', width=130, on_change=self.acoes_botoes_layout, data = 'vol')
        self.inverter = Checkbox(on_change=self.acoes_botoes_layout, data = 'Inverter', value = self.arquiv_config["inverter"])
        self.Treino_habilitado = Checkbox(on_change=self.acoes_botoes_layout, data = 'Treino_habilitado', value = self.arquiv_config["Treino_habilitado"])
        self.Tap = IconButton(icon = icons.CIRCLE,on_click=self.acoes_botoes_layout, data = 'Tap')

        tamanho_slids = 300
        self.meta = Slider_new('Meta',30, 300, 270, 1,0, width = 200, on_change = self.acoes_botoes_layout, data = 'meta',value = self.arquiv_config["meta"], )
        self.inicio = Slider_new('Início',30, 300, 270, 1,0, width = 200, on_change = self.acoes_botoes_layout, data = 'inicio',value = self.arquiv_config["inicio"], )
        self.passo = Slider_new('passo',0, 5.0, 50, 1,1, width = 200, on_change = self.acoes_botoes_layout, data = 'passo',value = self.arquiv_config["passo"], )
        self.passo_fim = Slider_new('Passo_fim',0, 5.0, 50, 1,1, width = 175, on_change = self.acoes_botoes_layout, data = 'passo_fim',value = self.arquiv_config["passo_fim"], )


        # self.intervalo  =  Slider(min = 1, max = 30, divisions=31, label='{value}', width=300,on_change=self.acoes_botoes_layout, data = 'intervalo')
        self.intervalo  =  Slider_new('',1, 30, 50, 1,1, width = 150, on_change = self.acoes_botoes_layout, data = 'intervalo',value = self.arquiv_config["intervalo"], )
        self.tempo = Checkbox(on_change=self.acoes_botoes_layout, data = 'tempo', value  = False)
        self.Tipo_compasso = Drop_new(['2/4', '3/4', '4/4'], self.arquiv_config["Tipo_compasso"],
                                      on_change=self.acoes_botoes_layout, data = 'Tipo_compasso'
                                      )
        self.qtd_compassos = Drop_new([i for i in range(1,48)], self.arquiv_config["qtd_compassos"],
                                      on_change=self.acoes_botoes_layout, data = 'qtd_compassos'
                                      )
        self.tempo_compasso = 'Tempo'

        self.continuar = Checkbox(on_change=self.acoes_botoes_layout, data = 'continuar', value = self.arquiv_config["qtd_compassos"])
        self.pomodoro_habilitado = Checkbox(on_change=self.acoes_botoes_layout, data = 'pomodoro_habilitado', value = self.arquiv_config["pomodoro_habilitado"])
        self.tempo_pomodoro = Drop_new([0.1,0.3,0.5]+[i for i in range(1,31)], self.arquiv_config["tempo_pomodoro"],
                                       on_change=self.acoes_botoes_layout, data = 'tempo_pomodoro'
                                       )
        self.tempo_descanso = Drop_new([0.5]+[i for i in range(1,31)], self.arquiv_config["tempo_descanso"],
                                       on_change=self.acoes_botoes_layout, data = 'tempo_descanso'
                                       )        
        self.p = None

        self.task_lis_select = Dropdown(                
            alignment= Alignment(-1, 1),
            options=[dropdown.Option(i) for i in self.arquiv.keys()],
            text_size = 20,
            border_color=colors.with_opacity(0.1,'white'),
            value = 'Padrão',
            color = colors.with_opacity(1,'white'),
            height = 30,
            expand= 1,
            content_padding = 0,
            autofocus = 0,
            on_change=self.acoes_botoes_layout, data = 'task_lis_select'

        )
        self.new_list_task = TextField(hint_text = 'nome da nova lista de tarefas', width = 150, expand= 1,)
        self.add_new_list_tasks = ElevatedButton(text='Add.', width = 80,on_click=self.acoes_botoes_layout, data = 'add new list task')

        tamanho_botao = 170
        self.play = IconButton(icon_color = 'blue',icon=icons.PLAY_ARROW, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'play')
        # self.play = Botao(icon=icons.PLAY_ARROW, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'play', rot = 40)
        self.pause = IconButton(icon_color = 'blue',icon=icons.PAUSE, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'pause')
        self.stop = IconButton(icon_color = 'blue',icon=icons.STOP, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'stop')
        self.salvar = IconButton(icon_color = 'blue',icon=icons.SAVE, width = tamanho_botao,on_click=self.acoes_botoes_layout, data = 'salvar')

        self.quado_saida = Column()
        self.saida_respiro = Column(visible=False)
        self.saida_treinamento = Row(visible=False)
        self.treinamento = None
        self.treinamento_compassos = None
        self.parar_tarefas = False

        # self.quado_saida = Quadro_assync(width=775,height = 120)
        # self.quado_saida = Container(content = Countdown(40, 'Volte a treinar por '), width=775,height = 120, border= border.all(1, color = 'white'),)       

        # self.add_tarefa = OutlinedButton('Add tarefa', on_click=self.acoes_botoes_layout, data = 'add new task')
        # self.play_tarefas = OutlinedButton('Play Tarefas',on_click=self.acoes_botoes_layout, data = 'Play Tarefas')
        self.add_tarefa = Botao('Add tarefa', on_click=self.acoes_botoes_layout, data = 'add new task', width=150 )
        self.play_tarefas = Botao('Play Tarefas', on_click=self.acoes_botoes_layout, data = 'Play Tarefas', width=150 )
        

    @property
    def get_pomodoro_habilitado(self):
        return self.pomodoro_habilitado.value
    @get_pomodoro_habilitado.setter
    def pomodoro_habilitado_value(self, valor:bool):
        self.pomodoro_habilitado.value = valor
        super().update()
    
    
    def build(self):
        bor = border.BorderSide(5, colors.with_opacity(0.7,'white')) 
        
        sombra =  BoxShadow(
            spread_radius=0,
            blur_radius=1,
            color=colors.with_opacity(0.2,'blue'),
            offset=Offset(3, 3),
            blur_style=ShadowBlurStyle.SOLID)
        gradiente =  gradient=LinearGradient(
            begin=Alignment(-1, -1),
            end=Alignment(-0.1, -0.1),
            
            colors=[
                "#777777",
                "#000000",
                "#000000",
                        ],
            tile_mode=GradientTileMode.MIRROR,
            rotation=50*3.14/180,
        )        
        def Container_new(i, rot = 50):
            gradiente =  gradient=LinearGradient(
                begin=Alignment(-1, -1),
                end=Alignment(-0.1, -0.1),
                
                colors=[
                    "#777777",
                    "#000000",
                    "#000000",
                            ],
                tile_mode=GradientTileMode.MIRROR,
                rotation=rot*3.14/180,
            ) 


            return Container(content=i,   shadow = sombra, border_radius = 15, gradient=gradiente)
            
        
        
        menu_bar = Row([
            self.Importar,
            self.Exportar,
            self.Selecionar_planilha,
        ], height=18)   


        bts = [self.Bot_m1, \
            self.Bot_m5, \
            self.Bot_m10, \
            Container_new2(self.display_bpm),\
            self.Bot_m_1, \
            self.Bot_m_5, \
            self.Bot_m_10] 
        
        # bts = [Container_new(i) for i in bts]       
        quadro_bpm = Container_new(Row(bts, alignment=MainAxisAlignment.SPACE_AROUND), rot = 60)  
        

        vol = Row([Text('Vol'),self.vol],spacing=0,)
        inverter = Row([self.inverter, Text('Inverter')], spacing=0)
        Treino_habilitado= Row([self.Treino_habilitado , Text('Treino_habilitado')], spacing=0)        
        tap = Row([Text('Tap'),self.Tap], spacing=0)   
        quadro_vol = Container_new2(Row([vol, inverter, Treino_habilitado, tap], alignment=MainAxisAlignment.SPACE_AROUND))
        
        
        tamanho_slids = 300
        altura = 155
        meta  =  Row([Text('Meta'),self.meta],spacing=0,)
        inicio  =  Row([Text('Inicio'),self.inicio],spacing=0,)
        passo  =  Row([Text('Passo'),self.passo],spacing=0,)
        col_trainamento = Container(Column([self.meta, self.inicio, self.passo,  self.passo_fim], spacing=5), padding = 20, height=altura)


        def Caixa(data):
            return TextField(
                # color='white', 
                width=60, 
                height=30,
                # max_lines = 1, border = InputBorder.OUTLINE , 
                                border_color=colors.with_opacity(0.2,'white'),
                                text_style = TextStyle(weight = 'bold'), 
                                text_size=15,
                                # scale=0.4, 
                                dense = True, 
                                color=colors.WHITE,

                                on_submit = self.acoes_botoes_layout,
                                data = data,
                                # border_width = 1,

                               )
        self.intervalo_caixa = Caixa('caixa_intervalo')        
        self.meta_caixa = Caixa('caixa_meta')        
        self.inicio_caixa = Caixa('caixa_inicio')
        self.passo_caixa = Caixa('caixa_passo') 
        self.passo_fim_caixa = Caixa('caixa_passo_fim')  

        self.intervalo_caixa.value =  self.intervalo.value
        self.meta_caixa.value =  self.meta.value   
        self.inicio_caixa.value =  int(self.inicio.value)
        self.passo_caixa.value =  1*self.passo.value
        self.passo_fim_caixa.value =  1*self.passo_fim.value
        

        # meta_caixa = Container(content = meta_caixa, bgcolor='black',width= 50,height=50,border = border.only(bottom=border.BorderSide(3, colors.with_opacity(0.3,'white'))), alignment = alignment.top_center)
        # col_caixas_trainamento = Container(Column([Text(), meta_caixa,meta_caixa,meta_caixa,meta_caixa], spacing=10), padding = 10)
        col_caixas_trainamento = Column([self.meta_caixa,self.inicio_caixa, self.passo_caixa, self.passo_fim_caixa ], spacing=10, run_spacing = 15, height=altura)

        intervalo = Row([Text('Intervalo'),self.intervalo, Text(width = 40),self.intervalo_caixa],spacing=0,)
        tempo = Row([self.tempo, Text('Tempo (min)')], spacing=0)
        Tipo_compasso = Row([Text('Tipo de Compasso'),self.Tipo_compasso])
        qtd_compassos = Row([Text('Qtd de Compasso'),self.qtd_compassos])

        self.tab_compassos = Container(Row([Tabs(
            selected_index=0,
            animation_duration=300,
            divider_color  = 'blue',
            indicator_tab_size = True,
            tabs=[
                Tab(
                    text="Tempo",
                    content=Column([intervalo, tempo])
                ),
                Tab(
                    text="Compassos",
                    # tab_content=Icon(icons.SEARCH),
                    content=Column([Tipo_compasso, qtd_compassos])
                ),
            ],
            width=350,
            height=130,
            on_change = self.acoes_botoes_layout,
            data = 'tempo_compasso',
            # expand=1,
            )
            ]),
            expand = 0,padding = 12,
        )
    
        
        quadro_trainamento = Container(Row([
                                            Container_new2(Row([
                                            col_trainamento,
                                            Container(width = 10, height=130, padding=50),
                                            col_caixas_trainamento], width=350)),
                                            Container(width = 1,bgcolor=colors.with_opacity(0.2,'blue'), height=130),

                                            # Divider(color='white', height=200, thickness = 10, opacity = 1),
                                            Container_new2(self.tab_compassos)],vertical_alignment = 'start',alignment=MainAxisAlignment.SPACE_AROUND),border= border.all(0.3, color = colors.with_opacity(0.5,'blue')),border_radius = 10,)
        
        # quadro_trainamento = Container_new2(quadro_trainamento)


        Treinamento = Container(Column([quadro_bpm,Container_new2(Row([self.task_lis_select, self.new_list_task, self.add_new_list_tasks],height= 35,alignment=MainAxisAlignment.SPACE_BETWEEN)),quadro_vol,quadro_trainamento]),border= border.all(0.1, color = 'blue'),border_radius = 10,)
        # Treinamento = Quadro_assync(Column([quadro_bpm,Row([self.task_lis_select, self.new_list_task, self.add_new_list_tasks],height= 35,alignment=MainAxisAlignment.SPACE_BETWEEN),quadro_vol,quadro_trainamento]))
        Treinamento = Container_new2(Treinamento)

        quadro_botoes = [self.play, self.pause, self.stop, self.salvar]

        # border = border.Border(left=bor,right=None, top=bor, bottom=None ),
        quadro_botoes = [Container_new2(i) for i in quadro_botoes]
        # quadro_botoes = Quadro(Row(quadro_botoes,alignment=MainAxisAlignment.SPACE_AROUND))
        # quadro_botoes = Container(Row(quadro_botoes,alignment=MainAxisAlignment.SPACE_AROUND),border= border.all(0.1, color = 'gray'),border_radius = 50,)
        quadro_botoes = Row(quadro_botoes,alignment=MainAxisAlignment.SPACE_AROUND)

        self.tempo_das_tarefas = Text('tempo aqui', color = 'blue')

        botos_tarefas = Row([self.add_tarefa, self.play_tarefas, Row([Text('Duração total: '), self.tempo_das_tarefas])], alignment=MainAxisAlignment.SPACE_AROUND)
        titulos_tarefas = Row([
            VerticalDivider(width=120),
            Text('Treino'),
            VerticalDivider(width=100),
            Text('Duração'),
            VerticalDivider(width=35),
            Text('In'),
            VerticalDivider(width=40),
            Text('Fim'),
            VerticalDivider(width=40),
            Text('Passo'),                                                   
        ])
        
        self.col_tarefas.scroll = ScrollMode.ALWAYS
        Tarefass = Column([
            Container(Row([self.task_lis_select, self.new_list_task, self.add_new_list_tasks],height= 35,alignment=MainAxisAlignment.SPACE_BETWEEN)),
            botos_tarefas,
            titulos_tarefas, 
            Container(self.col_tarefas,
            alignment=Alignment(-1,-1),
            border= border.all(0.1, color = 'blue'),
            border_radius = 6,
            height= 305,
        )
                            ], height=350, expand=0)       
        # Tarefass.scroll = ScrollMode.ALWAYS


        for i in self.arquiv['Padrão']:
            valor = list(i.values())
            t1 = New_task(self.acoes_tasks, *valor)
            self.col_tarefas.controls.append(t1)



        
        modos = Tabs(
            selected_index=0,
            animation_duration=300,
            divider_color  = 'blue',
            tabs=[
                Tab(
                    text="Treinamento",
                    content=Treinamento
                ),
                Tab(
                    text="Tarefas",
                    # tab_content=Icon(icons.SEARCH),
                    content=Container_new2(Tarefass)
                ),
            ],
            width=self.page.window_width-5,
            height=430,
            data = 'modos',
            on_change=self.acoes_botoes_layout,
            # expand=1,
            )

        continuar = Row([self.continuar, Text('Continuar')], spacing=0)
        pomodoro = Row([self.pomodoro_habilitado, Text('Pomodoro'),self.tempo_pomodoro ], spacing=0)
        descanso = Row([Text('Descanso'),self.tempo_descanso ], spacing=0)
        
        quadro_pomodoro = Container(Row([continuar, pomodoro, descanso],alignment=MainAxisAlignment.SPACE_AROUND), 
                                    border_radius = 6,border= border.all(0.2, color = 'blue'),)

        return Container(Column([
            menu_bar,
            modos,
            Container_new2(quadro_pomodoro),
            quadro_botoes, 
            Container(width=775,
                      height = 150,#120 
                border= border.all(6, color = colors.with_opacity(0.2,'blue')),
                border_radius = 10,
                content = Column([
                    self.saida_treinamento,
                    self.quado_saida,
                    self.saida_respiro,
                                  ])
                                    
                                    #  margin = margin.all(0),
                                    # padding = 0,
                                    # alignment = Alignment(-1,-1),

            )
            
        ]),border= border.all(6, color = colors.with_opacity(0.2,'blue')),)


    def Carregar_tarefas(self):
        # for i in self.arquiv['Padrão']:
        #     valor = list(i.values())
        #     t1 = New_task(self.acoes_tasks, *valor)
        #     self.col_tarefas.controls.append(t1)
        pass

    def Exportar_tarefas(self):

        nome_arquivo_exportar = FilePicker()
        

        '''
        try:
            with open(nome_arquivo_exportar, 'w', encoding='utf-8') as arq:
                arq.write(f'Nome, Duração, BPM_ini, BPM_fim, Passo\n')
                cont = 0
                try:
                    for h in self.col_tarefas.controls:
                        tarefa = f'{h.nome_tarefa.value}, {h.duracao_tarefa.value}, {h.inicio_tarefa.value}, {h.fim_tarefa.value}, {h.passo_tarefa.value}'
                        arq.write(f'{tarefa}\n')

                except:
                    self.pprint('erro na escrita do arquivo a ser exportado')

            self.pprint('Arquivo exportado com sucesso!')

        except:
            self.pprint(f'erro na abertura do arquivo para exportar')
        '''

        super().update()



    def Iniciar_arquiv(self):
        try:
            self.arquiv = Ler_json(config)
        except:
            self.arquiv = {
                'Padrão':[],
                'música 1':None,
                'música 2':None
            }
            Escrever_json(self.arquiv, config)

    def Salvar_cofig(self):
        
        p = []
        for i in self.col_tarefas.controls:
            chaves = ['nome', 'duração', 'bmp_ini', 'bpm_fim', 'passo']
            l = [i.nome_tarefa.value,i.duracao_tarefa.value,i.inicio_tarefa.value , i.fim_tarefa.value, i.passo_tarefa.value]
            d = {k:j for j,k in zip(l, chaves)}
            p.append(d)
 
        self.arquiv = Ler_json(config)
        nome_tarefa = self.task_lis_select.value

        self.arquiv[nome_tarefa] = p
        Escrever_json(self.arquiv, config)


        parametros_gerais = [self.display_bpm.value, self.vol.value, self.inverter.value, \
            self.Treino_habilitado.value, self.meta.getvalue, self.inicio.getvalue,\
            self.passo.getvalue, self.passo_fim.getvalue, self.intervalo.getvalue,\
            self.Tipo_compasso.value, self.qtd_compassos.value, self.continuar.value,\
            self.pomodoro_habilitado.value, self.tempo_pomodoro.getvalue,self.tempo_descanso.getvalue]
        
        nome_parametros_gerais = ['bpm', 'vol', 'inverter','Treino_habilitado', 'meta', 'inicio','passo',\
        'passo_fim', 'intervalo','Tipo_compasso', 'qtd_compassos','continuar', 'pomodoro_habilitado',\
        'tempo_pomodoro','tempo_descanso']

  
        dd = {i:j for i, j in zip(nome_parametros_gerais, parametros_gerais)}

 
        # self.arquiv_config = Ler_json(config_gerais)
        # nome_tarefa = self.task_lis_select.value

        # self.arquiv[nome_tarefa] = p
        Escrever_json(dd, config_gerais)
        # self.tempo_pomodoro.setvalue = 6
        # print(self.tempo_pomodoro.getvalue)

    def Ler_parametros_tarefas(self, task):
        self.Metro_normal.setVolume(self.vol.value/10)
        self.pomodoro_control_thread = self.pomodoro_habilitado.value                 
        self.display_bpm.value = float(task.inicio_tarefa.value)
        self.Metro_normal.setBpm(float(task.inicio_tarefa.value))
        self.parar = False
        self.t_total = float(task.duracao_tarefa.value)*60
        self.tempo_pomodoro_set = self.tempo_pomodoro.value
        self.tempo_descanso_set = self.tempo_descanso.value
        self.Treino_habilitado_set = True
        self.inverter_set = False
        self.tempo_set = True
        self.nome_treino = task.nome_tarefa.value
        self.meta_set = float(task.fim_tarefa.value)
        self.inicio_set = float(task.inicio_tarefa.value)
        self.passo_set = float(task.passo_tarefa.value)
        self.passo_fim_set = 0
        # self.Metro_normal.pomodoro_habilitado = self.pomodoro_habilitado.value
        # self.Metro_normal.tempo_descanso = int(self.tempo_descanso.value)
        # self.Metro_normal.tempo_pomodoro = float(self.tempo_pomodoro.value)
        self.Metro_normal.tempo_compasso = 'Tempo'
        self.parar_tarefas = False





        if self.meta_set == 0 or self.inicio_set == 0 or self.passo_set == 0:
            self.progressivo = False
            if self.t_total == None:
                self.t_total = self.intervalo_set
        else:
            self.progressivo = True

    def Read_values(self, tarefas=False):
        self.Metro_normal.setVolume(self.vol.value/10)
        self.pomodoro_control_thread = self.pomodoro_habilitado.value
        self.Treino_habilitado_set = self.Treino_habilitado.value
        self.inverter_set = self.inverter.value
        # self.Metro_normal.tempo_compasso = 
        self.parar = False
        self.tempo_pomodoro_set = self.tempo_pomodoro.getvalue
        self.tempo_descanso_set = self.tempo_descanso.getvalue
        self.meta_set = self.meta.getvalue
        self.inicio_set = self.inicio.getvalue 
        self.passo_set = self.passo.getvalue
        self.passo_fim_set = self.passo_fim.getvalue
        self.tempo_set = self.tempo.value
        self.intervalo_set = self.intervalo.value
        self.t_total = 0

        if self.tempo_set:
            self.t_total = self.intervalo.value*60
            self.intervalo_set = 0


        if self.inverter_set:
            self.Metro_normal.setBpm(self.meta_set)
            self.display_bpm.value = self.meta_set
        else:
            self.Metro_normal.setBpm(self.inicio_set)
            self.display_bpm.value = self.inicio_set


        if not tarefas:
            if self.Tipo_compasso.value == '2/4':
                self.Tipo_compasso.value = 2
            elif self.Tipo_compasso.value == '3/4':
                self.Tipo_compasso.value = 3
            elif self.Tipo_compasso.value == '4/4':
                self.Tipo_compasso.value = 4
            else:
                self.Tipo_compasso.value = 4

        if self.meta_set == -100 or self.inicio_set == -100 or self.passo_set == 0:
            self.progressivo = False
            if self.t_total == None:
                self.t_total = self.intervalo.value
        else:
            self.progressivo = True    

    def Play_tarefas(self, task):
        if self.metronomo_iniciado:
            self.Stop()
            self.Metro_normal = None
            sleep(0.5)
            self.Metro_normal = Metronomo()
            self.quado_saida.controls = None
            self.saida_respiro.controls = None
            self.saida_treinamento.controls = None
            # e.control.bgcolor = None

        else:
            self.Stop()
            self.Metro_normal = None
            sleep(0.4)
            self.Metro_normal = Metronomo()
            sleep(0.1)
            self.Ler_parametros_tarefas(task)
            super().update()
            self.Ini_Thread('pomodoro')
            self.Ini_Thread('beep')

            # try:
            intervalo_bpm = round((self.t_total*self.passo_set)/(self.meta_set - self.inicio_set), 3)

            if self.metronomo_iniciado:
                self.nome_treino = 'sem nome' if self.nome_treino == '' else self.nome_treino
                tarefa_exec = f'{Data()} .-. {self.nome_treino} .-. {self.t_total/60:.0f} min .-. BPM({self.inicio_set:.0f} a {self.meta_set:.0f}) .-. passo: {self.passo_set:.0f} .-. intervalo: {intervalo_bpm}s'
                # self.t_total = 60*self.t_total
                self.Ini_Thread('Treinamento', [(tarefa_exec)])

        super().update()

    def acoes_tasks(self, task,e):
        data = e.control.data
        t = task
        match data:
            case 'del':
                self.col_tarefas.controls.remove(task)
            case 'play tarefa':
                print('Apertou play')
                self.Play_tarefas(task)

            case 'pause tarefa':
                # self.quado_saida.content.pause = not self.quado_saida.content.pause 
                # self.Metro_normal.Pause()
                self.Pausar()


        super().update()
        print('ação recebida',data )

    def acoes_botoes_layout(self, e, task = ''):
        # self.Exibir_atributos(e.data)
        # print(e.data)
        try:
            data = e.control.data
        except:
            data = e.data        

        match data:                    
            case 'Importar':
                print('tempo_pomodoro alterado')
            case 'Exportar':
                print('exporat arquivo')
                self.Exportar_tarefas()
            case 'Selecionar Planilha':
                print('tempo_pomodoro alterado')
            case 'Bot_m1':
                self.up_bpm(1)
            case 'Bot_m5':
                self.up_bpm(5)
            case 'Bot_m10':
                self.up_bpm(10)
            case 'Bot_m_1':
                self.up_bpm(-1)
            case 'Bot_m_5':
                self.up_bpm(-5)
            case 'Bot_m_10':
                self.up_bpm(-10)
            case 'valorbpm':
                self.Metro_normal.setBpm(self.display_bpm.value)
            case 'vol':
               self.Metro_normal.setVolume(e.control.value/10)
            case 'Inverter':
                self.inverter_set = self.inverter.value
            case 'Treino_habilitado':
                print('treino alterado')
            case 'Tap':
                print('tap alterado')
                self.Tap_bpm()
            case 'meta':
                # print('meta = ', self.meta.value)
                self.meta_set = self.meta.value
                self.meta_caixa.value = self.meta.value
            case 'inicio':
                # print('inicio = ', self.inicio.value)
                self.inicio_set = self.inicio.value
                self.inicio_caixa.value = self.inicio.value

            case 'passo':
                # print('passo = ', self.passo.value)
                self.passo_set = self.passo.value
                self.passo_caixa.value = self.passo.value

            case 'passo_fim':
                # self.passo_fim = self.passo_fim2.value/10
                # self.texto_passo_fim.value = f'Passo_fim ({self.passo_fim2.value/10:.1f})'
                print('passo_fim = ',self.passo_fim.value)
                self.passo_fim_set = self.passo_fim.value
                self.passo_fim_caixa.value = self.passo_fim.value


            case 'intervalo':
                # print('intervalo alterado')
                self.intervalo_set = self.intervalo.value
                self.intervalo_caixa.value = self.intervalo.value
            case 'tempo':
                print('tempo alterado')
                self.tempo_set = self.tempo.value
            case 'Tipo_compasso':
                print('Tipo_compasso alterado')
            case 'qtd_compassos':
                print('qtd_compassos alterado')
            case 'continuar':
                print('continuar alterado')
            case 'pomodoro_habilitado':
                self.pomodoro_control_thread = self.pomodoro_habilitado.value
                print('pomodoro habilitado alterado')
            case 'tempo_pomodoro':
                print('tempo_pomodoro alterado')
            case 'tempo_descanso':
                print('tempo_descanso alterado')
            case 'task_lis_select':
                tarefa = e.control.value
                # print(self.arquiv[tarefa])
                if type(self.arquiv[tarefa]) == list:
                    if len(self.arquiv[tarefa]) >0:
                        self.col_tarefas.controls = None
                        for i in self.arquiv[tarefa]:
                            t1 = New_task(self.acoes_tasks)
                            valor = list(i.values())
                            t1.nome_tarefa.value = valor[0]
                            t1.duracao_tarefa.value = valor[1]
                            t1.inicio_tarefa.value = valor[2]
                            t1.fim_tarefa.value = valor[3]
                            t1.passo_tarefa.value = valor[4]
                            self.col_tarefas.controls.append(t1)
            case 'play':
                print(self.tempo_pomodoro.value)
                self.Play3()
            case 'add new list task':                
                self.task_lis_select.options.append(dropdown.Option(self.new_list_task.value))
            case 'pause':
                # self.pause_lay = not self.pause_lay

                # if self.quado_saida.content != None and not self.Treino_habilitado:
                #     self.quado_saida.content.pause = not self.quado_saida.content.pause 
                self.Pausar()
            case 'stop':
                self.Stop()
                # self.saida_respiro.controls = None
                # self.saida_treinamento.controls = None
                # self.quado_saida.controls = [Text()]
                self.parar_tarefas = True
                self.quado_saida.visible = False
                self.Metro_normal = None
                self.Metro_normal = Metronomo() 
            case 'salvar':
                self.Salvar_cofig()
            case 'add new task':
                self.col_tarefas.controls.append(New_task(self.acoes_tasks)) 
                print('add tarefa')
            case 'Play Tarefas':
                print('implementar play tarefas')
                self.play_tarefas_set = True
                lista_de_tarefas = self.col_tarefas.controls
                duracao_total = 0
                for i in lista_de_tarefas:
                    duracao_total += int(float(i.duracao_tarefa.value)*60)
                h3,m3,s3 = Treinamento.converter_segundos_para_horas_min_segundos(duracao_total)
                self.tempo_das_tarefas.value = f'{h3}:{m3}:{s3}'
                Thread(target=self.Play_tarefas, args = [(lista_de_tarefas[0])],daemon=False).start()

                # self.Play_tarefas(lista_de_tarefas[0])
                super().update()
                def Eventos_tarefas():
                    sleep(5)
                    for i in lista_de_tarefas[1:]:
                        while not self.treinamento.Parar:
                            sleep(3)
                            if self.parar_tarefas:
                                break
                        if self.parar_tarefas:
                            break                        
                        MessageBeep(MB_ICONHAND)
                        self.Play_tarefas(i)
                        self.update()
                    self.tempo_das_tarefas.value = ''


                Thread(target=Eventos_tarefas, daemon=False).start()

                



            case 'tempo_compasso':
                # print('tempo-compasso', e.data, type(e.data))
                match e.data:
                    case '0':
                        self.tempo_compasso = 'Tempo'
                    case '1':
                        self.tempo_compasso = 'Compassos'
            case 'modos':
                # print(e.data)
                match e.data:
                    case '0':
                        self.Modo = 'normal'
                    case '1':
                        self.Modo = 'tarefas'
            case 'caixa_intervalo':
                try:
                    new_value = float(e.control.value)
                    if new_value > 0:
                        self.intervalo.setvalue = 10*new_value
                        self.intervalo_set = new_value
                    else:
                        self.intervalo.setvalue = -10*new_value
                        self.intervalo_set = -1*new_value
                except:
                    self.pprint('Digite um valor inteiro !')                        

            case 'caixa_meta':
                try:
                    new_value = int(e.control.value)
                    if new_value > 0:
                        self.meta.setvalue = new_value
                        self.meta_set = new_value
                    else:
                        self.meta.setvalue = -1*new_value
                        self.meta_set = -1*new_value
                except:
                    self.pprint('Digite um valor inteiro !')
            case 'caixa_inicio':
                try:
                    new_value = int(e.control.value)
                    if new_value > 0:
                        self.inicio.setvalue = new_value
                        self.inicio_set = new_value
                    else:
                        self.inicio.setvalue = -1*new_value
                        self.inicio_set = -1*new_value
                except:
                    self.pprint('Digite um valor inteiro !')
            case 'caixa_passo':
                try:
                    new_value = float(e.control.value)
                    if new_value > 0:
                        self.passo.setvalue = 10*new_value
                        self.passo_set = new_value
                    else:
                        self.passo.setvalue = -10*new_value
                        self.passo_set = -1*new_value
                except:
                    self.pprint('Digite um valor real !')
            case 'caixa_passo_fim':
                try:
                    new_value = int(e.control.value)
                    if new_value > 0:
                        self.passo_fim.setvalue = 10*new_value
                        self.passo_fim_set = new_value
                    else:
                        self.passo_fim.setvalue = -10*new_value
                        self.passo_fim_set = -1*new_value
                except:
                    self.pprint('Digite um valor inteiro !')

               


        super().update()     

    def pprint(self, texto):
        self.quado_saida.controls = [Text(texto, color='white')]
        super().update()

    def up_bpm(self, bpm):        
        new_bpm = self.display_bpm.value + bpm
        if new_bpm <=30:
            new_bpm = 30
        elif  new_bpm>549:
            new_bpm = 549
        # print(new_bpm)
        # print(type(new_bpm))
        # print('tipo self.Metro_normal.setBpm(new_bpm) = ', type(self.Metro_normal.setBpm(new_bpm)))    
        self.display_bpm.options.append(dropdown.Option(new_bpm))
        self.display_bpm.value = new_bpm
        self.Metro_normal.setBpm(new_bpm)
        super().update()

    def up_bpm2(self, bpm):        
        new_bpm = bpm
        if new_bpm <=30:
            new_bpm = 30
        elif  new_bpm>549:
            new_bpm = 549
        # print(new_bpm)
        # print(type(new_bpm))
        # print('tipo self.Metro_normal.setBpm(new_bpm) = ', type(self.Metro_normal.setBpm(new_bpm)))    
        self.display_bpm.options.append(dropdown.Option(new_bpm))
        self.display_bpm.value = new_bpm
        self.Metro_normal.setBpm(new_bpm)
        super().update()

    def Play3(self):
    # print(e.control)
        # print(self.metronomo_iniciado)
        if self.metronomo_iniciado:
            print('metronomo já iniciado')
            self.Stop()
            self.Metro_normal = None
            sleep(0.5)
            self.Metro_normal = Metronomo()
            self.quado_saida.controls = None

        else:
            self.Stop()
            self.Metro_normal = None
            sleep(0.5)
            self.Metro_normal = Metronomo()
            self.Metro_normal.setBpm(self.display_bpm.value)
            # self.Play2() 
            self.Read_values()
            tempo = float(self.tempo_pomodoro.value)
            # print('tempo = ', tempo, 'tipo:', type(tempo))
            # self.quado_saida.content =  Countdown(tempo, 'Treine durante ')
            # print(self.pomodoro_habilitado.value)
            # self.Mostrar('ahora vai')
            self.quado_saida.visible = True
            print(self.passo_fim_set)
            self.Ini_Thread('pomodoro')
            self.Ini_Thread('beep')
            def eventos():
                while self.metronomo_iniciado:
                    while not self.p.pause_pomodoro:
                        sleep(0.3)
                        if not self.metronomo_iniciado:
                            break
                    if not self.metronomo_iniciado:
                        break                        
                    self.Metro_normal.pause = True
                    try:
                        self.treinamento.Pause  = True
                    except:
                        pass
                    try:
                        self.treinamento_compassos.Pause  = True
                    except:
                        pass

                    while self.p.pause_pomodoro:
                        sleep(0.3)
                        if not self.metronomo_iniciado:
                            break
                    if not self.metronomo_iniciado:
                        break                         
                    self.Metro_normal.pause = False
                    try:
                        self.treinamento.Pause  = False
                    except:
                        pass
                    try:
                        self.treinamento_compassos.Pause  = False
                    except:
                        pass                    
            if self.pomodoro_control_thread:
                Thread(target=eventos, daemon=False).start()


            if self.tempo_compasso == 'Tempo' and self.Treino_habilitado.value:
                self.tipo_de_treino = 'treinamento'                        
                self.Ini_Thread('Treinamento')

            elif self.tempo_compasso == 'Compassos' and self.Treino_habilitado.value:
                self.tipo_de_treino = 'compassos'                        
                self.Ini_Thread('compassos')        

    def Stop(self):
        self.Metro_normal.setOn = False
        self.treinando = False
        if self.metronomo_iniciado:
            if self.p != None:
                self.p.Parar = True
                self.p = None
            if self.treinamento != None:
                # self.treinamento = None
                self.treinamento.Parar = True
            if self.treinamento_compassos != None:
                # self.treinamento_compassos = None                
                self.treinamento_compassos.Parar = True
        
        self.pomodoro_control_thread = False
        self.metronomo_iniciado = False
        self.parar = True 
        super().update()

    def Pausar(self):
        if self.metronomo_iniciado:
            if self.p != None:
                self.p.Pause = not self.p.Pause
            if self.treinamento != None:
                self.treinamento.Pause = not self.treinamento.Pause
            if self.treinamento_compassos != None:
                self.treinamento_compassos.Pause = not self.treinamento_compassos.Pause      
        self.Metro_normal.pause = not self.Metro_normal.pause

    def Pomodoro(self):
        self.p = Pomodoro()
        self.p.tempo_pomodoro_set = self.tempo_pomodoro_set
        self.p.tempo_descanso_set = self.tempo_descanso_set
        self.quado_saida.controls = [self.p]

    def Treinamento(self, tarefas  = ''):
        if tarefas == '':
            self.treinamento = None
            self.treinamento = Treinamento(
                duracao = self.t_total,
                inicio = self.inicio_set,
                meta = self.meta_set,
                passo_set = self.passo_set,
                intervalo = self.intervalo_set,
                passo_fim = self.passo_fim_set,
                page = self.page,

                )
        else:
            self.treinamento = None
            self.treinamento = Treinamento(
                duracao = self.t_total,
                inicio = self.inicio_set,
                meta = self.meta_set,
                passo_set = self.passo_set,
                intervalo = 0,
                passo_fim = 0

                )            

        self.saida_treinamento.visible = True
        self.saida_treinamento.controls = [self.treinamento]
        Thread(target=self.att_bpm, args=[tarefas], daemon=False).start()

    def Treinamento_compassos(self):
        if self.Tipo_compasso.value == '2/4':
            self.Tipo_compasso.value = 2
        elif self.Tipo_compasso.value == '3/4':
            self.Tipo_compasso.value = 3
        elif self.Tipo_compasso.value == '4/4':
            self.Tipo_compasso.value = 4
        else:
            self.Tipo_compasso.value = 4
        
        self.treinamento_compassos = Compassos(
            inicio= self.inicio_set,
            meta = self.meta_set,
            passo_set = self.passo_set,
            tipo_compasso = self.Tipo_compasso.value,
            qtd_compassos = self.qtd_compassos.value

            )
        # t.inicio = self.inicio_set
        # t.meta = self.meta_set
        # t.passo_set = self.passo_set
        # t.passo_fim = self.passo_fim_set 
        # t.intervalo = self.intervalo_set
        self.saida_treinamento.visible = True
        self.saida_treinamento.controls = [self.treinamento_compassos]
        # print(self.inicio_set, self.meta_set, self.passo_set, self.Tipo_compasso.value,self.qtd_compassos.value )
        Thread(target=self.att_bpm_compassos, daemon=False).start()

    def att_bpm(self, tarefas = ''):
        estado = self.treinamento.new_bpm
        try:
            while not self.treinamento.Parar:
                if self.treinamento.new_bpm != estado:
                    self.up_bpm2(self.treinamento.new_bpm)
                    estado = self.treinamento.new_bpm
                if self.treinamento.Parar:
                    break
                sleep(0.5)
        except:
            pass


        if tarefas != '' and self.treinamento != None:
            self.EscreveTxt(tarefas)
        if not self.continuar.value:
            self.Stop()
         
    def att_bpm_compassos(self):
        estado = self.treinamento_compassos.new_bpm

        try:
            while not self.treinamento_compassos.Parar:
                if self.treinamento_compassos.new_bpm != estado:
                    self.up_bpm2(self.treinamento_compassos.new_bpm)
                    estado = self.treinamento_compassos.new_bpm
                if self.treinamento_compassos.Parar:
                    break                    

                sleep(0.5)       
        except:
            pass 

    def Ini_Thread(self, controle, argu=''):
        if controle == 'pomodoro':
            self.Metro_normal.setOn = False
            # sleep(0.3)
            self.Metro_normal.setOn = True
            if self.pomodoro_control_thread:
                # print('self.tempo_pomodoro:', (self.tempo_pomodoro.value), (self.tempo_descanso.value))
                if self.tempo_pomodoro_set != '' and self.tempo_descanso_set != '':
                    try:
                        self.tempo_pomodoro_set, self.tempo_descanso_set = float(
                            self.tempo_pomodoro_set), float(self.tempo_descanso_set)
                    except TypeError:
                        print('Erro na conversão dos tempo_pomodoro e tempo_descanso', TypeError)
                        self.tempo_pomodoro_set, self.tempo_descanso_set = 3, 1


                    Thread(target=self.Pomodoro, daemon=False).start()#########################################
                    
                    # self.Pomodoro()
            else:
                print('pomodoro_control_thread desabilitado')

        elif controle == 'beep':
            if not self.metronomo_iniciado:
                Thread(target=self.Metro_normal.beep, daemon=False).start()
                self.metronomo_iniciado = True
            else:
                print('metronomo já iniciado')

        elif controle == 'Treinamento':
            # self.Treinar()
            # print('vai reinar')
            if self.passo_fim_set < self.passo_set or self.passo_set == -1:
                if self.metronomo_iniciado:
                    if not self.treinando:
                        self.treinando = True
                        Thread(target=self.Treinamento, args=argu, daemon=False).start()
                        # self.th_t = Thread(target=self.Treinamento, args=argu, daemon=False)
                        # self.th_t.start()
                        # self.th_t.target = self.Treinamento
                        # self.th_t.args = argu
                        # self.th_t.start()
                        # self.Treinamento(argu)

        elif controle == 'Executar tarefas':
            self.Treinar()
            if not self.treinando:
                self.treinando = True
                Thread(target=self.Treinamento, args=argu, daemon=False).start()

            else:
                raise ValueError(
                    "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")

        elif controle == 'compassos':
            # self.Treinar()
            if self.passo_fim_set < self.passo_set:
                if self.metronomo_iniciado:
                    if not self.treinando:
                        self.treinando = True
                        Thread(target=self.Treinamento_compassos,
                            daemon=False).start()

            else:
                # raise ValueError(
                #     "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")
                self.Prints(
                    "O valor de 'Passo Fim' deve ser menor que o valor de 'Passo'")
 
    def Exibir_atributos(self, objeto):
        for i in objeto.__dict__.keys():
            print(i) 

    @classmethod    
    @property
    def nometarefastxt(self):
        return Juntar(getcwd(), 'tarefas.txt')
    @classmethod    
    def EscreveTxt(self, texto):
        try:
            with open(self.nometarefastxt, 'a') as arq:
                arq.write(f'{texto}\n')
        except:
            with open(self.nometarefastxt, 'w') as arq:
                arq.write(f'{texto}\n')
        print(f'A tarefa foi salva em {self.nometarefastxt}')

    def EscrevePlanilha(self, texto):
        # texto = f'11-10-2023-14:56:53 .-. Estágio 3 .-. 5min .-. BPM(140 a 150) .-. passo: 0.1 .-. intervalo: 3.0s'
        # print(texto)
        b = texto.split(' .-. ')
        d, m, y = b[0].split('-')[:3]
        h = b[0].split('-')[3]
        data = f'{d}/{m}/{y} {h}'
        nome = b[1]
        duracao = b[2][:-3]

        # if self.progressivo:    # or nome == 'sem nome'
        try:
            resultado = search(r'BPM\((\d+) a (\d+)\)', b[3])
            print(f'resultado = {resultado}')
            bpm_in = resultado.group(1)
            bpm_fim = resultado.group(2)
            passo = b[4][7:]
            intervalo = b[5][10:-1]
        except:
            resultado = search(r'BPM\((\d+(\.\d+)?) a', b[3])
            print(f'resultado = {resultado}')
            bpm_in = resultado.group(1).split('.')[0]
            bpm_fim = ''
            passo = ''
            intervalo = ''

        valores = [[data, nome, duracao, bpm_in, bpm_fim, passo, intervalo]]

        n_linhas = 1+len(p := LerCelulas(self.nome_planilha,
                         'metronomo!A:h', nome_da_credencial))
        AtualizarCelulas(
            self.Selecionar_planilha.value, f'metronomo!A{n_linhas}:h', valores, nome_da_credencial)
    
    def Tap_bpm(self):
        print('tap pressionado')
        if not self.iniciar_medicao_bpm:
            self.ti = time()
            self.iniciar_medicao_bpm = not self.iniciar_medicao_bpm
        else:
            self.tf = time()
            # print(f'delta T = {self.tf-self.ti}')
            new_bpm = round(int(60/(self.tf-self.ti)), 0)
  
            if new_bpm <=30:
                new_bpm = 30
            elif  new_bpm>549:
                new_bpm = 549
            # print(new_bpm)
            # print(type(new_bpm))
            # print('tipo self.Metro_normal.setBpm(new_bpm) = ', type(self.Metro_normal.setBpm(new_bpm)))    
            self.display_bpm.options.append(dropdown.Option(new_bpm))
            self.display_bpm.value = new_bpm
            self.Metro_normal.setBpm(new_bpm)
            super().update()


            self.ti = None
            self.tf = None
            self.iniciar_medicao_bpm = not self.iniciar_medicao_bpm
    def Teclas(self, e: KeyboardEvent):
        if self.Modo == 'normal':
            match e.key:
                case ' ':
                    self.Play3()              
                    print('pressionou space') 
                case 'Enter':
                    if self.metronomo_iniciado:
                        self.Metro_normal.Stop()            
                    print('pressionou enter')
                case 'P':
                    if self.metronomo_iniciado:
                        self.Metro_normal.Pause()               
                    print('pressionou P')
                case 'Numpad 7':
                    self.up_bpm(1)
                case 'Numpad 8':
                    self.up_bpm(5)                 
   
                case 'Numpad 9':
                    self.up_bpm(10)                  

                case 'Numpad 1':
                    self.up_bpm(-1)                  
                case 'Numpad 2':
                    self.up_bpm(-5)                    
   
                case 'Numpad 3':
                    self.up_bpm(-10)                   
 
                case 'Numpad 5':
                    self.Tap_bpm()

                # case 'Numpad 4':
                #     self.check_display()                                                                                         
   
        super().update()
     

    
    '''
    def iniciar_configs_gerais(self):
        parametros_gerais = [self.display_bpm.value, self.vol.value, self.inverter.value, \
            self.Treino_habilitado.value, self.meta.value, self.inicio.value,\
            self.passo.value, self.passo_fim.value, self.intervalo.value,\
            self.Tipo_compasso.value, self.qtd_compassos.value, self.continuar.value,\
            self.pomodoro_habilitado.value, self.tempo_pomodoro.value,self.tempo_descanso.value]
        
        nome_parametros_gerais = ['bpm', 'vol', 'inverter','Treino_habilitado', 'meta', 'inicio','passo',\
        'passo_fim', 'intervalo','Tipo_compasso', 'qtd_compassos','continuar', 'pomodoro_habilitado',\
        'tempo_pomodoro','tempo_descanso']
        # try:
        self.arquiv_config = Ler_json(config_gerais)

        self.display_bpm.options.append(dropdown.Option(self.arquiv_config["bpm"]))
        self.display_bpm.value = self.arquiv_config["bpm"]
        self.vol.value = self.arquiv_config["vol"]
        self.inverter.value = self.arquiv_config["inverter"]
        self.Treino_habilitado.value = self.arquiv_config["Treino_habilitado"]
        self.meta.setvalue = self.arquiv_config["meta"]
        self.inicio.setvalue = self.arquiv_config["inicio"]
        self.passo.setvalue = self.arquiv_config["passo"]
        self.passo_fim.setvalue = self.arquiv_config["passo_fim"]
        self.intervalo.setvalue = self.arquiv_config["intervalo"]
        self.Tipo_compasso.setvalue = self.arquiv_config["Tipo_compasso"]
        self.qtd_compassos.setvalue = self.arquiv_config["qtd_compassos"]
        self.continuar.value = self.arquiv_config["continuar"]
        self.pomodoro_habilitado.value = self.arquiv_config["pomodoro_habilitado"]
        self.pomodoro_habilitado_value = False
        self.tempo_pomodoro.setvalue = float(self.arquiv_config["tempo_pomodoro"])
        # self.tempo_pomodoro.setvalue = 5
        self.tempo_descanso.setvalue = float(self.arquiv_config["tempo_descanso"])

        super().update()              
        # except:    
        #     d = {i:j for i, j in zip(nome_parametros_gerais, parametros_gerais)}

        #     Escrever_json(d, config_gerais)
        print(self.arquiv_config["pomodoro_habilitado"])
    '''
    

    '''
    # def did_mount(self):        
    #     self.iniciar_configs_gerais()
        # super().update()
    # def will_unmount(self):
    #     self.pomodoro_habilitado.value = 5
    #     print('casa')
    '''

    '''
    def Mostrar(self, *texto, cor = 'white', size = 20):
        try:
            if self.quado_saida.content.texto1 == '':
                pass

            for i in texto:
                if self.quado_saida.content.texto1 == '':
                    self.quado_saida.content.texto1 = i
                    self.quado_saida.content.texto1_color = cor
                    self.quado_saida.content.texto1_size = size
    

                elif self.quado_saida.content.texto2 == '':
                    self.quado_saida.content.texto2 = i
                    self.quado_saida.content.texto2_color = cor
                    self.quado_saida.content.texto2_size = size
    

                elif self.quado_saida.content.texto3 == '':
                    self.quado_saida.content.texto3 = i
                    self.quado_saida.content.texto3_color = cor
                    self.quado_saida.content.texto3_size = size
    

                elif self.quado_saida.content.texto4 == '':
                    self.quado_saida.content.texto4 = i
                    self.quado_saida.content.texto4_color = cor
                    self.quado_saida.content.texto4_size = size
    

                elif self.quado_saida.content.texto5 == '':
                    self.quado_saida.content.texto5 = i
                    self.quado_saida.content.texto5_color = cor
                    self.quado_saida.content.texto5_size = size
    

                elif self.quado_saida.content.texto6 == '':
                    self.quado_saida.content.texto6 = i
                    self.quado_saida.content.texto6_color = cor
                    self.quado_saida.content.texto6_size = size


                else:
                    print('limite de saidas atingido')

        except:
            self.quado_saida.content = Saidas(*texto, cor  = cor, size = size)
                            

        super().update()
        return  self.quado_saida.content      
    '''
  
    '''
    def Play2(self, e='', tarefas = False):
        self.Read_values(tarefas)
        # Thread(target=self.check_display, daemon=False).start()
        tempo = float(self.tempo_pomodoro.value)
        print('tempo = ', tempo, 'tipo:', type(tempo))
        self.quado_saida.content =  Countdown(tempo, 'Volte a treinar por ')
        
        if tarefas:
            self.Metro_normal.Play_tarefas()   
        else:
            self.Metro_normal.Play()
        super().update()
    '''
    '''
    def Play_tarefas(self):
        self.Ini_Thread('pomodoro')
        self.Ini_Thread('beep')
        self.Treino_habilitado.value = True
        self.inverter.value = False
        self.tempo.value = True
        self.passo_fim.value = 0
        # try:
        intervalo_bpm = round(
            (float(self.t_total)*float(self.passo))/(float(self.meta) - float(self.inicio)), 3)

        if self.metronomo_iniciado:
            self.nome_treino = 'sem nome' if self.nome_treino == '' else self.nome_treino
            tarefa_exec = f'{Data()} .-. {self.nome_treino} .-. {self.t_total}min .-. BPM({self.inicio} a {self.meta}) .-. passo: {self.passo} .-. intervalo: {intervalo_bpm}s'
            self.Ini_Thread('Treinamento', [(tarefa_exec)])
    '''
   
    '''

    def Respiro(self):
        self.Metro_normal.pause = True
        estado_saida_treinamento = self.saida_treinamento.visible
        estado_saida_quado = self.quado_saida.visible
        self.saida_treinamento.visible = False
        self.quado_saida.visible = False
        self.saida_respiro.visible = True
        descan = int(self.tempo_descanso.value*60/19.4)
        # print(descan)
        # self.Metro_normal.pause = False
        self.parar = False
        width_max = 740
        respiro = Container(content=Text(),bgcolor= colors.YELLOW,width = 0, border_radius=40)
        def Inspire(d):
            # self.quado_saida.content = Text(f'INSPIRE ({d})')
            s = Saidas(f'INSPIRE ({d})', cor = colors.YELLOW, size = 50)
            # s.saida_tempo_de_treino.visible = True
            # self.saida.texto1_size = 50
            # self.saida.texto1_color= colors.YELLOW
            self.saida_respiro.controls = [Column([s, respiro])]
            # self.quado_saida.content.alignment= MainAxisAlignment.CENTER

        def Expire(d):
            s = Saidas(f'EXPIRE  ({d})', cor = colors.GREEN, size = 50)

            # s.saida_tempo_de_treino.visible = True
            # self.saida.texto1_size = 50
            # self.saida.texto1_color= colors.GREEN
            self.saida_respiro.controls = [Column([s, respiro])]
            # self.quado_saida.content.alignment= MainAxisAlignment.CENTER


        for d in range(descan,0,-1):
            a = time()
            Inspire(d)
            super().update()
            for i in range(0,width_max,6*2):
                respiro.width = i
                sleep(0.001)
                if self.parar:
                    break
                super().update()
            respiro.bgcolor = colors.GREEN
            Expire(d)
            super().update()
            if self.parar:
                break             
            for i in range(width_max,0,-1*2):
                respiro.width = i
                if self.parar:
                    break                    
                sleep(0.01567)
                super().update()
            respiro.bgcolor = colors.YELLOW
            b = time()-a
            print(b)

        self.saida_treinamento.visible = estado_saida_treinamento
        self.quado_saida.visible = estado_saida_quado
        self.saida_respiro.controls = None
        self.saida_respiro.visible = False
        self.Metro_normal.pause = False
        respiro.width = 0
        super().update()
  

    def Pomodoro2(self):
        texto = 'Pomodoro inciado...'
        self.quado_saida.visible = True        
        self.quado_saida.controls = [Text(texto)]
        super().update()

        while self.pomodoro_control_thread:
            self.quado_saida.visible = True
            # self.quado_saida.content =  Countdown(self.tempo_pomodoro.value, 'Pomodoro inciado...')
            segundos = self.tempo_pomodoro_set*60
            while segundos >= 0:
                h, mins = divmod(segundos, 60*60)
                mins, secs = divmod(mins, 60)
                h, mins, secs = int(h), int(mins), int(secs)
                if texto != '':
                    contador = "{:s} {:02d}:{:02d}:{:02d}".format(texto,h, mins, secs)
                else:
                    contador = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)

                self.quado_saida.controls = [Text(contador)]
                sleep(1)
                super().update()
                segundos -= 1
                while self.Metro_normal.pause:
                    sleep(0.3)
                if self.parar or not self.pomodoro_control_thread:
                    break

            if self.parar or not self.pomodoro_control_thread:
                self.quado_saida.visible = False
                self.quado_saida.controls = None
                break

            MessageBeep(MB_ICONHAND)
            # self.Pausar()
            # self.quado_saida.content =  Countdown(self.tempo_descanso.value, 'Faça uma pausa de')
            
            self.Respiro()
            
            if not self.pomodoro_control_thread:
                break
            MessageBeep(MB_ICONHAND)

            if not self.pomodoro_control_thread:
                break
            # self.Pausar()
            texto = 'Volte a treinor por '

        self.quado_saida.controls =  None



    def Treinar(self):
        if self.progressivo:
            if not self.tempo_set:
                # print('self.meta.value:', type(self.meta.value), self.meta.value)
                # print('self.inicio.value:', type(self.inicio.value), self.inicio.value)
                # print('self.passo.value:', type(self.passo.value), self.passo.value)
                # print('self.intervalo.value:', type(self.intervalo.value), self.intervalo.value)
                self.tempo_de_treino = int(((self.meta_set - self.inicio_set)/self.passo_set)*self.intervalo_set)
                self.t_total = self.tempo_de_treino
                horas, minutos, segundos = self.converter_segundos_para_horas_min_segundos(self.tempo_de_treino)
                self.quado_saida.content = Text(f"Duração do treino: {horas}:{minutos}:{segundos}")
                self.intervalo2 = self.intervalo_set

            else:

                self.intervalo2 = round((self.t_total*self.passo_set)/(self.meta_set - self.inicio_set), 3)
                horas, minutos, segundos = self.converter_segundos_para_horas_min_segundos(self.t_total)
                self.quado_saida.content = Text(f"Duração do treino: {horas}:{minutos}:{segundos}")

            if self.inverter.value:
                self.Metro_normal.setBpm(self.meta_set)
                self.display_bpm.value = self.meta_set
                self.meta2 = self.inicio_set
                self.passo_set = -1*self.passo_set

            else:
                self.Metro_normal.setBpm(self.inicio_set)
                self.display_bpm.value = self.inicio_set
                self.meta2 = self.meta_set
                # self.passo2 = self.passo_set


            if not self.inverter_set and self.passo_fim_set not in [0, '', None]:
                distancia_bpm = self.meta_set - self.inicio_set
                self.dist_passo = self.passo_set - self.passo_fim_set
                self.constante_de_tempo = ((self.meta_set - self.inicio_set)*self.intervalo2)
                self.x = [0.25, 0.5, 0.75, 0.9, 1]
                self.incrementos = [y*distancia_bpm +  self.inicio_set for y in self.x]
                ii = 0

            else:
                self.dist_passo = 0

        else:
            self.Metro_normal.setBpm(self.inicio_set)
            self.display_bpm.value = self.inicio_set
        
        super().update()

    def Treinamento2(self, tarefa_exec=''):
        self.quado_saida.visible = True
        # self.saida_respiro.visible = False
        self.saida_treinamento.visible = True
        self.saida_treinamento.controls = [Text('Treino iniciado...'), Text()]
        super().update()
        print('Treino iniciado...')
        # print(f'tarefa_exec = {tarefa_exec}')

        # print(f'dist_passo = {dist_passo} \npasso = {self.passo} \nbpm = {bpm}\n')
        def Finalizacao_treino():
            self.saida_treinamento.controls = [Text('Treino Finalizado...')]
            # self.Piscar_infos
            self.EscreveTxt(tarefa_exec)
            # self.EscrevePlanilha(tarefa_exec)
            self.quado_saida.controls = None

        ii = 0
        self.tempo_restante = float(self.t_total) + self.intervalo2

        if tarefa_exec == '':
            tarefa_exec = f'{Data()} .-. {"sem nome"} .-. {round(self.tempo_restante/60,1)}min .-. BPM({self.inicio} a  ) .-. passo:   .-. intervalo:  s'

        if self.progressivo:
            while (teste := (bpm := self.Metro_normal.getBpm) > self.meta2 if self.inverter_set else (bpm := self.Metro_normal.getBpm) < self.meta2):
                self.Exibir_tempo_restante()


                sleep(self.intervalo2)
                self.tempo_restante -= self.intervalo2

                ii = self.Variador_de_passo(bpm, ii)
                self.up_bpm(self.passo_set)
                self.saida_treinamento.controls[1] = Text(f'({self.display_bpm.value} bpm)') if self.Modo == 'tarefas' else Text()
                super().update()


                # Para caso o de o botão pause ser pressionado
                while self.Metro_normal.pause:
                    sleep(0.1)

                # Para caso o de o botão Stop ser pressionado
                if self.treinando == False or self.Treino_habilitado_set == False or self.tempo_restante <= 0:
                    break

            # para quando a bpm passa da meta
            if (teste2 := bpm < self.meta2 if self.inverter_set else bpm > self.meta2):
                bpm = self.meta2
                self.display_bpm.options.append(dropdown.Option(bpm))
                self.display_bpm.value = bpm
                self.Metro_normal.setBpm(bpm)
                super().update()

            if bpm == self.meta2 or self.tempo_restante == 0:
                # self.saida_treinamento.controls = [Text('Treino finalizado...')]
                MessageBeep(MB_ICONHAND)

        else:
            while self.tempo_restante >= 0:
                self.Exibir_tempo_restante()
                sleep(1)
                self.tempo_restante -= 1
                while self.pause:
                    sleep(0.1)
                if self.treinando == False or self.Treino_habilitado_set == False or self.tempo_restante <= 0:
                    break

            if self.tempo_restante == 0:
                MessageBeep(MB_ICONHAND)

        Thread(target=Finalizacao_treino, daemon=True).start()
        self.Testar_continuidade()
        self.saida_treinamento.visible = False
        self.saida_treinamento.controls = None
        self.quado_saida.visible = False
        self.quado_saida.controls = None
        super().update()

    def Treinamento_compassos(self):
        self.quado_saida.visible = False
        self.saida_respiro.visible = False
        self.saida_treinamento.visible = True
        self.saida_treinamento.controls = [Text('Treino compassos iniciado...')]
        super().update()
        print('Treino compassos iniciado...')

        # self.setBpm = self.inicio

        # self.setBpm = meta
        # self.cont_tempos = 0
        # self.cont_compassos = 0
        ii = 0
        # print(f'\nself.treinando = {self.treinando}\nself.treino_habilitado = {self.treino_habilitado}')
        while (teste := (bpm := self.Metro_normal.getBpm) > self.meta2 if self.inverter_set else (bpm := self.Metro_normal.getBpm) < self.meta2):
            # if self.dist_passo != 0:
            #     if ii >= 3:
            #         if bpm >= self.incrementos[ii]:
            #             self.passo = self.passo_fim
            #             self.tempo_restante = int(
            #                 self.constante_de_tempo/self.passo)
            #             print(f'passou dos {self.x[ii]*100}% da meta')

            #     elif bpm >= self.incrementos[ii] and bpm < self.incrementos[ii+1]:
            #         self.passo = self.passo_fim + \
            #             (1-self.x[ii])*self.dist_passo
            #         self.tempo_restante = int(
            #             ((self.meta - bpm)*self.intervalo)/self.passo)
            #         print(f'passou dos {self.x[ii]*100}% da meta')
            #         ii += 1
            ii = self.Variador_de_passo(bpm, ii)
            # print(f'bpm = {bpm}\nteste = {teste}')
            while self.Metro_normal.cont_tempos != self.Tipo_compasso.value*self.qtd_compassos.value:
                sleep(0.01)

            self.Metro_normal.cont_tempos = 0
            self.up_bpm(self.passo.value)


            # Para caso o de o botão pause ser pressionado
            while self.Metro_normal.pause:
                sleep(0.1)
            # Para caso o de o botão Stop ser pressionado
            if self.treinando == False or self.Treino_habilitado.value == False:
                break

        # para quando a bpm passa da meta
        if (teste2 := bpm < self.meta2 if self.inverter_set else bpm > self.meta2):
            self.up_bpm(self.meta2)
            bpm = self.meta2

        if bpm == self.meta2:
            MessageBeep(MB_ICONHAND)


            self.saida_treinamento.controls = [Text('Treino Finalizado...')]
            super().update()
            # self.EscreveTxt(tarefa_exec)
            # self.EscrevePlanilha(tarefa_exec)

            # fazer o nome ficar pisacando na tela
            # for i in range(4):
            #     self.window['-tempo_restante-'].update(text_color='#ffff80')
            #     sleep(0.5)
            #     self.window['-tempo_restante-'].update(text_color='red')
            #     sleep(0.5)
            # self.window['-tempo_restante-'].update(text_color='#4ab580')
            # self.Piscar_infos
            self.Testar_continuidade()
            self.saida_treinamento.visible = False


        # if self.continuar == False:
        #     self.pomodoro_habilitado = False
        #     self.treinando = False
        #     self.setOn = False

    def Testar_continuidade(self):
        if self.continuar.value == False and not self.play_tarefas_set:
            self.pomodoro_control_thread = False
            self.treinando = False
            self.Metro_normal.setOn = False
            self.quado_saida.controls = None
        elif self.play_tarefas_set:
            # self.pomodoro_habilitado = False
            self.treinando = False
            self.Metro_normal.setOn = False
        # self.Restaurar_cores
        self.metronomo_iniciado = False

    def Variador_de_passo(self, bpm, ii):
        if self.dist_passo != 0:
            if ii >= 3:
                if bpm >= self.incrementos[ii]:
                    self.passo_set = self.passo_fim_set
                    self.tempo_restante = int(
                        self.constante_de_tempo/self.passo_set)
                    print(f'passou dos {self.x[ii]*100}% da meta')

            elif bpm >= self.incrementos[ii] and bpm < self.incrementos[ii+1]:
                self.passo_set = self.passo_fim_set + \
                    (1-self.x[ii])*self.dist_passo
                self.tempo_restante = int(
                    ((self.meta_set - bpm)*self.intervalo2)/self.passo_set)
                print(f'passou dos {self.x[ii]*100}% da meta')
                ii += 1
        return ii
    
    def Exibir_tempo_restante(self):
        self.saida_treinamento.visible = True
        tempo = self.tempo_restante
        horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(tempo)
        self.saida_treinamento.controls[0] = Text(f"Tempo restante: {horas2}:{minutos2}:{segundos2}")
        super().update()
    '''

    '''
    @classmethod
    def converter_segundos_para_horas_min_segundos(self, segundos):
        def Algarismos(numero, qtd=2):
            numero = int(numero)
            return str(numero).zfill(qtd)
        horas = segundos // 3600  # 3600 segundos em uma hora
        horas = Algarismos(horas)
        segundos %= 3600
        minutos = segundos // 60  # 60 segundos em um minuto
        minutos = Algarismos(minutos)
        segundos %= 60
        segundos = Algarismos(segundos)

        return horas, minutos, segundos
    '''
  

    
def main(page: Page):
    page.title = "Exemplo Layout"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = '#000000', #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750
    
    # layout = Quadro(page, 
    #                 width = page.window_width-1,
    #                 height= page.window_height-55,  
    #                 border_color = 'white',
    # )
    # layout.contet = Column(Text('kjhkjhkj', size = 200, color='white'))
    def Exibir_atributos(objeto):
        for i in objeto.__dict__.keys():
            print(i) 
    app = Layout(page)
    # pomodoro_habilitado = Checkbox()
    # pomodoro = Row([pomodoro_habilitado, Text('Pomodoro'),Quadro(Drop_new([0.1,0.3,0.5]+[i for i in range(1,301)], 1)) ], spacing=0)
    # Exibir_atributos(pomodoro.controls)  
    # print(pomodoro_habilitado.value)          
    page.add(app)
    # page.add(self.menu_bar,modos,quadro_pomodoro,quadro_botoes, quado_saida)
    # page.add(col_tarefas)

    page.update() 
# app(target=main, view=AppView.WEB_BROWSER)

def main2(page: Page):
    page.title = "Metrônomo"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 800

    app = Layout(page)
    page.on_keyboard_event = app.Teclas
    
    page.window_focused = True
    # print(page.window_focused)
    s = Saidas()
    s.texto1 = 'Pomodoro iniciado ............. (00:00:00)'
    s.texto1_color = 'green'
    # s.texto1_size = 12
    s.texto2 = '22222222222222222222'
    s.texto2_color = 'yellow'
    s.texto3 = '333333333333333333'
    s.texto4 = '444444444444444444'
    s.texto5 = '555555555555555'
    s.texto6 = '666666666666666666'
    quado_saida = Container(width=775,height = 120, 
                                     border= border.all(0.1, color = 'white'),
                                    #  margin = margin.all(0),
                                    # padding = 0,
                                    # alignment = Alignment(-1,-1),
    )
    sombra =  BoxShadow(
            spread_radius=0,
            blur_radius=1,
            color=colors.with_opacity(0.2,'blue'),
            offset=Offset(3, 3),
            blur_style=ShadowBlurStyle.SOLID)
    gradiente =  gradient=LinearGradient(
            begin=Alignment(-1, -1),
            end=Alignment(1.1, -0.1),
            
            colors=[
                # "#222222",
                "#171718",
                "#171718",
                "#171718",
                "#1d1e22",
                # "#1d1e22",
                #  "#12121a",                
                # "black",
                "black",
                # "black",
                # "black",
                # "black",
                # "black",
                        ],
            tile_mode=GradientTileMode.MIRROR,
            rotation=63*3.14/180,
        ) 
    # app = Container(app, gradient=gradiente, shadow=sombra, border_radius=25)
    app = Container(app, bgcolor='black', border_radius=25)
    page.add(app)
    def Mostrar(*texto):
        quado_saida.content = Saidas(*texto, cor  = 'white', size = 25)
        # quado_saida.content.texto1_size = 30
        page.update()

    def Mostrar2(*texto):
        return Saidas(*texto)
     

    # page.add(quado_saida)
    
    # Mostrar('cú assssssssssssss   ddddddddddddd', 'bunda', 'buceta', 'cabaço', 'sexo')
    # page.add(b)
    # page.add(quado_saida)
    # s = Container(s, bgcolor = 'red')



    page.update()

    # page.add_async(TextButton(visible=False, autofocus=True))
    # page.add_async(app)
    # page.add(Countdown(40, 'Volte a treinar por '))

def main3(page: Page):
    page.title = "texte"
    page.horizontal_alignment = "center"
    page.window_width = 780
    page.window_height = 750



    quado_saida = Container(width=775,height = 120, 
                                     border= border.all(0.1, color = 'white'),
                                    #  margin = margin.all(0),
                                    # padding = 0,
                                    # alignment = Alignment(-1,-1),
    )
    

    def Mostrar(*texto):
        quado_saida.content = Saidas(*texto, cor  = 'white', size = 25)
        # quado_saida.content.texto1_size = 30
        page.update()

    # Mostrar('mina pica')
    def add_view(*texto, cor  = 'white', size = 20):
        try:
            if quado_saida.content.texto1 == '':
                pass

            for i in texto:  
                if quado_saida.content.texto1 == '':
                    quado_saida.content.texto1 = i
                    quado_saida.content.texto1_color = cor
                    quado_saida.content.texto1_size = size
    

                elif quado_saida.content.texto2 == '':
                    quado_saida.content.texto2 = i
                    quado_saida.content.texto2_color = cor
                    quado_saida.content.texto2_size = size
    

                elif quado_saida.content.texto3 == '':
                    quado_saida.content.texto3 = i
                    quado_saida.content.texto3_color = cor
                    quado_saida.content.texto3_size = size
    

                elif quado_saida.content.texto4 == '':
                    quado_saida.content.texto4 = i
                    quado_saida.content.texto4_color = cor
                    quado_saida.content.texto4_size = size
    

                elif quado_saida.content.texto5 == '':
                    quado_saida.content.texto5 = i
                    quado_saida.content.texto5_color = cor
                    quado_saida.content.texto5_size = size
    

                elif quado_saida.content.texto6 == '':
                    quado_saida.content.texto6 = i
                    quado_saida.content.texto6_color = cor
                    quado_saida.content.texto6_size = size

                else:
                    print('limite de saidas atingido')

        except:
            quado_saida.content = Saidas(*texto, cor  = cor, size = size)
                            
        page.update()



    add_view('asaddsasdaa', 'aaaaaaaa',cor = 'green', size = 20)  
    add_view('vvvvvvvvvvvvv', 'iiiiiiiiiiiii', cor  = 'yellow', size = 20)  
    add_view('ccccccccccccc', 'vvvvvvvvvvvv', cor  = 'red', size = 10)  


    page.add(quado_saida)

    page.update()

def main_test(page: Page):
    page.title = "Metrônomo"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 800


    p = Pomodoro()



    page.add(p)
  


    page.update()

app(target=main2)