import flet as ft


def Teclas(e: ft.KeyboardEvent):
    match e.key:
        case ' ':
            print('pressionou space')               
        case 'Enter':
            print('pressionou enter')
        case 'P':
            print('pressionou P')
        

def main(page: ft.Page):
       


    page.on_keyboard_event = Teclas
    page.add(
        ft.Text("Press any key with a combination of CTRL, ALT, SHIFT and META keys...")
    )

ft.app(target=main)