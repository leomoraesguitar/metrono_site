# <<<<<<< HEAD

from arquivo_metronomo import Arquivo, Juntar, Ler_json, Escrever_json
from os import getcwd
# from pyautogui import size
import ctypes.wintypes
import tkinter.colorchooser as colorchooser


__docformat__ = "restructuredtext"


def size():
    """Returns the width and height of the screen as a two-integer tuple.

    Returns:
      (width, height) tuple of the screen size, in pixels.
    """
    return (ctypes.windll.user32.GetSystemMetrics(0), ctypes.windll.user32.GetSystemMetrics(1))


largura, altura = size()
altura_janela = altura-250
# from collections import namedtuple
# Size = collections.namedtuple("Size", "width height")
inicializar, arquiv, config = Arquivo()


# try:
#     dic  = Ler_json('cores_config.json')
# except:
#     dic = {nome:'gray' for nome in cores}
#     Escrever_json(dic,'cores_config.json')
# iniciar_cores = False

# def  self.Default_cor(nome):
#     if not iniciar_cores:
#         try:
#             return dic[nome]
#         except:
#             return 'gray'
#     else:
#         return 'gray'
play = Juntar(getcwd(), r'imagens\play.png')
pause = Juntar(getcwd(), r'imagens\pause.png')
stopp = Juntar(getcwd(), r'imagens\stopp.png')
salvar = Juntar(getcwd(), r'imagens\salvar.png')


class Layout:
    def __init__(self):
        self.iniciar_cores = False
        self.inicializar = False
        self.cores = [
            'cor_texto_but',
            'cor_fundo_but',
            'cor_de_fundo_tab',
            'cor_de_fundo_metro',

            'cor_de_fundo_vol',
            'cor_texto_vol',

            'cor_de_fundo_treinamento',
            'cor_de_texto_treinamento',

            'cor_de_fundo_pomodoro',
            'cor_de_texto_pomodoro',

            'cor_de_fundo_saida',
            'cor_de_texto_saida',
            'cor_de_fundo_botoes'

        ]
        self.tamanhos = [
            'tamanho_fonte_but',
            'tamanho_but',
            'fonte_bpm',
            'tamanho_texto_trinamento',
            'tamanho_texto_pomodoro',
            'tamanho_texto_saida',
            'tamanho_texto_vol'
        ]
        self.dic = self.Iniciar_dic()
        # self.dic_t = self.Iniciar_dic_t()

    def Iniciar_dic(self):
        try:
            dic = Ler_json('cores_e_tamanhos_config.json')
        except:
            dic = {'Padrao':{'cores':None,'tamanhos':None}}
            dic['Padrao']['cores'] = {nome: 'gray' for nome in self.cores}
            dic['Padrao']['tamanhos'] = {nome: 10 for nome in self.tamanhos}
            Escrever_json(dic, 'cores_e_tamanhos_config.json')
        return dic

    def Iniciar_dic_t(self):
        try:
            dic_t = Ler_json('tamanhos_config.json')
        except:
            dic_t = {nome: 10 for nome in self.tamanhos}
            Escrever_json(dic_t, 'tamanhos_config.json')
        return dic_t

    def Default_cor(self, nome):
        if not self.iniciar_cores:
            try:
                return self.dic['Padrao']['cores'][nome]
            except:
                return 'gray'
        else:
            return 'gray'

    def Default_tamanho(self, nome):
        if not self.iniciar_cores:
            try:
                return self.dic['Padrao']['tamanhos'][nome]
            except:
                return 15
        else:
            return 15

    def DefaultValores(self, nome):
        try:
            if self.inicializar:
                return ''
            else:
                return arquiv['valores'][nome]
        except:
            return ''

    def Framer(self, layout, cor='#1f4d7a', alinhamento=('c', 't')):
        return [[sg.Frame('', layout, expand_y=True, expand_x=True, background_color=cor, title_color='grey',
                          element_justification=alinhamento[0],
                          vertical_alignment=alinhamento[1],
                          grab=True

                          )]]

    def Texto2(self, texto, size=(0, 0), dist=(0, 0), alin='c', fonte=('Helvetica', 13, 'bold')):
        return sg.Text(texto, font=fonte, size=size, pad=dist, justification=alin, text_color=self.cor_de_texto_treinamento, background_color=self.cor_de_fundo_treinamento)

    def entrada2(self, chave, size=(3, 0), justification='c'):
        return sg.Input(key=chave,
                        size=size,
                        pad=(10, 0),
                        justification=justification,
                        font=('Helvetica', 13, 'bold'),
                        default_text=self.DefaultValores(chave),
                        text_color=self.cor_de_texto_treinamento,
                        background_color=self.cor_de_fundo_treinamento,
                        border_width=2
                        )

    def Coluna(self, layout, size_subsample_width=1, pad=(0, 0), element_justification='c'):
        return sg.Column(layout, pad=pad, element_justification=element_justification, size_subsample_width=size_subsample_width, background_color=self.cor_de_fundo_treinamento)

    def But(self, nome):
        return sg.Button(nome, pad=(5, 0), border_width=12, size=(self.tamanho_but, 0), font=self.fonte_but, button_color=self.cor_but,  expand_x=True, expand_y=True, auto_size_button=True)

        # [sg.Input(default_text = 120,  visible = False, focus = True, key='-bpm2-', enable_events = False)],
    def ButImag(self, key, imagem, tamanho=3):
        return sg.Button(key=key, image_source=imagem, image_subsample=tamanho, bind_return_key=False, 
                         border_width=8, font=('Helvetica', 10, 'bold'), expand_x=False, expand_y=False)

    def ButImag2(self, key, imagem, tamanho=3, ret=False):
        return sg.Button(key=key, image_source=imagem, image_subsample=tamanho,
                         bind_return_key=ret, border_width=8, font=('Helvetica', self.tamanho_fonte, 'bold'),
                         use_ttk_buttons=False, expand_x=True, expand_y=False
                         #    button_color = ('black', self.cor_fundo_but)
                         )

    def Cb(self, nome, key, cor_texto='white', cor_fundo='black', tamanho_font=20, evento=False):
        return sg.Checkbox(nome, key=key, default=self.DefaultValores(key), font=('Helvetica', tamanho_font, 'bold'), pad=(0, 0), enable_events=evento,  text_color=cor_texto, background_color=cor_fundo, expand_y=False, expand_x=True)

    def Tabe(self, nome, layout, visible=True):
        return sg.Tab(
            nome, layout, expand_x=True, expand_y=True,  background_color=self.cor_de_fundo_treinamento,
            font=('Helvetica', 20, 'bold'), border_width=8, element_justification='l'
        )

    def item_row(self, i):
        tamanho_but = 20
        tamnaho_fontes = 13

        # def entrada2(chave, size=(tamnaho_fontes, 1), justification='c'):
        #     return sg.Input(key=chave, size=size, pad=(10, 0), justification=justification, font=('Helvetica', tamnaho_fontes, 'bold'), default_text=DefaultValores(chave))

        """
        A "Row" in this case is a Button with an "X", an Input element and a Text element showing the current counter
        :param item_num: The number to use in the tuple for each element
        :type:           int
        :return:         List
        """
        row = [
            sg.pin(
                sg.Column(
                    [
                        [sg.Button(sg.SYMBOL_X, pad=(0, 0), size=(2, 0), border_width=0, font=('Helvetica', 9), button_color=('white', self.cor_de_fundo_treinamento),
                                   k=('-DEL-', i), tooltip='Delete this item')] +
                        [self.Coluna([[self.entrada2(f'-TR-{i}-', size=(43, 0), justification='l')]], size_subsample_width=15)] +
                        [self.Coluna([[self.entrada2(f'-DR-{i}-')]], pad=(3, 0))] +
                        [self.Coluna([[self.entrada2(f'-BPMI-{i}-')]])] +
                        [self.Coluna([[self.entrada2(f'-BPMF-{i}-')]])] +
                        [self.Coluna([[self.entrada2(f'-PASSO-{i}-')]])] +
                        [self.Coluna([[self.ButImag(f'-play-{i}', play, tamanho_but)]+[
                         self.ButImag(f'-pause-{i}', pause, tamanho_but)]], pad=(4, 0))]
                    ], k=('-ROW-', i), pad=(0, 0), element_justification='l', vertical_alignment='t', background_color=self.cor_de_fundo_treinamento)
            )
        ]
        return row

    def Tarefa(self, i):
        tamanho_but = 20
        # tamnaho_fontes = 13
        # cor_de_fundo = '#062322'

        if i == 0:
            layout = [
                [sg.Column(
                    [
                        [sg.T(' ', background_color=self.cor_de_fundo_treinamento)],
                        [sg.Text(sg.SYMBOL_X, background_color=self.cor_de_fundo_treinamento, pad=(0, 0), size=(2, 0), border_width=0, text_color='white',
                                 font=('Helvetica', 9))]], element_justification='c', pad=(0, 0), background_color=self.cor_de_fundo_treinamento)] +
                [self.Coluna([[self.Texto2('         Treino', alin='c', fonte=('Helvetica', 11, 'bold'))], [self.entrada2(f'-TR-{i}-', size=(43, 0),
                                                                                                                          justification='l')]], element_justification='l', pad=((0, 0), (0, 0)))] +
                [self.Coluna([[self.Texto2('Duração', fonte=('Helvetica', 11, 'bold'))], [self.entrada2(f'-DR-{i}-')]])] +
                [self.Coluna([[self.Texto2('In', fonte=('Helvetica', 11, 'bold'))], [self.entrada2(f'-BPMI-{i}-')]])] +
                [self.Coluna([[self.Texto2('Fim', fonte=('Helvetica', 11, 'bold'))], [self.entrada2(f'-BPMF-{i}-')]])] +
                [self.Coluna([[self.Texto2('Passo', fonte=('Helvetica', 11, 'bold'))], [self.entrada2(f'-PASSO-{i}-')]])] +
                [sg.Column([[sg.Text('',  background_color=self.cor_de_fundo_treinamento)], [self.ButImag(f'-play-{i}', play, tamanho_but), self.ButImag(
                    f'-pause-{i}', pause, tamanho_but)]
                ], element_justification='l', vertical_alignment='t', pad=((5, 0), (0, 0)), background_color=self.cor_de_fundo_treinamento)]
            ]
        else:
            layout = [
                self.item_row(i)


            ]

        return layout

    def FazerJanela(self, arquiv, inicializar=False):
        '''  
        # tamnaho_caixas = 8
        # cor_de_fundo = '#062322'
        # cor_de_fundo_frame1 =  self.Default_cor('cor_de_fundo_frame1')
        # cor_de_fundo_frame2 = '#062322'
        # cor_botoes1 = 'white'
        # cor_botoes2 = 'white'
        # cor_texto1 = 'white'
        # cor_texto2 = 'white'
        # tamanfo_fonte1 = 20
        # tamanfo_fonte2 = 17
        # tamanfo_fonte3 = 17
        # fonte1 = ('Helvetica', tamanfo_fonte1)
        # fonte1B = ('Helvetica', tamanfo_fonte1, 'bold')
        # fonte2 = ('Helvetica', tamanfo_fonte2)
        # fonteB = ('Helvetica', tamanfo_fonte2, 'bold')
        # fonte3 = ('Helvetica', tamanfo_fonte3)
        # fonte3B = ('Helvetica', tamanfo_fonte3, 'bold')
'''
        self.tamanho_fonte = 14
        '''botoes de mudança de bpm'''
        self.cor_texto_but = self.Default_cor('cor_texto_but')
        self.cor_fundo_but = self.Default_cor('cor_fundo_but')
        self.cor_but = (self.cor_texto_but, self.cor_fundo_but)
        self.cor_de_fundo_tab = self.Default_cor('cor_de_fundo_tab')
        self.cor_de_fundo_metro = self.Default_cor('cor_de_fundo_metro')
        self.fonte_but = ('Helvetica', self.Default_tamanho(
            'tamanho_fonte_but'), 'bold')
        self.tamanho_but = self.Default_tamanho('tamanho_but')
        self.fonte_bpm = self.Default_tamanho('fonte_bpm')
        ''' cores layout volume'''
        self.cor_de_fundo_vol = self.Default_cor('cor_de_fundo_vol')
        self.cor_texto_vol = self.Default_cor('cor_texto_vol')
        self.tamanho_texto_vol = self.Default_tamanho(
            'tamanho_texto_vol')
        ''' cor do layout treinamento'''
        self.cor_de_fundo_treinamento = self.Default_cor(
            'cor_de_fundo_treinamento')
        self.cor_de_texto_treinamento = self.Default_cor(
            'cor_de_texto_treinamento')
        self.tamanho_texto_trinamento = self.Default_tamanho(
            'tamanho_texto_trinamento')
        ''' cores do layout pomodoro'''
        self.cor_de_fundo_pomodoro = self.Default_cor('cor_de_fundo_pomodoro')
        self.cor_de_texto_pomodoro = self.Default_cor('cor_de_texto_pomodoro')
        self.tamanho_texto_pomodoro = self.Default_tamanho(
            'tamanho_texto_pomodoro')
        ''' cores do layout de saíoda'''
        self.cor_de_fundo_saida = self.Default_cor('cor_de_fundo_saida')
        self.cor_de_texto_saida = self.Default_cor('cor_de_texto_saida')
        self.tamanho_texto_saida = self.Default_tamanho('tamanho_texto_saida')
        ''' cores do layout de botoes'''
        self.cor_de_fundo_botoes = self.Default_cor('cor_de_fundo_botoes')

        def Texto_pomodoro(texto, size=(0, 0), dist=(0, 0), alin='c', fonte=self.tamanho_texto_pomodoro):
            return sg.Text(texto,
                           font=fonte,
                           size=size,
                           pad=dist,
                           justification=alin,
                           background_color=self.cor_de_fundo_pomodoro,
                           text_color=self.cor_de_texto_pomodoro,

                           )

        def Campo_treinamento(texto, chave, cor_texto=self.cor_de_texto_treinamento, cor_fundo=self.cor_de_fundo_treinamento, tamanho_fonte=self.tamanho_texto_trinamento):
            NAME_SIZE = 20
            largg = 150
            dots = largg - len(texto)-2
            texto = texto+' '+'.'*dots
            return [sg.Text(texto, text_color=cor_texto, font=('Helvetica', tamanho_fonte, 'bold'), background_color=cor_fundo, size=(NAME_SIZE, 1), justification='l', expand_x=True),
                    sg.Input(key=chave, text_color=cor_texto, pad=(0, 0), border_width=5, size=(3, 1), justification='c', background_color=cor_fundo,
                             font=('Helvetica', tamanho_fonte, 'bold'), default_text=self.DefaultValores(chave))
                    ]
        '''
        # pomodoro = Juntar(getcwd(), r'imagens\pomodoro.png')
        # soneca = Juntar(getcwd(), r'imagens\soneca.png')
        # continuar = Juntar(getcwd(), r'imagens\continuar.png')
        # print(continuar)
'''
        sg.theme_add_new(
            'NewTheme17608',
            {
                'BACKGROUND': '#062322',  # '#062322'
                'TEXT': '#cdf1ef',
                'INPUT': '#434948',
                'TEXT_INPUT': '#fde2e4',
                'SCROLL': '#333',
                'BUTTON': ('#fde2e4', '#5f6766'),
                'PROGRESS': ('#fde2e4', '#333'),
                'BORDER': 0,
                'SLIDER_DEPTH': 1,
                'PROGRESS_DEPTH': 0,
            }
        )
        sg.theme('NewTheme17608')
        '''
        # sg.theme('pomodoro')
        # sg.theme('NewTheme8447')
        # sg.theme('NewTheme13856')
        # sg.theme('DarkGrey6')

        # cor_vermelha = '#a94442'
        # cor_de_fundo_botoes = '#a94442'
        # cor_texto = '#1f4d7a'
        # cor_cinza = '#ccd1d3'
        # cor_azul = '#1f4d7a'

        # title = 'Metrônomo Leo'

        # close64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsSAAALEgHS3X78AAAE30lEQVRIiZ2VXYgdRRqGn6+quvucM/85iRoTNevMBJFEWY0GFQTBC1HBlaz/jMpoFFfXBdmFvdiLvRIEFRHFGBXMjUQhF/6Bol6sSNaIruCNir/R/Dlx5iRzck736e6qby/6JDlx9CIWFN10Ue/7vW+9X7XcDn8bryWPL2vERkNQQPj9Q72K7F3s7Hxb9bZ98L0bj91jt1y23kxNTxIEGUQ/aTYR6WW9cud/Prx01zf7/7FP5EHXHG7Y6bVTpBPLMSegCWKEEMKvkihgjEWDP+FbEjxTa1bjv9l/CsIKF3ypHhUDSFGACCKC956iKKjV6/hfkCjgUNK0TW1oCA3h+EJk8UUBYFCsQaSyRajArUWLnEONcTrT68nTLtZaEKmmMTiUlsREGy9HO0dgcL1y6lgtZrAsEYFexhwxq2buYfru+1mcOo+828UYg4rgUH7OSkY3zbDq1lkaV1yFP9TqEyy18jiBCMF7DjYmOOu+hxifnCSKItZuvp/F6fPJ05TEwE+dHhN33MfpGy4iFAVjf7qF8etvBV9y1IilBApGIMt6TExOM372JKqKqhLFMdOz93Jk6jx+bHVoztzLyj9eiHqP2Gq7O3UlGAuq1RwYDlUwhoChMdSAz3ZxaEeD8T/fBggaAnGtxpqZWdKFBSbOPLMCCQGJItJPdrHw4lOYRgNsBM6dSCDGErIuodtGkhoyPEr68U5svcbI1ZsQY0CV2vAw9ZGRKjEiSBTR/fQjDm9/AddcjqoSul182kYHVDhJauRffUH7wD7ilatxzVOwI6PM7XiJLO2x4rob0CgGVTSEKigidD94j/ltW9Dg0b0/4BfmyQ8ewKUdWLZ6wCIB9SXFXJvQ+hLkc6QeEznHf199jY1rpjh1w0ZUFTGm7z18/tSj2Hffor5shKLdhhJCADMcw7IlKRIkAqkJRIa4LPl6d5c/PPJkBd5vpArcArD+ue101l1Md08bFxuIBUlOyOUggUIAVIl94Kv5wKqtz7L+7r/0bRHEmApcFbwnHhljw6tv0b3kEtK5gDWmj/GbfQAWZbdaztjyPOfP3oN6D8GDCO133uDAvx9CyxKsRX1JMjbBBa+8Rnbl5RSpR35RfXUGfVLnYGFBcTfdwLo77yLkPYy14CLa773JngfuoNy7QOh2WPnw09WVkufUm8s598G/s+eT9wmBJZ1m+sVTFNBc4Wi8vJ3v//kAJk7AOhbf3MGezTfjWwuYCcv8s1s58K+/okWOxDGdjz5g7+YZtKRSoL+igCp5FKVntGk48sTTzDWb1C+4mB833wgETD2CELBjEfNbtyAjo4xdcz27N11L6B5GGoZQhN+26KiSoII9LebnJx9BkggzNIQkyfEdItiRQGvbM7S2bQHJMGN1NO8ds2dQhBORYBCjAFEE1kFSw0QxuAiTJCAGce64vz4gviTkOTJcErIMMRbyDIxg7bHTFnc47clcmpdj43VkeBRJEkytgdTqSL2OiRMkSRDroH9t4EtCUaBZhmYpIUurZ9pFfVnuX+w62xfjeq3D3/6vbifXrT1XkzgWdREmipA4RlwMUYRY21cg/X+lJ5gSbIHGOVovCHmOCSX7DrbMx599icIhVI2cA5c5mC1gbGnITm4oqAOr0PoOXs9g51HAGiITyCDByXDp4KuiaoESmP8/YC0Y5GajmEsAAAAASUVORK5CYII='
        '''
        menu_def = [
            ['Arquivo', ['Importar', 'Exportar',
                         'Selecionar Planilha', 'Aparência', 'Sair']],

            ['Créditos', ['Autor', ['Programa criado por Leãnio Moraes'],
                          'Email/pix', ['leaniomoraes@gmail.com']]],

            ['Ajuda', ['manual', 'Baixar audio "1.Wav"', 'Baixar audio "2.Wav"',
                       'Obter "client_secret.json"', 'Ciar Planilha Google']]

        ]
        # layout_menus = [
        #     #   [sg.Titlebar(title, sg.CUSTOM_TITLEBAR_ICON)],
        #     [sg.Menu(menu_def)]]

        # menu_def2 = [[],
        #              ['Arquivo', ['Importar', 'Exportar',
        #                           'Selecionar Planilha', 'Aparência', 'Sair']],

        #              ['Créditos', ['Autor', ['Programa criado por Leãnio Moraes'],
        #                            'Email/pix', ['leaniomoraes@gmail.com']]],

        #              ['Ajuda', ['manual', 'Baixar audio "1.Wav"', 'Baixar audio "2.Wav"',
        #                         'Obter "client_secret.json"', 'Ciar Planilha Google']]

        #              ]
        # layout_menus2 = [
        #     [sg.ButtonMenu('Arquivo', menu_def=menu_def2[1], border_width=0, p=(0, 0),
        #                    button_color=(
        #                        self.cor_de_texto_treinamento, '#580c0c'),
        #                    font=('Helvetica', 10, 'bold'))] +
        #     [sg.ButtonMenu('Créditos', menu_def=menu_def2[2], border_width=0, p=(0, 0),
        #                    button_color=(
        #                        self.cor_de_texto_treinamento, '#580c0c'),
        #                    font=('Helvetica', 10, 'bold'))] +
        #     [sg.ButtonMenu('Ajuda', menu_def=menu_def2[3], border_width=0, p=(0, 0),
        #                    button_color=(
        #                        self.cor_de_texto_treinamento, '#580c0c'),
        #                    font=('Helvetica', 10, 'bold'))]
        # ]
        # layout_menus2 = [[sg.Frame('', layout_menus2,
        #                            background_color='#580c0c',
        #                            expand_x=True,
        #                            pad=(0, 0),
        #                            border_width=0
        #                            )] +
        #                  #    SYMBOL_TITLEBAR_MINIMIZE = '_'
        #                  #     SYMBOL_TITLEBAR_MAXIMIZE = '◻'
        #                  #     SYMBOL_TITLEBAR_CLOSE = 'Ｘ'
        #                  [sg.Button(sg.SYMBOL_TITLEBAR_MINIMIZE, k='minimizar')] +
        #                  [sg.Button(sg.SYMBOL_TITLEBAR_MAXIMIZE, k='maximizar')] +
        #                  [sg.Button(sg.SYMBOL_TITLEBAR_CLOSE, k='Sair')],

        #                  ]

        layout_menus2 = [
                        [sg.Titlebar('Metrônomo', text_color=self.cor_de_texto_treinamento,
                                     background_color='black')],
                        [sg.MenubarCustom(menu_definition=menu_def,
                                          bar_background_color=self.cor_de_fundo_tab,
                                          bar_text_color=self.cor_de_texto_treinamento,
                                          background_color=self.cor_de_fundo_tab,
                                          text_color=self.cor_de_texto_treinamento,
                                          font=('Helvetica', 12, 'bold'),
                                          bar_font=('Helvetica', 12, 'bold')


                                          )]
        ]

        layout_metronomo = [
            [sg.Combo([1, 2, 3], visible=False, k='4564654')],
            # [sg.Frame('', [
            [sg.Input(default_text=self.DefaultValores('nome_planilha'), key='nome_planilha', visible=False)] +
            [self.But('-1'), self.But('-5'), self.But('-10')] +
            [sg.Text('BPM', font=('Helvetica', self.tamanho_fonte, 'bold'), visible=False),
             sg.Combo(list(range(30, 900)),  auto_size_text=True, expand_x=True, expand_y=True, default_value=120,text_color = self.cor_texto_but,
                      enable_events=True,  font=('Helvetica', self.fonte_bpm, 'bold'),background_color = self.cor_de_fundo_tab,
                      key='-bpm-', size=(4, 1))] +
            [self.But('+1'), self.But('+5'), self.But('+10')],
            # [sg.Button('Ocultar BPM', expand_y=True, expand_x=True)]
        ]
        layout_metronomo = self.Framer(
            layout_metronomo, self.cor_de_fundo_metro)
        layout_metronomo = [
            [sg.TabGroup(

                [[

                    sg.Tab('Exibir', layout_metronomo,
                           expand_x=True, expand_y=True, font='_ 20', border_width=8, element_justification='c'),

                    sg.Tab('Ocultar', [[]], font='_ 20',
                           element_justification='c'),

                ]],
                expand_x=True,
                expand_y=True,
                font=('Helvetica', 2),
                tab_location='bottomright',
                background_color=self.cor_de_fundo_tab,
                title_color='gray')],


        ]
        layout_metronomo = self.Framer(layout_metronomo, self.cor_de_fundo_tab)
        layout_metronomo += [[sg.Combo(list(arquiv.keys()),   default_value=self.DefaultValores(
            '-arq-'), auto_size_text=True,  size=(19, 20), expand_x=True, enable_events=True, text_color=self.cor_texto_but,
            font=('Helvetica', 15, 'bold'), key='-arq-', background_color=self.cor_de_fundo_tab)]]
        layout_vol = [
            [sg.Text('Vol.', font=('Helvetica', self.tamanho_texto_vol, 'bold'), text_color=self.cor_texto_vol, background_color=self.cor_de_fundo_vol, pad=((0, 0), (20, 20))),
             sg.Slider(range=(0, 1.0), border_width=0, resolution=0.1, orientation='h', font=('Helvetica', int(self.tamanho_texto_vol/2), 'bold'),
                       default_value=1, expand_x=True, enable_events=True, text_color=self.cor_texto_vol, background_color=self.cor_de_fundo_vol, key='-volume-', size=(20, 20), pad=((0, 25), (3, 20)))] +
            [self.Cb('Inverter   ', '-inverter-', cor_texto=self.cor_texto_vol,
                     cor_fundo=self.cor_de_fundo_vol, tamanho_font=self.tamanho_texto_vol)] +
            [self.Cb('Treino_habilitado    ', 'treino_habilitado', tamanho_font=self.tamanho_texto_vol, cor_texto=self.cor_texto_vol,  cor_fundo=self.cor_de_fundo_vol, evento=True)] +
            [sg.Text('Tap',  text_color=self.cor_texto_vol, background_color=self.cor_de_fundo_vol, font=('Helvetica', self.tamanho_texto_vol, 'bold')), sg.Button(sg.SYMBOL_CIRCLE, key='-tap-',
                                                                                                                                                                   button_color='gray', tooltip='clic duas vez ou \npressione a tecla "5" duas vezes')]
        ]
        layout_vol = self.Framer(layout_vol, cor=self.cor_de_fundo_vol,
                                 alinhamento=('l', 't'))
        layout_tempo = [
            Campo_treinamento('Intervalo (s)', '-Intervalo-'),

            [self.Cb('Tempo (min)', '-tempo-', cor_texto=self.cor_de_texto_treinamento,
                     cor_fundo=self.cor_de_fundo_treinamento, tamanho_font=self.tamanho_texto_trinamento)]
            #  [sg.Slider(range = (0.3,3), default_value = 1, resolution=0.1, k = '-zoom-',
            #             orientation ='h',
            #             enable_events = True)]
        ]
        layout_compassos = [
            [sg.Text('Tipo de Compasso', font=('Helvetica', self.tamanho_texto_trinamento, 'bold'), text_color=self.cor_de_texto_treinamento, background_color=self.cor_de_fundo_treinamento)] +
            [sg.Combo(['2/4', '3/4', '4/4'],
                      size=(3, 0),
                      key='-tipo_compasso-',
                      default_value=self.DefaultValores('-tipo_compasso-'),
                      font=('Helvetica', self.tamanho_texto_trinamento, 'bold')
                      )],
            [sg.Text('Quantidade de Compassos', font=('Helvetica', self.tamanho_texto_trinamento, 'bold'), text_color=self.cor_de_texto_treinamento, background_color=self.cor_de_fundo_treinamento)] +
            [sg.Input(size=(2, 0), key='-qtd_compassos-',
                      default_text=self.DefaultValores('-qtd_compassos-'),
                      font=('Helvetica', self.tamanho_texto_trinamento, 'bold'), border_width=5, text_color=self.cor_de_texto_treinamento, background_color=self.cor_de_fundo_treinamento)]
        ]
        layout_treinamento = [
            [sg.Column([

                # [sg.Text('Vol.', font=('Helvetica', 16, 'bold'), text_color=self.cor_texto_vol, background_color=self.cor_de_fundo_vol, pad=((10, 0), (25, 0))),
                #  sg.Slider(range=(0, 1.0), border_width=0, resolution=0.1, orientation='h', font=('Helvetica', 10, 'bold'),
                #            default_value=1, expand_x=False,enable_events=True, text_color=self.cor_texto_vol, background_color=self.cor_de_fundo_vol, key='-volume-', size=(30, 20), p = ((0,0),(20,20)))],
                Campo_treinamento('Meta (bpm)', '-meta-'),
                Campo_treinamento('Início (bpm)', '-inicio-'),
                Campo_treinamento('Passo In(bpm)', '-passo-'),
                Campo_treinamento('Passo Fim(bpm)', '-passo_fim-')



            ],
                expand_y=True,
                expand_x=True,
                background_color=self.cor_de_fundo_treinamento,
                element_justification='l',
                key='-treinamento-',
                vertical_alignment='t'),

                sg.Column([
                    [sg.TabGroup(
                        [[
                            self.Tabe('Tempo', layout_tempo),
                            self.Tabe('Compassos', layout_compassos)
                        ]],
                        expand_x=True,
                        expand_y=True,
                        tab_location='topleft',
                        # size=(0, altura_janela-550),
                        font=('arial', 20, 'bold'),
                        title_color='gray',
                        background_color=self.cor_de_fundo_treinamento,
                        # tab_background_color = self.cor_de_fundo_treinamento,
                        selected_background_color=self.cor_de_fundo_treinamento,
                        selected_title_color=self.cor_de_texto_treinamento,
                        k='-tempo/compasso-'
                    )
                    ]
                ],
                expand_y=True,
                expand_x=True,
                background_color=self.cor_de_fundo_treinamento,
                element_justification='c', vertical_alignment='t')
            ]]
        layout_treinamento = self.Framer(
            layout_treinamento, cor=self.cor_de_fundo_treinamento, alinhamento=('l', 't'))
        l_add = [[sg.Button('Add Tarefa',
                            border_width=3,
                            size=(0, 0),
                            font=('Helvetica', 10, 'bold'),


                            )]
                 #  [sg.Button('Remover Tarefa', border_width = 0,   size = (0,0))]
                 ]
        qtd_tarefas = int(self.DefaultValores('qtd_tarefas')) if self.DefaultValores(
            'qtd_tarefas') != '' else 2
        for ia in range(qtd_tarefas):
            l_add.extend(self.Tarefa(ia))
        layout_tarefas = [
            [sg.Column(
                l_add,

                vertical_alignment='t',
                vertical_scroll_only=True,
                scrollable=True,
                key='-COL-',
                size=(720, 250),
                expand_y=True,
                expand_x=True,
                element_justification='l',
                background_color=self.cor_de_fundo_treinamento,
                visible=True


            )
            ]

        ]

        layout_pomodoro = [
            [sg.Checkbox('',
                         key='-continuar-',
                         default=self.DefaultValores('-continuar-'),
                         tooltip="continuar executando o metrônomo",
                         font=('Helvetica', self.tamanho_texto_pomodoro),
                         pad=(0, 0),
                         expand_x=False,
                         expand_y=False,
                         background_color=self.cor_de_fundo_pomodoro,
                         text_color=self.cor_de_texto_pomodoro,
                         )] +
            [Texto_pomodoro('Continuar'+' '*3, fonte=('Helvetica', self.tamanho_texto_pomodoro, 'bold'))] +
            [sg.Checkbox('', key='-habilitar_pomodoro-', default=self.DefaultValores('-habilitar_pomodoro-'),                     background_color=self.cor_de_fundo_pomodoro,
                         text_color=self.cor_de_texto_pomodoro, font=('Helvetica', self.tamanho_texto_pomodoro), pad=(0, 0))] +
            [Texto_pomodoro('Pomodoro', fonte=('Helvetica', self.tamanho_texto_pomodoro, 'bold'))] +
            [sg.Input(border_width=5, default_text=self.DefaultValores('-Pomodoro-'), font=('Helvetica', 20, 'bold'),                     background_color=self.cor_de_fundo_pomodoro,
                      text_color=self.cor_de_texto_pomodoro, key='-Pomodoro-', size=(2, 1))] +

            [Texto_pomodoro(' '*3+'Descanso', fonte=('Helvetica', self.tamanho_texto_pomodoro, 'bold'))] +
            [sg.Input(border_width=5, default_text=self.DefaultValores('-descanso-'), font=('Helvetica', 20, 'bold'),  background_color=self.cor_de_fundo_pomodoro,
                      text_color=self.cor_de_texto_pomodoro, key='-descanso-', size=(2, 1))]
        ]
        layout_pomodoro = [[sg.Frame('', layout_pomodoro, expand_y=False, expand_x=True,
                                     background_color=self.cor_de_fundo_pomodoro, title_color='grey', element_justification='c')]]
        layout_botoes = [

            # [sg.Frame('', [
            [self.ButImag2(key='OK', imagem=play, ret=False)] +
            [self.ButImag2('Pause', pause)] +
            [self.ButImag2('Stop', stopp)] +
            [self.ButImag2('Salvar', salvar)]
        ]
        layout_botoes = self.Framer(
            layout_botoes, cor=self.cor_de_fundo_pomodoro)
        layout_saidas = [
            [sg.Text(key='-tempo_de_treino-',
                     font=('Helvetica', self.tamanho_texto_saida),
                     background_color=self.cor_de_fundo_saida,
                     text_color=self.cor_de_texto_saida

                     )] +
            [sg.T('         ', background_color=self.cor_de_fundo_saida,
                  text_color=self.cor_de_texto_saida)],
            [sg.Text(key='-tempo_pomodoro-',  font=('Helvetica', self.tamanho_texto_saida), background_color=self.cor_de_fundo_saida, text_color=self.cor_de_texto_saida)] +
            [sg.Text(key='-contagem-',
                     font=('Helvetica', self.tamanho_texto_saida), background_color=self.cor_de_fundo_saida, text_color=self.cor_de_texto_saida)] +
            [sg.Text(key='-tempo_restante-',
                     font=('Helvetica', self.tamanho_texto_saida), background_color=self.cor_de_fundo_saida, text_color=self.cor_de_texto_saida)],
            [sg.Text('', font=('Helvetica', 20, 'bold'), k='-respiracao-', justification='c',
                     background_color=self.cor_de_fundo_saida, expand_x=True, text_color='green', visible=False)],
            [sg.Text('', size=(0, 1), relief='groove', expand_x=True,
                     text_color='yellow', font=('Helvetica', 10), background_color='black', key='-TEXT-', metadata=0, border_width=1, visible=False)]

        ]
        layout_saidas = [
            [sg.TabGroup(
                [[

                    sg.Tab('Exibir',  layout_saidas,
                           expand_x=True, expand_y=True, font=('Helvetica', 3, 'bold'), border_width=8, element_justification='l', background_color=self.cor_de_fundo_saida),

                    sg.Tab('Ocultar', [
                        []], font='_ 6', element_justification='l', background_color=self.cor_de_fundo_saida),

                ]], expand_x=True, expand_y=True, tab_location='topright', 
                title_color='gray', selected_background_color=self.cor_de_fundo_saida, 
                background_color=self.cor_de_fundo_saida,
                font=('Helvetica', 2))]

        ]
        layout_saidas = self.Framer(
            layout_saidas, cor=self.cor_de_fundo_saida, alinhamento=('l', 't'))
        l2 = self.Framer(layout_pomodoro + layout_botoes +
                         layout_saidas, 'black')

        layout_tab = [
            [sg.TabGroup(
                [[
                    self.Tabe('Treinamento', layout_metronomo +
                              layout_vol+layout_treinamento),
                    self.Tabe('Tarefas', layout_tarefas)
                ]],
                expand_x=True,
                expand_y=True,
                tab_location='topleft',
                # size=(0, altura_janela-550),
                font=('Helvetica', 15),
                title_color = self.cor_texto_but,
                selected_title_color = self.cor_texto_but,
                # enable_events = True,
                key='-tab-',
                selected_background_color=self.cor_de_fundo_treinamento,
                background_color=self.cor_de_fundo_treinamento

            )
            ]
        ]

        layout_tab = self.Framer(layout_tab, 'black')
        # layout_tab = layout_vol+layout_tab
        # layout_treinamento = layout_vol+layout_treinamento
        layout = layout_menus2 + layout_tab + l2
        # layout = layout_tab+layout_vol+layout_menus

        window = sg.Window('Metrônomo', layout,
                           titlebar_background_color='green',
                           resizable=True,
                           return_keyboard_events=True,
                           use_default_focus=False,
                           no_titlebar=True,
                           use_custom_titlebar=True,
                           element_justification='c',
                           finalize=True,
                           grab_anywhere=True,
                        #    font=('Helvetica', 2, 'bold'),
                           location=(0, 0),
                           button_color=(self.cor_de_texto_saida,
                                         self.cor_de_fundo_botoes)



                           #    size = ()
                           #    element_padding = (0,0),
                           #    default_element_size = (50,0),
                           #    default_button_element_size = (5,2),
                           #    auto_size_buttons = True,
                           #    font=('Helvetica', 18, 'bold')
                           #    size = (0,altura_janela)#(largura//4)+120

                           )
        return window

    def Janela_config(self):

        # print(dic)
        def Campo_cofig(nome):
            key = nome
            tam = 25
            dots = 2*tam - len(nome)
            if dots < 1:
                dots = 1
            nome = nome+' '+'.'*dots
            return [sg.Text(nome, size=(tam, 1), font=('Helvetica', 13, 'bold'), justification='l', key=f'{nome}_t'),
                    sg.Input(default_text=self.Default_cor(
                        key), k=f'{key}_cor', s=(8, 1),font=('Helvetica', 10, 'bold')),
                    sg.Button( sg.SYMBOL_LEFT_ARROWHEAD, font=('Helvetica', 14), button_color=self.Default_cor(key),
                              k=key)]

        def Campo_cofig_tamanhos(nome):
            key = nome
            tam = 25
            dots = 2*tam - len(nome)
            if dots < 1:
                dots = 1
            nome = nome+' '+'.'*dots
            return [sg.Text(nome, size=(tam, 1), font=('Helvetica', 13, 'bold'), justification='l', key=f'{nome}_f'),
                    sg.Combo(list(range(1, 100)), font=('Helvetica', 12), default_value=self.Default_tamanho(key),
                             k=key, enable_events=True)]

        def Frame2(nome, layout):
            return [[sg.Frame(title=nome, layout=layout)]]
        
        layout_zoom = [[sg.Slider(range = (0.5,2), default_value = 1, tooltip = 'Zoom',resolution = 0.1, expand_x = True,orientation = 'h', k = '-zoom-')]]
        layout_metronomo = [
            [sg.Combo(list(self.dic.keys()),   default_value=list(self.dic.keys())[-1], auto_size_text=True,  size=(19, 20), expand_x=True, enable_events=True,
                font=('Helvetica', 15, 'bold'), key='-temas-', background_color=self.cor_de_fundo_tab)]
        ]

        layout_metronomo =  layout_metronomo +[Campo_cofig(nome) for nome in self.cores[:4]]
        layout_metronomo_tamanhos = [Campo_cofig_tamanhos(
            nome) for nome in self.tamanhos[:3]]
        layout_metronomo = Frame2(
            'BPM', layout_metronomo + layout_metronomo_tamanhos)

        layout_vol =  [Campo_cofig(nome) for nome in self.cores[4:6]]
        layout_pomodoro_vol = [Campo_cofig_tamanhos(
            nome) for nome in self.tamanhos[6:]]
        layout_vol = Frame2('Vol.', layout_vol + layout_pomodoro_vol)

        layout_Treinamento = [Campo_cofig(nome) for nome in self.cores[6:8]]
        layout_Treinamento_tamanhos = [
            Campo_cofig_tamanhos(nome) for nome in self.tamanhos[3:4]]
        layout_Treinamento = Frame2(
            'Treinamento', layout_Treinamento + layout_Treinamento_tamanhos)

        layout_pomodoro = [Campo_cofig(nome) for nome in self.cores[8:10]]
        layout_pomodoro_tamanhos = [Campo_cofig_tamanhos(
            nome) for nome in self.tamanhos[4:5]]
        layout_pomodoro = Frame2(
            'Pomodoro', layout_pomodoro + layout_pomodoro_tamanhos)

        layout_saida = [Campo_cofig(nome) for nome in self.cores[10:]]
        layout_saida_tamanhos = [Campo_cofig_tamanhos(
            nome) for nome in self.tamanhos[5:6]]
        layout_saida = Frame2('Saída', layout_saida + layout_saida_tamanhos)

        layout = layout_zoom + [[sg.Column(layout_metronomo + layout_Treinamento)] +
                  [sg.Column(layout_vol + layout_pomodoro + layout_saida)]]

        layout += [[sg.Button('Salvar Cores')]]

        window = sg.Window('Metrônomo Configurações', layout,
                           titlebar_background_color='green',
                           resizable=True,
                           return_keyboard_events=True, use_default_focus=False,
                           no_titlebar=False,
                           use_custom_titlebar=False,
                           element_justification='c',
                           finalize=True,
                           keep_on_top=True
                           #    size = ()
                           #    element_padding = (0,0),
                           #    default_element_size = (50,0),
                           #    default_button_element_size = (5,2),
                           #    auto_size_buttons = True,
                           #    font=('Helvetica', 18, 'bold')
                           #    size = (0,altura_janela)#(largura//4)+120

                           )
        return window

    def Get_cor(self, window, key):
        # Abra a janela de seleção de cor usando o Tkinter
        color = colorchooser.askcolor()[1]
        try:
            if color[1]:
                window[key].update(button_color=color)
                window[f'{key}_cor'].update(color)

                return color
        except:
            return None


def TestarLayout():
    global qtd_tarefas
    # window = FazerJanela(arquiv, inicializar)
    lt = Layout()
    janela_prog = lt.FazerJanela(arquiv, inicializar)
    janela_config = None
    # m = Metronomo_leo(window)
    # m.IniciaTeclas(window)

    def Win_Jan(nome):
        return window == janela_prog and event in nome

    def Win_Config(nome):
        return window == janela_config and event in nome

    while True:
        # event, values = window.read()
        window, event, values = sg.read_all_windows()

        if Win_Jan([sg.WIN_CLOSED, 'Sair']):
            break
        elif Win_Jan(['maximizar']):
            if not window.maximized:
                window.maximize()
            else:
                window.normal()
        elif Win_Jan(['minimizar']):
            window.Minimize()

        elif Win_Jan(['Aparência']):
            # try:
            janela_config = lt.Janela_config()
            janela_prog.hide()
            # except:
            #     sg.popup('Deu erro')
        elif Win_Config([sg.WIN_CLOSED]):
            janela_config.hide()
            janela_prog.un_hide()
        elif Win_Config(['-temas-']):
            dic = Ler_json('cores_e_tamanhos_config.json')
            try:            
                for key in dic[values['-temas-']]['cores'].keys():
                    cor = dic[values['-temas-']]['cores'][key]
                    window[key].update(button_color=cor)
                    window[f'{key}_cor'].update(cor)
            except:
                pass
            try:    
                for key in dic[values['-temas-']]['tamanhos'].keys():
                    tamanho = dic[values['-temas-']]['tamanhos'][key]
                    window[key].update(tamanho)
            except:
                pass

        elif window == janela_config and event in lt.cores:
            cor = lt.Get_cor(window, event)
            if cor != None:
                dic = Ler_json('cores_e_tamanhos_config.json')
                # dic['Padrao']['cores'][event] = cor
                # dic[values['-temas-']] = dic['Padrao']
                dic[values['-temas-']] = dic['Padrao']

                try:
                    dic[values['-temas-']]['cores'][event] = cor
                except:
                    dic[values['-temas-']] = {'cores': {event:None}}
                    dic[values['-temas-']]['cores'][event] = cor
                Escrever_json(dic, 'cores_e_tamanhos_config.json')
        elif window == janela_config and event in lt.tamanhos:
            # cor = lt.Get_cor(window, event)
            # if cor != None:

            # print(event, values[event])
            dic = Ler_json('cores_e_tamanhos_config.json')
            # dic['Padrao']['tamanhos'][event] = values[event]
            # dic[values['-temas-']] = dic['Padrao']
            dic[values['-temas-']] = dic['Padrao']
            try:
                dic[values['-temas-']]['tamanhos'][event] = values[event]
            except:
                dic[values['-temas-']] = {'tamanhos': {event: None}}
                dic[values['-temas-']]['tamanhos'][event] = values[event]

            Escrever_json(dic, 'cores_e_tamanhos_config.json')

        elif Win_Config(['Salvar Cores']):
            # janela_config.hide()
            # janela_prog.un_hide()
            dic = Ler_json('cores_e_tamanhos_config.json')
            dic['Padrao'] = dic[values['-temas-']]
            Escrever_json(dic, 'cores_e_tamanhos_config.json')

            lt = None
            lt = Layout()
            window.close()
            janela_prog = lt.FazerJanela(arquiv, inicializar)

        elif Win_Jan(['treinamento']):
            if values['treinamento'] == 'Tarefas':
                window['-COL-'].update(visible=True)
            else:
                window['-COL-'].update(visible=False)

        elif Win_Jan(['OK']):
            print(values)

    window.close()


if __name__ == "__main__":
    TestarLayout()
