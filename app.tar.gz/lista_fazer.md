
# Lista de coisas a implementar no app:-----------------------------------------------------

- importar tarefas
- exportar tarefas
- selecionar planilha
- escrever tarefas completadas na planilha
- criar alguns temas
- Transformar os grupo de objetos da janela em classes
- Cria um layout estilo o site do TJSE
- ResponsiveRow pode ser útil para as tarefas
- Adicionar um time para a duração do treino (1h)
- selecionar temas
- ajeitar a função Sair






- pause não tá parando o treinamento - ok
- estudar sobre os métodos nativos did_mount e will_mount - ok
- display para mostar o tempo total da lista de tarefas - ok
- exibir o tempo total para o caso de "play tarefas" - ok
- ajeitar a exibição do valor inicial do passo (0.1 para 1) - ok
- mudar o layout dos botões add tarefa e play tarefas - ok
- habilitar o pomodo junto com otreino de compassos - ok
 - posicionar objetos dentro de Container - ok
- o display está iniciando apagado - ok
- criar campos de intradas ao lodo de "meta", 'início' ... para que posa ser digitado um valor e esse valor ser atualizar o valor entre () - ok
-  a caixa de "tempo" não está funcionando - ok
 - habilitar o "play tarefas" - rodar todas as tarefas em sequência - ok
- pausar metronomo nas pausas do pomodoro - ok
- mewlhorar a vizualizaç~~ao das saídas - ok
- Criar um layout estilo o pligin NAM - ok
 - habilitar salvar configura~ções ao sair, não apenas as tarefas - ok
- ajeitar a inicialização dos parâmetros - ok
- colocar pause no pomodoro, treinamento e compassos - ok
 - ativar o pomodoro em pararelo aos modos compassos - ok
 - ativar o pomodoro em pararelo aos modos treinamento/tarefas - ok
- enviar os dados de exibição de controlador_metronomo_flet para o container saida de Todoapp - ok
- Botão para dar play na lista de tarefas e executar todas - ok
- Dropdown para selecionar alguma config salva - ok
- Habilitar os modos Treinamento e compassos - ok
- Habilitar as exibições das saídas - ok
- criar as funções dos botôes dos modos treinamento/compassos -ok
- ativar as funções do metrônomo (modos de treino e etc) -ok
- ajeitar as acções das tarefas - ok
-criar varios continers de saida. na hora de exibir, torna-o vizível e oculta os demais - ok
- ativar o modo treinamento - ok
- ajustar o tamenho do respiro - ok
- ativar as açoes dos botoes da lista de tarefas - ok
- configurando o pomodoro (síncrono ou assíncrono?) - ok
 - salvar as tarefas com uma chave específica - ok
- adicionar função selecionar tarefas - ok
- criar uma forma de selecionar o modo de treino (tempo/compassos) - ok
-------- para saber qual parâmetro usar, faça o "on_click o u On_change" chamar um  método e nesse método dê um print em "e". Geralmente os parâmentros ficam em "e.data"---------------
- Botâo para importar/exportar lista de tarefas - ok
- criar um método "Slider igual a Vol (para faciliatr a visualização) - quase
- criar bota~so com swith - ok
- add voice command
- colocar um ranger no botão - ok
- criar botões dos modos treinamento, cmpassos
- criar abas: lento, médio, rápido, speedburst em filtros
- Exibir o tempo de descanso - ok
- exibir o valor do volume - ok
 - criar módulos separdas para layout, ações dos botoes, ...-ok
- criar um atributo em metronomo para que quando ele esteja ativado, todoapp exibir o respiro -ok
- ativar o "salvar" na tela lento - ok
- criar telas "ativos" e "Concluídos - ok
- recriar a janela metronomo normal (desta vez, usando parâmentro em todoapp) -ok
- criar um atributo em crontole metronomo para receber as 'atualizações de tela' - ok
- fzer o metrônomo tocar - ok (o problema estava na thread - daemon = True)
- adicionar um seletor de cores na tela metronomo normal - ok
- ativar função salvar para "lento" - ok
- ativar as teclas apenas em "metronomo normal' - ok
- ativar a funcção deletar tarefas na tela "Lento - ok
- ativar a opção "concluido" para as tarefas da tela lwnto - ok
- colocar o scroll na tela lento - ok
- Display para os bpm - ok
- criar um tela para o metrônomo normal - ok
- Botão Play para o Metrônomo normal - ok
- Botão Pause para o Metrônomo normal - ok
- Botão Stop para o Metrônomo normal - ok
- Botão Salvar  - ok
- Botões aumendar e diminuir bpm (+-1,+-5,+-10)
- Botão de Volume - ok
- Botão tap -ok
- ativar teclas do teclado - ok
'''
