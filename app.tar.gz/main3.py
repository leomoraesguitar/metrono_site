from threading import Thread
import webbrowser
from arquivo_metronomo import Escrever_json, Ler_json,  ListExportTarefas
from layout2 import Layout, inicializar, arquiv, config, sg
from controlador_metronomo import Metronomo_Control,  sleep
# from controlemetronomo import*
# from os import system
import logging


# from controlemetronomo import*
__docformat__ = "restructuredtext"


def Rodar(arquiv=arquiv, inicializar=inicializar):
    global qtd_tarefas
    lt = Layout()
    '''
    qtd_tarefas é a quantidade de tarefas que a janela vai exibir ao inicar       
    '''
    qtd_tarefas = int(lt.DefaultValores('qtd_tarefas')) if lt.DefaultValores(
        'qtd_tarefas') != '' else 2
    logging.debug(f'qtd_tarefas = {qtd_tarefas}')
    '''janeja do programa'''
    # window = FazerJanela(arquiv, inicializar)
    janela_prog = lt.FazerJanela(arquiv, inicializar)
    
    janela_config = None
    # m = Metronomo_leo(window)
    # m.IniciaTeclas(window)
    window = janela_prog

    def Exibir_teclas(evento, eb=False):
        try:
            if len(evento) == 1:
                # ev = ord(event)
                if eb:
                    # print('%s - %s' % (event, ord(event)))
                    print('%s' % (ord(evento)))
                return ord(evento)
            else:
                if eb:
                    print(f'{evento} - tipo {type(evento)}')
                return evento
        except:
            return None

    def Win_Jan(*nome):
        try:
            return window == janela_prog and event in nome
        except:
            return window == janela_prog and event == nome

    def Win_Jan2(*nome):
        try:
            return window == janela_prog and Exibir_teclas(event) in nome
        except:
            return window == janela_prog and Exibir_teclas(event) == nome

    def Win_Config(*nome):
        try:
            return window == janela_config and event in nome
        except:
            return window == janela_config and event == nome

    def Win_Config2(nome):
        return window == janela_config and event in nome

    logging.error(f'window = FazerJanela(arquiv, inicializar)')

    '''Cria uma instância da subclasse Controle_metronomo'''
    m = Metronomo_Control(window)
    # m.IniciaTeclas(window)
    # m.nome_planilha = lt.DefaultValores('nome_planilha')
    logging.debug(f'nome_planilha = {m.nome_planilha}')

    def Add_tarefa(m, i, values):
        logging.debug('Add_tarefa')
        m.setOn(False)
        try:
            print(f"values[-DR-{i}-] = {values[f'-DR-{i}-']}")
            if values[f'-DR-{i}-'] != None:
                window[('-ROW-', i)].update(visible=True)
        except:
            m.window.extend_layout(window['-COL-'], lt.Tarefa(i))
        m.window.visibility_changed()
        m.window['-COL-'].contents_changed()
        lista_tarefas_play = [f'-play-{ll}' for ll in range(i)]
        lista_tarefas_pause = [f'-pause-{ll}' for ll in range(i)]
        i += 1
        logging.info(
            f'lista_tarefas_play = {lista_tarefas_play}, lista_tarefas_pause = {lista_tarefas_pause}')
        return lista_tarefas_play, lista_tarefas_pause, i

    def LerValues(values, tarefas=False):
        def Ler(valor, tipo='', ret=None):
            try:
                match tipo:
                    case 'int':
                        return int(values[valor])
                    case 'float':
                        return float(values[valor])
                    case '':
                        return values[valor]
            except:
                return ret

        m.pomodoro_habilitado = Ler('-habilitar_pomodoro-')
        m.treino_habilitado = Ler('treino_habilitado')
        print(f'm.treino_habilitado = {m.treino_habilitado}')
        m.continuar = Ler('-continuar-')
        m.setVolume(Ler('-volume-', 'float'))

        if not tarefas:
            m.setBpm(Ler('-bpm-', 'float', 100))
            m.inverter = Ler('-inverter-')
            m.meta = Ler('-meta-', 'int', -100)
            m.inicio = Ler('-inicio-', 'int', 100)
            m.passo = Ler('-passo-', 'float', -1)

            m.passo_fim = Ler('-passo_fim-', 'float', 0)
            m.tempo = Ler('-tempo-')
            if m.tempo:
                m.t_total = 60*Ler('-Intervalo-', 'float', 1)
            else:
                m.intervalo = Ler('-Intervalo-', 'float', 1)
                m.t_total = None

            m.qtd_compassos = Ler('-qtd_compassos-', 'int', 1)
            m.tipo_compasso = Ler('-tipo_compasso-')

            if Ler('-tipo_compasso-') == '2/4':
                m.tipo_compasso = 2
            elif Ler('-tipo_compasso-') == '3/4':
                m.tipo_compasso = 3
            elif Ler('-tipo_compasso-') == '4/4':
                m.tipo_compasso = 4
            else:
                m.tipo_compasso = 4

        else:
            m.n_treino = m.event[6:]
            m.nome_treino = Ler(f'-TR-{m.n_treino}-', '', 'sem nome')
            m.nome_planilha = Ler('nome_planilha')
            m.t_total = 60*Ler(f'-DR-{m.n_treino}-', 'float', 1)  # duração
            # print(f'self.tempo_restante = {m.t_total}')
            m.meta = Ler(f'-BPMF-{m.n_treino}-', 'float', -100)
            m.inicio = Ler(f'-BPMI-{m.n_treino}-', 'float', 80)
            m.passo = Ler(f'-PASSO-{m.n_treino}-', 'float', -1)

        if m.meta == -100 or m.passo == -1:
            m.progressivo = False
            if m.t_total == None:
                m.t_total = m.intervalo
        else:
            m.progressivo = True

    p = True
    i = qtd_tarefas
    lista_tarefas_play = []
    lista_tarefas_pause = []
    bpm = 100
    try:

        for it in range(qtd_tarefas):
            lista_tarefas_play.append(f'-play-{it}')
            lista_tarefas_pause.append(f'-pause-{it}')
            # = ['-play-0', '-play-1', '-play-2'], ['-pause-0', '-pause-1', '-pause-2']
            logging.info(
                f'lista_tarefas_play = {lista_tarefas_play},lista_tarefas_pause = {lista_tarefas_pause} ')

    except:
        print(f'Deu erro nas inicializações das listas "lista_tarefas_play" e "lista_tarefas_pause" ')
        logging.error(
            f'Deu erro nas inicializações das listas "lista_tarefas_play" e "lista_tarefas_pause" ')
    lista = [0, 1, 2, 3, 4, '4564654',
             'qtd_tarefas', '-tab-', '-tempo/compasso-']

    lista_export = ['-bpm-', '-arq-', 'nome_planilha', 'treino_habilitado', '-meta-', '-inicio-', '-passo-', '-passo_fim-', '-Intervalo-',
                    '-inverter-', '-tempo-', '-tipo_compasso-', '-qtd_compassos-', '-continuar-', '-habilitar_pomodoro-', '-Pomodoro-', '-descanso-']

    lista_export_tarefas = ListExportTarefas(qtd_tarefas)
    logging.info(f'lista_export_tarefas = {lista_export_tarefas}')

    def Limpar_tarefas(window, qtd_tarefas):
        try:
            lista_tarefas_apagar = ListExportTarefas(qtd_tarefas)
        except:
            pass
        for hh in lista_tarefas_apagar:
            try:
                window[hh].update('')
            except:
                pass

    def Remover_tarefas(window, qtd_tarefas):
        try:
            for rt in range(1, qtd_tarefas):
                try:
                    window[('-ROW-', rt)].update(visible=False)
                except:
                    pass
        except:
            logging.exception(
                f'erro na atualização dos campos ')

    def Atualizar_campos(window, dicnovo):
        for inp in dicnovo.keys():
            if inp not in lista:
                try:
                    window.Element(inp).update(dicnovo[inp])
                except:
                    pass

    def Restaurar_cores(window):
        window['Pause'].update(button_color=lt.cor_de_fundo_botoes)
        for i3 in lista_tarefas_play:
            window[i3].update(button_color='#5f6766')
        for i3 in lista_tarefas_pause:
            window[i3].update(button_color='#5f6766')

    while True:
        # event, values = window.read()
        window, event, values = sg.read_all_windows()
        # window.TKroot.tk.call('tk', 'scaling', 3)
        try:
            bpm = int(values['-bpm-'])
            # Exibir_teclas(event, True)
            # print(values)
            # print(event)

        except:
            pass

        # if event in [sg.WIN_CLOSED, 'Sair']:
        if Win_Jan(*[sg.WIN_CLOSED, 'Sair']):
            # try:
            m.setOn(False)
            m.treinando = True
            # m.RemoverTeclasIniciadas()
            break
            # except:
            #     pass
        # elif Win_Jan(*['maximizar']):
        #     if not window.maximized:
        #         window.maximize()
        #     else:
        #        window.normal()
        # elif Win_Jan(*['minimizar']):
        #     window.Minimize()

        elif Win_Jan('OK') or Win_Jan2(32):
            # try:
            # m.window = window
            # m = Stop(m, values)
            # m = Stop(m, values)
            m.Stop(values)
            m = None
            m = Metronomo_Control(window)
            LerValues(values)

            m.Play(values)

            Restaurar_cores(window)
            if m.treino_habilitado:
                def sl(m):
                    sleep(m.t_total+5)
                    m.Stop(values)
                    # m = Stop(m, values)
                if not values['-continuar-']:
                    Thread(target=sl, args=[(m)], daemon=True).start()
            # except:
            #     pass
        elif Win_Jan('Pause') or Win_Jan2(112):
            try:
                m.Pause()
                if p:
                    window['Pause'].update(button_color='red')
                    p = not p
                else:
                    window['Pause'].update(button_color='#5f6766')
                    p = not p
            except:
                pass
        elif Win_Jan('+1') or Win_Jan2(55):

            try:

                m.ModificarBPM(bpm+1)
            except:
                pass
        elif Win_Jan('-1') or Win_Jan2(49):
            try:
                m.ModificarBPM(bpm-1)
            except:
                pass
        elif Win_Jan(*['+5']) or Win_Jan2(56):

            try:

                m.ModificarBPM(bpm+5)
            except:
                pass
        elif Win_Jan(*['-5']) or Win_Jan2(50):

            try:

                m.ModificarBPM(bpm-5)
            except:
                pass
        elif Win_Jan(*['+10']) or Win_Jan2(57):

            try:

                m.ModificarBPM(bpm+10)
            except:
                pass
        elif Win_Jan(*['-10']) or Win_Jan2(51):

            try:

                m.ModificarBPM(bpm-10)
            except:
                pass
        elif Win_Jan(*['-bpm-']):
            try:
                m.ModificarBPM(int(values['-bpm-']))
            except:
                pass
        elif Win_Jan(*['-volume-']):

            try:

                m.setVolume(float(values['-volume-']))
            except:
                pass
        elif Win_Jan(*['Add Tarefa']):
            # try:
            # qtd_tarefas += 1

            # ad1, ad2, i = Add_tarefa(window, m, i)
            # lista_tarefas_play.append(ad1)
            # lista_tarefas_pause.append(ad2)
            lista_tarefas_play, lista_tarefas_pause, qtd_tarefas = Add_tarefa(
                m, qtd_tarefas, values)
            lista_export_tarefas = ListExportTarefas(qtd_tarefas)

            # print(lista_tarefas_play, lista_tarefas_pause)
            # except:
            #     pass
        elif Win_Jan('Stop') or Win_Jan2(13):
            try:
                # m.window = window
                m.Stop(values)
                m = None
                m = Metronomo_Control(window)
                Restaurar_cores(window)
                # window['Pause'].update(button_color='#414141')
                # for i3 in lista_tarefas_play:
                #     window[i3].update(button_color='#5f6766')
                # for i3 in lista_tarefas_pause:
                #     window[i3].update(button_color='#5f6766')


            except:
                pass
        elif Win_Jan(*lista_tarefas_play):
            # try:
            # print(event)
            m.Stop(values)
            m.Stop(values)
            m = None
            m = Metronomo_Control(window)
            for i3, i33 in zip(lista_tarefas_play, lista_tarefas_pause):
                window[i3].update(button_color='#5f6766')
                window[i33].update(button_color='#5f6766')

            window[event].update(button_color='red')
            m.event = event
            LerValues(values, True)
            m.tipo_de_treino = 'tarefas'
            m.Play_tarefas(values)
            m.t_total = 60*float(values[f'-DR-{event[6:]}-'])  # duração

            def sl(m):
                sleep(m.t_total+5)
                m.Stop(values)
                # m = Stop(m, values)
                Restaurar_cores(window)
                # window['Pause'].update(button_color='#414141')
                # for i3 in lista_tarefas_play:
                #     window[i3].update(button_color='#5f6766')
                # for i3 in lista_tarefas_pause:
                #     window[i3].update(button_color='#5f6766')
            if not values['-continuar-'] and not m.treinando:
                Thread(target=sl, args=[(m)], daemon=True).start()

            # m = Stop(m, values)

            # window[event].update(button_color='#5f6766')
            # except:
            #     pass
        elif Win_Jan(*lista_tarefas_pause):
            try:
                m.Pause()
                for i3, i33 in zip(lista_tarefas_play, lista_tarefas_pause):
                    window[i3].update(button_color='#5f6766')
                    window[i33].update(button_color='#5f6766')
                window[event].update(button_color='red')
            except:
                pass
        elif Win_Jan(*['Salvar']) or Win_Jan2('s:83'):
            # try:
            arquiv = Ler_json(config)
            lista_export_tarefas = ListExportTarefas(qtd_tarefas)

            # print(f'values = {values}')
            # print(f'qtd_tarefas = {qtd_tarefas}')
            # print(f'lista_export_tarefas = {lista_export_tarefas}')
            dic_export = {i: values[i]
                          for i in lista_export+lista_export_tarefas}
            arquiv['valores'] = dic_export
            arquiv[values['-arq-']] = dic_export
            arquiv['valores']['qtd_tarefas'] = qtd_tarefas
            arquiv[values['-arq-']]['qtd_tarefas'] = qtd_tarefas
            Escrever_json(arquiv, config)
            window['-tempo_de_treino-'].update(
                'Configurações salvas com sucesso!')

            print('Configurações salvas com sucesso!')
            # except:
            #     pass
        elif Win_Jan(*['Ocultar BPM']):
            try:
                window['-bpm-'].update(button_background_color='#062322')
                # print('aqui')
            except:
                pass
        elif Win_Jan(*['-arq-']):
            # try:
            arquiv = Ler_json(config)
            # arquiv['valores'] = arquiv[values['-arq-']]
            # Escrever_json(arquiv, config)
            # lt = None
            # window.close()
            # Rodar()

            # try:

            # for chave, valor in arquiv[values['-arq-']].items():
            print('qtd_tarefas = ', qtd_tarefas)
            print('arquiv[values[-arq-] = ',
                  arquiv[values['-arq-']]['qtd_tarefas'])
            if qtd_tarefas == arquiv[values['-arq-']]['qtd_tarefas']:
                print('iguais')
                Atualizar_campos(window, arquiv[values['-arq-']])

            elif qtd_tarefas > arquiv[values['-arq-']]['qtd_tarefas']:
                print('do maior pro menor')
                qtd_tarefas_para_excluir = qtd_tarefas - \
                    arquiv[values['-arq-']]['qtd_tarefas']
                for qt in range(qtd_tarefas_para_excluir):
                    qtd_tarefas -= 1
                    print('tarefa ', qtd_tarefas)
                    window[('-ROW-', qtd_tarefas)].update(visible=False)
                    window[(f'-TR-{qtd_tarefas}-')].update('')

                Atualizar_campos(window, arquiv[values['-arq-']])

            elif qtd_tarefas < arquiv[values['-arq-']]['qtd_tarefas']:
                print('do menor pro maior')
                qtd_tarefas_para_incluir = arquiv[values['-arq-']
                                                  ]['qtd_tarefas'] - qtd_tarefas
                for qt in range(qtd_tarefas_para_incluir):
                    lista_tarefas_play, lista_tarefas_pause, qtd_tarefas = Add_tarefa(
                        m, qtd_tarefas, values)
                    lista_export_tarefas = ListExportTarefas(qtd_tarefas)
                print(f'lista_export_tarefas = {lista_export_tarefas}')
                # print(arquiv[values['-arq-']])
                Atualizar_campos(window, arquiv[values['-arq-']])

            # Limpar_tarefas(window, qtd_tarefas)
            # Remover_tarefas(window, qtd_tarefas)

            # try:
            #     lista_tarefas_escrever = ListExportTarefas(arquiv['valores']['qtd_tarefas'])
            #     print(lista_tarefas_escrever)
            # except:
            #     pass

            # for l1 in range(2, qtd_tarefas):
            # i = arquiv['valores']['qtd_tarefas']
            # i = 1

            # print('i=', i)

            # print(lista_tarefas_play)
            # Limpar_tarefas(window, arquiv['valores']['qtd_tarefas'])

            # print('i=', i)
            # Atualizar_campos(window, arquiv['valores'])

            # print('\n\n\n')
            # print(values)

            # except:
            #     sg.popup("Deu erro!")
            # except:
            #     pass
        elif Win_Jan(*['manual']):

            try:

                url = 'https://raw.githubusercontent.com/leomoraesguitar/Metronomo/main/leia-me.txt'
                webbrowser.open(url)
            except:
                pass
        elif Win_Jan(*['Baixar audio "1.Wav"']):
            try:

                url = 'https://github.com/leomoraesguitar/Metronomo/raw/main/1.wav'
                webbrowser.open(url)
            except:
                pass
        elif Win_Jan(*['Baixar audio "2.Wav"']):
            try:
                url = 'https://github.com/leomoraesguitar/Metronomo/raw/main/2.wav'
                webbrowser.open(url)
            except:
                pass
        elif Win_Jan(*['Obter "client_secret.json"']):
            try:
                url = 'https://developers.google.com/docs/api/quickstart/python?hl=pt-br'
                webbrowser.open(url)
            except:
                pass
        elif Win_Jan(*['Ciar Planilha Google']):
            try:
                url = 'https://github.com/leomoraesguitar/Metronomo/blob/main/Como%20Criar%20Planilha%20Metronomo.pdf'
                webbrowser.open(url)
            except:
                pass
        elif Win_Jan(*['Exportar']):
            logging.debug('Exportar')
            lista_export_tarefas = ListExportTarefas(qtd_tarefas)
            nome_arquivo_exportar = sg.popup_get_file('Digite o nome do arquivo a ser exportado',
                                                      no_window=True,
                                                      save_as=True,
                                                      file_types=(
                                                          (".txt", ". txt"),)
                                                      )
            logging.info(
                f'nome do arquivo a ser exportado: {nome_arquivo_exportar}')
            if nome_arquivo_exportar[-4:] != '.txt':
                nome_arquivo_exportar += '.txt'
            if nome_arquivo_exportar != '':
                try:
                    with open(nome_arquivo_exportar, 'w', encoding='utf-8') as arq:
                        logging.debug('arquivo aberto com sucesso')
                        # arq.write(f'{qtd_tarefas},')
                        # for h in lista_export[:-1]:
                        #     arq.write(f'{values[h]},')
                        # arq.write(f'{values[lista_export[-1]]}\n')
                        arq.write(f'Nome, Duração, BPM_ini, BPM_fim, Passo\n')

                        cont = 0
                        try:
                            for h in lista_export_tarefas:
                                if cont < 4:
                                    arq.write(f'{values[h]},')
                                    cont += 1
                                else:
                                    arq.write(f'{values[h]}\n')
                                    cont = 0
                        except:
                            logging.exception(
                                'erro na escrita do arquivo a ser exportado')

                    logging.debug('Arquivo exportado com sucesso!')
                    # print('Arquivo exportado com sucesso!')
                except:
                    logging.exception(
                        f'erro na abertura do arquivo para exportar')
            else:
                logging.info('Selecione um arquivo válido')
        elif Win_Jan(*['Importar']):
            logging.debug('Importar')
            nome_arquivo_importado = sg.popup_get_file('Digite o nome do arquivo a ser exportado',
                                                       no_window=True,
                                                       save_as=False,
                                                       file_types=(
                                                           (".txt", ". txt"),),
                                                       default_extension='.txt'
                                                       )
            logging.info(
                f'nome do arquivo a ser inportado: {nome_arquivo_importado}')

            if nome_arquivo_importado not in [None, '']:
                try:
                    with open(nome_arquivo_importado, 'r', encoding='utf-8') as arq:
                        a = arq.read()
                    logging.debug(
                        'arquivo importado está sendo lido e extraiddas suas informações')
                    a1 = a.split('\n')
                    # remover as tarefas anteriores:
                    # print(qtd_tarefas)
                    try:
                        for rt in range(qtd_tarefas):
                            if rt > 0:
                                window[('-ROW-', rt)].update(visible=False)

                            window[(f'-TR-{rt}-')].update('')

                    except:
                        logging.exception(
                            f'erro na atualização dos campos \nda tela ao importar o arquivo {nome_arquivo_importado}')
                    # lista_export_tarefas = ListExportTarefas(1)
                    # logging.debug(
                    #     f'lista_export_tarefas = {lista_export_tarefas}')
                    # try:
                    #     for hh in lista_export_tarefas:
                    #         window[hh].update('')
                        # arquiv = Ler_json(config)
                        # lista_para_deletar = [f"-TR-{rt}-",f"-DR-{rt}-",f"-BPMI-{rt}-",f"-BPMF-{rt}-",f"-PASSO-{rt}-", ]
                        # print(lista_para_deletar)
                        # for d in lista_para_deletar:
                        #     try:
                        #         del arquiv['valores'][d]
                        #     except:
                        #         print('chave inexistente')
                        # qtd_tarefas -=1
                        # arquiv['valores']['qtd_tarefas'] = qtd_tarefas
                        # Escrever_json(arquiv, config)
                    # except:
                    #     logging.exception(
                    #         'erro ao limpar os campos do programa')
                    qtd_tarefas = 0
                    valores_importados = []
                    for i3 in a1[1:]:
                        if len(i3) > 3:
                            qtd_tarefas += 1
                            valores_importados.extend(i3.split(','))
                    # print('valores_importados = ',valores_importados )
                    # print('qtd_tarefas = ', qtd_tarefas)
                    # for chave in list(values.keys())[18:]:
                    #     print(chave, ' = ', values[chave])
                    lista_export_tarefas = ListExportTarefas(qtd_tarefas)
                    # print(lista_export_tarefas)
                    # # a2 = a1[1:]#.split(',')
                    # # qtd_tarefas = a2[0]
                    # # for kk,hh in enumerate(lista_export[:14]):
                    # #     window[hh].update(a2[kk+1])
                    # #     print(a2[kk+1])

                    logging.debug(f'a1 = {a1}')
                    logging.debug(f'qtd_tarefas = {qtd_tarefas}')
                    logging.debug(f'valores_importados = {valores_importados}')
                    logging.debug(f'lista_export = {lista_export_tarefas}')

                    for l1 in range(1, qtd_tarefas):
                        lista_tarefas_play, lista_tarefas_pause, i = Add_tarefa(
                            m, l1, values)

                    for kk, hh in zip(valores_importados, lista_export_tarefas):
                        try:
                            window[hh].update(kk)
                        except:
                            logging.exception(
                                'campo não encontrado na atualização com campos ao importar arquivo')

                except:
                    logging.exception('Erro ao abrir o arquivo de importação')

            else:
                print('Selecione um arquivo válido')
        elif window == janela_prog and event[0] == '-DEL-':
            # print('tarefa ', event[1])
            window[('-ROW-', event[1])].update(visible=False)
            window[(f'-TR-{event[1]}-')].update('')
            qtd_tarefas -= 1
        elif Win_Jan(*['-tap-']) or Win_Jan2(53):
            try:
                m.Tap
            except:
                pass
        elif Win_Jan(*['Selecionar Planilha']):
            nome_plan = sg.popup_get_text(
                'Digite o ID da planilha do google \n(ex. 1-vU6ONr6gsdfpOI-inXlzpiwcPqdhdgBgXnPXvjkPjk)', no_titlebar=False)
            if nome_plan != '':
                values['nome_planilha'] = nome_plan
                arquiv = Ler_json(config)
                arquiv[values['-arq-']] = values
                arquiv[values['-arq-']]['qtd_tarefas'] = qtd_tarefas
                arquiv['valores'] = values
                arquiv['valores']['qtd_tarefas'] = qtd_tarefas
                # arquiv['valores']['nome_planilha'] = nome_plan
                Escrever_json(arquiv, config)
                m.nome_planilha = nome_plan
                # texto = f'11-10-2023-14:56:53 .-. Estágio 3 .-. 5min .-. BPM(140 a 150) .-. passo: 0.1 .-. intervalo: 3.0s'
                # m.EscrevePlanilha(texto)
        elif Win_Config2(lt.tamanhos):
            dic = Ler_json('cores_e_tamanhos_config.json')
            # dic['Padrao']['tamanhos'][event] = values[event]
            # dic[values['-temas-']] = dic['Padrao']
            if values['-temas-'] in dic.keys():
                novo_tema = f'{values["-temas-"]}_mod'
            else:
                novo_tema = values['-temas-']

            dic[novo_tema] = dic['Padrao']

            try:
                dic[novo_tema]['tamanhos'][event] = values[event]
            except:
                dic[novo_tema] = {'tamanhos': {event: None}}
                dic[novo_tema]['tamanhos'][event] = values[event]

            Escrever_json(dic, 'cores_e_tamanhos_config.json')

        elif Win_Config2(lt.cores):
            cor = lt.Get_cor(window, event)
            if cor != None:
                dic = Ler_json('cores_e_tamanhos_config.json')
                # dic['Padrao']['cores'][event] = cor
                # dic[values['-temas-']] = dic['Padrao']

                if values['-temas-'] in dic.keys():
                    novo_tema = f'{values["-temas-"]}_mod'
                else:
                    novo_tema = values['-temas-']

                dic[novo_tema] = dic['Padrao']
                try:
                    dic[values['-temas-']]['cores'][event] = cor
                except:
                    dic[novo_tema] = {'cores': {event: None}}
                    dic[novo_tema]['cores'][event] = cor
                Escrever_json(dic, 'cores_e_tamanhos_config.json')
        elif Win_Jan(*['Aparência']):
            try:
                janela_config = lt.Janela_config()
                janela_prog.hide()
            except:
                sg.popup('Deu erro')
        elif Win_Config(*[sg.WIN_CLOSED]):
            janela_config.hide()
            janela_prog.un_hide()
        elif Win_Config(*['Salvar Cores']):
            # janela_config.hide()
            # janela_prog.un_hide()
            dic = Ler_json('cores_e_tamanhos_config.json')
            dic['Padrao'] = dic[values['-temas-']]
            Escrever_json(dic, 'cores_e_tamanhos_config.json')
            # zoom = values['-zoom-']



            lt = None
            # lt = Layout()
            window.close()
            Rodar()


            # janela_prog = lt.FazerJanela(arquiv, inicializar)
            # window =   janela_prog
        elif Win_Config(*['-temas-']):
            dic = Ler_json('cores_e_tamanhos_config.json')
            novo_tema = values['-temas-']
            try:
                for key in dic[novo_tema]['cores'].keys():
                    cor = dic[novo_tema]['cores'][key]
                    window[key].update(button_color=cor)
            except:
                pass
            try:
                for key in dic[novo_tema]['tamanhos'].keys():
                    tamanho = dic[novo_tema]['tamanhos'][key]
                    window[key].update(tamanho)
            except:
                pass

        # for chave in list(values.keys())[18:]:
        #     print(chave, ' = ', values[chave])
    window.close()



if __name__ == '__main__':
    filename = 'logs_metronomo.log'
    logging.basicConfig(level=logging.DEBUG,
                        filename=filename,
                        format="%(asctime)s - %(levelname)s - %(message)s",
                        encoding='utf-8',
                        filemode='w'

                        )
    Rodar()
