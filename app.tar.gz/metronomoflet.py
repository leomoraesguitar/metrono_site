from controlador_metronomo import *

import flet as ft
from flet import (
    Column,
    Container,
    ElevatedButton,
    Dropdown,
    Page,
    Slider,
    Checkbox,
    Row,
    Text,
    Stack,
    TextField,
    UserControl,
    border_radius,
    colors,

)

    

m = Metronomo_Control(None)
class MetronomoApp(UserControl):
    def build(self):
        self.result = Text(value="0", color=colors.WHITE, size=20)

        # application's root control (i.e. "view") containing all other controls
        def Recipiente(conteudo, cor = colors.BLACK):
            return  Container(
                        bgcolor = cor,
                        # border = border.all(2, colors.PINK_600),
                        border_radius=border_radius.all(5),

                        content = conteudo

                    )
        def Entrada(nome = ''):
            dot = 40 - len(nome)
            dot = '.'*dot
            nome = f'{nome}{dot}'
            # return  Row(spacing = 0,width = 30,controls = [Text(nome),TextField(label="", border_width = 2,width = 50, height= 40)])
            return TextField(label="", border_width = 2,width = 50, height= 40)
        def Slider_treinamento(tipo = 1):
            if tipo == 1:
                return Slider(min=0,  max=1000, divisions=10,  label="{value}%")
            else:
                return Slider(min=0,  max=30, divisions=0.,  label="{value}%")

        def But_acao(texto):
            return ElevatedButton(
                            text=texto,
                            bgcolor=colors.GREY_50,
                            color=colors.BLACK,
                            expand=1,
                            on_click=self.button_clicked,
                            data=texto,
                        )        
        def But_bpm(texto):
            return ElevatedButton(
                        text=texto,
                        bgcolor=colors.RED_400,
                        color=colors.WHITE,
                        expand=1,
                        on_click=self.button_clicked,
                        data=texto
                    )

        self.bpm =  Dropdown(
                label="BMP",
                on_change=self.dropdown_changed,
                value = 100,
                hint_text="Escolçha o BPM",
                options=[ft.dropdown.Option(i) for i in range(1,1000)],
                autofocus=True,
                text_size = 20,
                alignment = ft.Alignment(0, 0),
                # suffix_text = ' BPM'
                width = 110,
                data= "BMP"
                                )
        layout_botoes_bpm = Row(alignment = 'center',
                    controls=[
                                But_bpm('-1'),
                                But_bpm('-5'),
                                But_bpm('-10'),
                                self.bpm,
                                But_bpm('+1'),
                                But_bpm('+5'),
                                But_bpm('+10')                                                                                                 
                            ]
                )
        self.v1 = Slider(
                                min=0, 
                                max=100, 
                                divisions=100, 
                                label="{value}%",
                                inactive_color = 'red',
                                # thumb_color='gray'
                                data = "-vol-{value}"
                                )
        layout_volume_e_treino = Row( alignment = 'center',
                        controls= [ 
                            Text('Vol.'),
                            self.v1,
                            Checkbox(label = 'Inverter'),
                            Checkbox(label = 'Treino_habilitado'),
                            ElevatedButton('Tap')
                        ]
           
                    )
        layout_treinamento = Row(spacing = 10,alignment = 'left',                
                controls= [
                   
                    
                    # ft.VerticalDivider(width=300,thickness = 5, color = 'white'),
                    Column(controls= [
                                        Text('Meta(bpm)'),
                                        Text('Início(bpm)'),
                                        Text('Início(bpm)'),
                                        Text('Passo(bpm)'),
                                        Text('Passo Fim(bpm)')
                                    ],spacing  = 30                               
                    ),
                    Column(controls = [
                                    Entrada(),  
                                    Entrada(),  
                                    Entrada(),  
                                    Entrada(),  
                                    Entrada()  
                                    ]

                        )

            
                ]
            )
        layout_botoes_acao = Row(
                    alignment = 'center',
                    controls=[
                        But_acao('play'),
                        But_acao('pause'),
                        But_acao('stop'),
                        But_acao('salvar'),

                    ]
                )
        layout_pomodoro = Row(alignment = 'center',
                controls= [
                            Checkbox(label = 'Continuar'),
                            ft.VerticalDivider(),
                            Checkbox(label = 'Pomodoro'),
                            Entrada(),
                            ft.VerticalDivider(),
                            Checkbox(label = 'Descanso'),
                            Entrada(),

                        ]

                )
        return Container(
            # width=900,
            bgcolor=colors.BLACK87,
            border_radius=border_radius.all(20),
            padding=20,
            content=Column(
                controls=[
                    Recipiente(layout_botoes_bpm) , 
                    ft.Divider(),
                    Recipiente(layout_volume_e_treino) , 
                    ft.Divider(),
                    Recipiente(layout_treinamento) , 
                    ft.Divider(),
                    Recipiente(layout_pomodoro) , 
                    ft.Divider(),
                    Recipiente(layout_botoes_acao) , 
                    ft.Divider()
                                       
                    
                ],
            ),
        )

    def Stop(self):
        m.bpm_atual = self.bpm.value
        m.Stop()


    def dropdown_changed(self,e):
        # print(f"Dropdown changed to {self.bpm.value}")
        m.bpm_atual = self.bpm.value

    def button_clicked(self, e):
        data = e.control.data
        
        if data   == 'play':
            print(f'Apertou {data}')
            self.Stop()
            m = None
            m = Metronomo_Control(None)
            # self.LerValues()
            # m.Play()
            print(self.v1.data)
            print(self.v1.label)
            print(self.v1.value)
        elif data   == 'pause':
            print(f'Apertou {data}')
        elif data   == 'stop':
            print(f'Apertou {data}')

        elif data   == 'salvar':
            print(f'Apertou {data}')  
        elif data   == '-1':
            print(f'Apertou {data}')   
        elif data   == '-5':
            print(f'Apertou {data}') 
        elif data   == '-10':
            print(f'Apertou {data}') 
        elif data   == '+1':
            print(f'Apertou {data}') 
        elif data   == '+5':
            print(f'Apertou {data}') 
        elif data   == '+10':
            print(f'Apertou {data}') 
            
                                                                                                                    
     

def main(page: Page):
    page.title = "Metrônomo"
    page.window_width = 800
    # page.window_height = 400
    page.window_center()

    # create application instance
    
    metro = MetronomoApp()

    # add application's root control to the page
    page.add(metro)

# try:
#     ft.app(target=main)
# except KeyboardInterrupt:
#     print("interoompido")
ft.app(target=main, view=ft.WEB_BROWSER)
