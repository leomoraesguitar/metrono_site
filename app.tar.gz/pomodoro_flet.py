
from flet import*
from time import sleep, time
from winsound import MessageBeep, MB_ICONHAND


class Pomodoro(UserControl):
    def __init__(self,
    tempo_pomodoro_set = 0.05, 
    tempo_descanso_set = 0.5,
    parar_pomodoro = False,
    pause_pomodoro = False,
    ):
        super().__init__()
        self.parar_pomodoro = parar_pomodoro
        self.pause_pomodoro = pause_pomodoro
        self.tempo_pomodoro_set = tempo_pomodoro_set
        self.tempo_descanso_set = tempo_descanso_set
        self.quado_saida = Row()
        self.saida_respiro = Column(visible=False)


    @property
    def Parar(self):
        return self.parar_pomodoro
    
    @Parar.setter
    def Parar(self, valor: bool):
        self.parar_pomodoro = valor
        self.quado_saida = Row()
        self.saida_respiro = Column(visible=False)
        self.update()
 

    @property
    def Pause(self):
        return self.pause_pomodoro
    
    @Pause.setter
    def Pause(self, valor: bool):
        self.pause_pomodoro = valor
        self.update()





    def did_mount(self):
        self.Pomodoro()

    def build(self):
        return  Row([self.quado_saida, self.saida_respiro])  
    
    def Pomodoro(self):
        texto = 'Pomodoro inciado...'
        self.quado_saida.visible = True        
        self.quado_saida.controls = [Text(texto)]
        self.update()

        while not self.parar_pomodoro:
            self.quado_saida.visible = True
            
            segundos = self.tempo_pomodoro_set*60
            while segundos >= 0:
                h, mins = divmod(segundos, 60*60)
                mins, secs = divmod(mins, 60)
                h, mins, secs = int(h), int(mins), int(secs)
                if texto != '':
                    contador = "{:s} {:02d}:{:02d}:{:02d}".format(texto,h, mins, secs)
                else:
                    contador = "{:02d}:{:02d}:{:02d}".format(h, mins, secs)

                self.quado_saida.controls = [Text(contador, color = 'yellow', size = 22)]
                sleep(1)
                self.update()
                segundos -= 1
                while self.pause_pomodoro:
                    sleep(0.3)
                if self.parar_pomodoro:
                    break

            if self.parar_pomodoro:
                self.quado_saida.visible = False
                break

            MessageBeep(MB_ICONHAND)

            self.Respiro()
            
            if self.parar_pomodoro:
                break
            MessageBeep(MB_ICONHAND)

            if self.parar_pomodoro:
                break
            texto = 'Volte a treinor por '

        self.quado_saida.visible = False

    def Respiro(self):
        self.pause_pomodoro = True
        # estado_saida_treinamento = self.saida_treinamento.visible
        # estado_saida_quado = self.quado_saida.visible
        # self.saida_treinamento.visible = False
        self.quado_saida.visible = False
        self.saida_respiro.visible = True
        descan = int(self.tempo_descanso_set*60/19.4)
        # print(descan)
        # self.pause_pomodoro = True

        width_max = 740
        respiro = Container(content=Text(),bgcolor= colors.YELLOW,width = 0, border_radius=40, height=40)
        def Inspire(d):
            # self.quado_saida.content = Text(f'INSPIRE ({d})')
            s = Row([Text(f'>>>    INSPIRE ({d})    <<<', color = colors.WHITE, size = 25, weight = 'bold')], alignment='center', width=750)
            # s.saida_tempo_de_treino.visible = True
            # self.saida.texto1_size = 50
            # self.saida.texto1_color= colors.YELLOW
            self.saida_respiro.controls = [Stack([respiro, s])]
            # self.quado_saida.content.alignment= MainAxisAlignment.CENTER

        def Expire(d):
            s = Row([Text(f'<<<    EXPIRE  ({d})    >>>', color = colors.WHITE, size = 25, weight = 'bold'  )], alignment='center', width=750)

            # s.saida_tempo_de_treino.visible = True
            # self.saida.texto1_size = 50
            # self.saida.texto1_color= colors.GREEN
            self.saida_respiro.controls = [Stack([respiro, s])]
            # self.quado_saida.content.alignment= MainAxisAlignment.CENTER


        for d in range(descan,0,-1):
            # a = time()
            Inspire(d)
            super().update()
            for i in range(0,width_max,6):
                respiro.width = i
                sleep(0.005)
                if self.parar_pomodoro:
                    break
                super().update()
            respiro.bgcolor = colors.GREEN
            Expire(d)
            super().update()
            if self.parar_pomodoro:
                break             
            for i in range(width_max,0,-1):
                respiro.width = i
                if self.parar_pomodoro:
                    break                    
                sleep(0.01577)
                super().update()
            respiro.bgcolor = colors.YELLOW
            # b = time()-a
            # print(b)

        # self.saida_treinamento.visible = estado_saida_treinamento
        # self.quado_saida.visible = estado_saida_quado
        # self.saida_respiro.controls = None
        self.saida_respiro.visible = False
        self.quado_saida.visible = True
        self.pause_pomodoro = False
        respiro.width = 0
        super().update()
  

def main_test(page: Page):
    page.title = "Teste"
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    # page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    page.theme_mode = ThemeMode.DARK
    page.window_width = 780
    page.window_height = 750


    p = Pomodoro(0.01,1)
    page.add(p)
    page.update()



if __name__ == '__main__':
    app(target=main_test)