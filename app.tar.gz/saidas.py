from flet import (
    UserControl,
    Row,
    Text,
    Column,
    MainAxisAlignment,
    Container,
    margin,
)


class Saidas(UserControl):
    def __init__(self, 
                 tempo_de_treino = '',
                 tempo_pomodoro = '',
                 contagem = '',
                 tempo_restante = '',
                 respiracao = '',
                 TEXT = ''
                 ):
        super().__init__()

        self.saida_tempo_de_treino = Text(tempo_de_treino, size = 20, visible=False)
        self.saida_tempo_pomodoro = Row([Text(tempo_pomodoro, size = 15, color = 'yellow' )], visible=False)
        self.saida_contagem = Row([Text(contagem)], visible=False )
        self.saida_tempo_restante = Row([Text(tempo_restante)], visible=False)
        self.saida_respiracao = Row([Text(respiracao)], visible=False)
        self.saida_TEXT = Row([Text(TEXT)], visible=False)
        self.Visibles(                
                 tempo_de_treino ,
                 tempo_pomodoro,
                 contagem,
                 tempo_restante,
                 respiracao,
                 TEXT)
    def build(self):
        self.saida = Row(
            alignment= MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment = 'center',
            controls=[
                      Column([self.saida_tempo_de_treino,self.saida_tempo_pomodoro,self.saida_contagem],alignment = MainAxisAlignment.START),
                      Column([self.saida_tempo_restante,self.saida_respiracao,self.saida_TEXT],alignment = MainAxisAlignment.START),
                    #   Row([],alignment = MainAxisAlignment.SPACE_AROUND),  
                                     
                      ],                                            
        )
        self.saida = Container(self.saida, margin=margin.all(6))
        
        return self.saida
    
    @property
    def saida_tempo_de_treinos(self):
        return Text('', size = 20, visible=False)
    # @saida_tempo_de_treino.setter
    # def saida_tempo_de_treino(self, texto):
    #     self.saida_tempo_de_treino = Text(texto, size = 20, visible=False)


    def Visibles(self,                 
                 tempo_de_treino ,
                 tempo_pomodoro,
                 contagem,
                 tempo_restante,
                 respiracao,
                 TEXT):
        if tempo_de_treino != '':
            self.saida_tempo_de_treino.visible = True
        if tempo_pomodoro != '':
            self.saida_tempo_pomodoro.visible = True
        if contagem != '':
            self.saida_contagem.visible = True
        if tempo_restante != '':
            self.saida_tempo_restante.visible = True
        if respiracao != '':
            self.saida_respiracao.visible = True
        if TEXT != '':
            self.saida_TEXT.visible = True                                                            


