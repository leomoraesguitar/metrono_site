

import flet as ft



class FileSelector(ft.UserControl):
    def __init__(self,
        tipo = 'save',
        result = None,
        ):
        super().__init__() 
        self.tipo = tipo   
        self.result = result
        self.pick_files_dialog = ft.FilePicker(on_result=self.pick_files_result)
        self.name = None
        self.path = None

    def pick_files_result(self, e: ft.FilePickerResultEvent):
        # selected_files.value = (
        #     ", ".join(map(lambda f: f.name, e.files)) if e.files else "Cancelled!"
        # )
        # selected_files.update()
        # print("aqui")
        # print("Selected files:", e.files)
        # print("Selected file or directory:", e.path)  
        # self.name = e.files
        # self.path = e.path    
        # super().update()
        # self.result(self)
        print(e)
        super().update()

    # pick_files_dialog = ft.FilePicker()
    # selected_files = ft.Text()
    def did_mount(self):
        match self.tipo:
            case 'save':
                self.pick_files_dialog.save_file(file_type = ft.FilePickerFileType.CUSTOM, allowed_extensions = ['txt'])
                # self.name = self.pick_files_dialog.result.files
                # self.path = self.pick_files_dialog.reult.path
            case 'select':
                 self.pick_files_dialog.pick_files()

        self.update()
        

    def Exibir_atributos(self, objeto):
        for i in objeto.__dict__.keys():
            print(i) 


    def build(self):
        return  self.pick_files_dialog




def main(page: ft.Page):
    def pick_files_result(e: ft.FilePickerResultEvent):
        selected_files.value = (
            ", ".join(map(lambda f: f.name, e.files)) if e.files else "Cancelled!"
        )
        selected_files.update()

    pick_files_dialog = ft.FilePicker(on_result=pick_files_result)
    selected_files = ft.Text()

    page.overlay.append(pick_files_dialog)

    page.add(
        ft.Row(
            [
                ft.ElevatedButton(
                    "Pick files",
                    icon=ft.icons.UPLOAD_FILE,
                    on_click=lambda _: pick_files_dialog.pick_files(
                        allow_multiple=True
                    ),
                ),
                selected_files,
            ]
        )
    )

ft.app(target=main)