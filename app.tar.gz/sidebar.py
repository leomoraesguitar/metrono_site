from flet import (
    UserControl,
    Column,
    Container,
    IconButton,
    Row,
    Text,
    IconButton,
    NavigationRail,
    NavigationRailDestination,
    TextField,
    alignment,
    border_radius,
    colors,
    MainAxisAlignment,
    icons,
    padding,
    FloatingActionButton,
    margin,
)


class Sidebar(UserControl): 
    def __init__(self, Salvar_cofig):
        super().__init__()
        # self.app_layout = app_layout
        # self.page = page
        # self.top_nav_items = [
        #     NavigationRailDestination(
        #         label_content=Text("Boards"),
        #         label="Boards",
        #         icon=icons.BOOK_OUTLINED,
        #         selected_icon=icons.BOOK_OUTLINED
        #     ),
        #     NavigationRailDestination(
        #         label_content=Text("Members"),
        #         label="Members",
        #         icon=icons.PERSON,
        #         selected_icon=icons.PERSON
        #     ),
 
        # ]
        # self.top_nav_rail = NavigationRail(
        #     selected_index=None,
        #     label_type="all",
        #     on_change=self.top_nav_change,
        #     destinations=self.top_nav_items,
        #     bgcolor=colors.BLUE_GREY,
        #     extended=True,
        #     expand=True
        # )
        self.Salvar_cofig=Salvar_cofig
        self.Botao_salvar = Row([FloatingActionButton(icon=icons.SAVE, 
                                                      expand = 1, 
                                                      tooltip = 'Slavar as tarefas',
                                                      on_click=self.Salvar_cofig)])

    def build(self):
        self.view = Container(
                            content=Column([Row([Text("Configurações")]),
                                            self.Botao_salvar
                                            
                                            
                                            ], 
                                        tight=True,
                                        expand =1,
                                        alignment= MainAxisAlignment.START
                                        ),
                        expand =0,
                        padding=padding.all(15),
                        margin=margin.all(0),
                        width=160,
                        height=950,
                        bgcolor=colors.BLUE_GREY,
                        # alignment= flet.Alignment(0, -1)
                        )
        return self.view
 