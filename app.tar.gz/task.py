
from flet import*

(
    Checkbox,
    Dropdown,
    Column,
    BoxShadow,
    border,
    Offset,
    ShadowBlurStyle,
    TextStyle,
    Container,
    Switch,
    ScrollMode,
    Slider,
    FloatingActionButton,
    NavigationRail,
    MainAxisAlignment,
    NavigationRailDestination,
    IconButton,
    Page,
    Row,
    Tab,
    Tabs,
    Text,
    TextField,
    UserControl,
    colors,
    dropdown,
    icons,
    padding,
    margin,    
    alignment,    
    border_radius,    
    Alignment,
    ButtonStyle,
)
# from controlador_metronomo import Metronomo_Control, Thread, Escrever_json, Ler_json
from controlador_metronomo_flet import Escrever_json, Ler_json, Metronomo_Control_flet, Thread

# from time import sleep
# from sidebar import Sidebar

config = 'config_metronomo_flet.json'

m = Metronomo_Control_flet()





class Task(UserControl):
    def __init__(self, 
                 task_name, 
                 task_status_change, 
                 task_delete, 
                 exibir,
                 stop,
                 page, 
                 bpm = 120, 
                 continuar = False, 
                 pomodoro_ativar = False, 
                 tempo_pomodoro = 3, 
                 tempo_descanso = 1):
        super().__init__()
        # self.outros = outras
        self.page = page
        self.metronomo = Metronomo_Control_flet()
        self.continuar  = continuar
        self.pomodoro_ativar = pomodoro_ativar
        self.pomodoro = tempo_pomodoro
        self.descanso = tempo_descanso
        self.completed = False
        self.task_name = task_name
        self.task_status_change = task_status_change
        self.Exibir = exibir
        self.task_delete = task_delete
        self.valor_bpm = bpm
        self.stopp = False
        self.stop = stop
        self.nome_tarefa = Text(self.task_name, size = 20)
        self.caixa = Checkbox(value=False, 
                                    #  label=self.task_name,
                                     check_color = colors.BLACK, 
                                     on_change=self.status_changed)
        self.caixa_e_nome_taref = Row([self.caixa, self.nome_tarefa], width=480)
        self.bpm = Dropdown(data = 'valorbpm',
                options=[dropdown.Option(i) for i in range(30,550,1)],
                # min = 30,
                # max = 250,
                # divisions = 10,
                # alignment = Alignment(0, -1),
                text_size = 20,
                # filled=True, 
                border_width = 0,
                prefix_text = 'bpm: ',
                value = self.valor_bpm,
                width = 100,
                height = 32,
                content_padding = 0,
                text_style = TextStyle(weight = 'bold'),
                # focused_bgcolor=colors.GREEN_ACCENT_400,
                # border_color = colors.WHITE60,
                # border = flet.InputBorder.OUTLINE,
                # label = '{value}', 
                on_change = self.Modificar_bpm,                                                   
        )        

        # self.display_bpm = TextField(value = self.bpm.value, width = 60)
        self.edit_name = TextField(max_length = 55, expand = 1,color = '#888888', text_size = 25)
        self.icon_play = Container(
            bgcolor = colors.with_opacity(0.3, 'green'),
            border = border.all(0, color = "#282a36"),#4f72a4
            border_radius = 8,
            alignment = Alignment(0,0),
            shadow = BoxShadow(
                spread_radius=1,
                blur_radius=5,
                color=colors.BLUE_GREY_300,
                offset=Offset(0, 0),
                blur_style=ShadowBlurStyle.OUTER,
            ),
            content = IconButton(
                                icon=icons.PLAY_ARROW_ROUNDED,
                                tooltip="Inicia o metrônomo",
                                on_click=self.Play_metronomo,
                                data = 'play',
                                
                                
                            )
        ) 
        self.icon_pause =  Container(
            bgcolor = colors.with_opacity(0.3, 'yellow'),
            border = border.all(0, color = "#282a36"),#4f72a4
            border_radius = 8,
            alignment = Alignment(0,0),
            shadow = BoxShadow(
                spread_radius=1,
                blur_radius=5,
                color=colors.BLUE_GREY_300,
                offset=Offset(0, 0),
                blur_style=ShadowBlurStyle.OUTER,
            ),
            content = IconButton(
                                icon=icons.PAUSE_ROUNDED,
                                tooltip="Pausa o metrônomo",
                                on_click=self.Pause_metronomo,
                            )
        )
        self.stope = Container(
            bgcolor = colors.with_opacity(0.3, 'red'),
            border = border.all(0, color = "#282a36"),#4f72a4
            border_radius = 8,
            alignment = Alignment(0,0),
            shadow = BoxShadow(
                spread_radius=1,
                blur_radius=5,
                color=colors.BLUE_GREY_300,
                offset=Offset(0, 0),
                blur_style=ShadowBlurStyle.OUTER,
            ),
            content = IconButton(
                icon=icons.STOP_ROUNDED,
                tooltip="Para o metrônomo",
                on_click=self.Stop_metronomo,
                selected_icon_color = 'red',
                # style = ButtonStyle.shadow_color,
                )

        )
        self.display_view = Row(
            alignment= MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment="center",
            expand = 0,
            # spacing = 100
     
            )
        self.botoes_das_tarefas = Row([self.bpm,self.icon_play,self.icon_pause,
                       self.stope,                                       
                        IconButton(
                            icon=icons.CREATE_OUTLINED,
                            tooltip="Editar nome da tarefa",
                            on_click=self.edit_clicked,
                        ),
                        IconButton(
                            icons.DELETE_OUTLINE,
                            tooltip="Delete tarefa",
                            on_click=self.delete_clicked,
                        ),])
        self.display_view.controls = [self.caixa_e_nome_taref, self.botoes_das_tarefas]        
        self.edit_view = Row(
            visible=False,
            expand=1,
            alignment=MainAxisAlignment.CENTER,
            vertical_alignment="center",
            controls=[
                self.edit_name,
                IconButton(
                    icon=icons.DONE_OUTLINE_OUTLINED,
                    icon_color=colors.GREEN,
                    tooltip="Atualizar tarefa",
                    on_click=self.save_clicked,
                    # key = 'enter',
                ),
            ],
        )
        
    def build(self):        
        return Container(content = Row(
                    # scroll = ScrollMode.ALWAYS,
                    # col={"sm": 6, "md": 4, "xl": 2},
                #  alignment=   MainAxisAlignment.SPACE_AROUND,
            controls=[self.display_view, self.edit_view],height=33, wrap=False),#, height=50
            
            # bgcolor = "#282a36",
            border = border.all(1, color = "#4f72a4"),#4f72a4
            border_radius = 20,
        
            width=850,
            shadow = BoxShadow(
                spread_radius=1,
                blur_radius=8,
                color=colors.BLACK54,
                offset=Offset(0, 0),
                blur_style=ShadowBlurStyle.OUTER,
            ),
            )
    def edit_clicked(self, e):
        self.edit_name.value = self.nome_tarefa.value
        self.display_view.visible = False
        self.edit_view.visible = True
        self.update()
    def save_clicked(self, e):
        self.nome_tarefa.value = self.edit_name.value
        self.display_view.visible = True
        self.edit_view.visible = False
        self.update()
    def status_changed(self, e):
        self.completed = self.caixa.value
        self.task_status_change(self)
        print('marcou a tarefa:', self.caixa_e_nome_taref.controls[0].value)
    def delete_clicked(self, e):
        self.task_delete(self)
    def Play_metronomo(self,e):
        
        def ex():
            return self.Exibir(self)
        Thread(target=ex, daemon=False).start()
        # m = Metronomo_Control()
        # print(self.display_view.controls[1].controls[1].icon_color)
        # print(self.icon_play.icon_color)
        self.icon_play.icon_color = colors.RED_400
        self.nome_tarefa.color = colors.RED_400
        print('apertou play')
        nome_tarefa = self.nome_tarefa.value


        self.metronomo.pomodoro_habilitado = self.pomodoro_ativar
        self.metronomo.tempo_pomodoro = self.pomodoro
        self.metronomo.tempo_descanso = self.descanso
        self.metronomo.continuar = self.continuar    
        # self.saida_tempo_pomodoro.value = 
        bpm_atual= float(self.bpm.value)
        # self.bpm_display.value  =   bpm_atual  
        self.metronomo.setBpm(bpm_atual)
        self.metronomo.Play()
        self.update()
    def Pause_metronomo(self,e):
        # m = Metronomo_Control()
        print('apertou pause')
        
        if self.metronomo.pause:
            self.icon_pause.icon_color =  None
        else:
            self.icon_pause.icon_color =  colors.RED_400
        self.metronomo.Pause()  
        self.update()
    def Stop_metronomo(self,e):
        self.stopp =True
        self.stop(self)
        self.metronomo = None
        self.metronomo = Metronomo_Control_flet()
        self.icon_play.icon_color = None
        self.icon_pause.icon_color =  None
        self.nome_tarefa.color =  None
        print('apertou stop')
        self.metronomo.Stop()   
        self.update()
    def Modificar_bpm(self,e):
        new_bpm = float(self.bpm.value)
        self.metronomo.setBpm(new_bpm)
        self.metronomo.Atualizar(True)
        # self.display_bpm.value = new_bpm
        # self.update()
    def Modificar_bpm2(self,e,bpm):
        old_bpm = m.getBpm
        new_bpm = old_bpm+bpm
        self.metronomo.setBpm(new_bpm)
        self.metronomo.Atualizar(True)        
