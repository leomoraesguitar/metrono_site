

from flet import*



def main_test(page: Page):
    page.title = "teste"
    # page.window_title_bar_hidden = True
    page.window_movable = True
    page.horizontal_alignment = "center"
    # page.scroll = ScrollMode.ALWAYS
    page.bgcolor = colors.TRANSPARENT, #'#282a36'
    # page.theme = theme.Theme( font_family="Verdana")
    # page.theme = theme.Theme(color_scheme_seed="#282a36")
    # page.theme = theme.Theme(visual_density=ThemeVisualDensity.STANDARD)
    # page.theme_mode = ThemeMode.LIGHT
    page.window_width = 600
    page.window_height = 460



    def func(e):
        t.value = round(e.control.value,2)
        page.update()

    def Botao(texto, icon = None, width = 100,on_click = None, color  = 'blue'):
        bor2 = border.BorderSide(20, colors.with_opacity(1,'white'))
        bor = border.all(1, colors.with_opacity(0.9,'#777777')) 
        sombra =  BoxShadow(
            spread_radius=0,
            blur_radius=10,
            color=colors.with_opacity(0.8,'blue'),
            offset=Offset(3, 3),
            blur_style=ShadowBlurStyle.NORMAL)
        gradiente =  gradient=LinearGradient(
            begin=Alignment(-1, -1),
            end=Alignment(-0.1, -0.1),
            
            colors=[
                "#777777",
                "#000000",
                "#000000",
                        ],
            tile_mode=GradientTileMode.MIRROR,
            rotation=30*3.14/180,
        )

        if icon == None:
            conteudo = ElevatedButton(content = Text(texto, size=30, weight='bold', no_wrap = True, color=color),width=width)
        else:
            conteudo = Icon(icons.PLAY_ARROW, color=color)
        return Container( 
            content= conteudo,
            
                # [
                    # Text("1", color=colors.WHITE),
                    # Text("2", color=colors.WHITE, right=0),
                    # Text("3", color=colors.WHITE, right=0, bottom=0),
                    # Text("4", color=colors.WHITE, left=0, bottom=0),
                # ]
            # ),
            # top = 5,
            alignment=Alignment(0, 0),
            bgcolor='green',
            width=width,
            # height=220,
            border_radius=20,
            on_click = on_click,
            shadow=sombra,
            gradient=gradiente,
            border= bor, 
            data = texto,  
            animate=animation.Animation(1000, "bounceOut"),
            theme=Theme(color_scheme_seed=colors.INDIGO),
            theme_mode=ThemeMode.DARK,

            )
    
    n = Botao('+5', on_click=func)

    t = Text()

    n = Column([Slider(min = 0, max = 1.0, on_change=func),t ])
    page.add(n)
    page.update()



if __name__ == '__main__':
    app(target=main_test)