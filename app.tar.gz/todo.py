from flet import (
    Checkbox,
    Dropdown,
    Column,
    Container,
    WEB_BROWSER,
    app,
    Icon,
    AppBar,
    Alignment,
    icons,
    theme,
    Slider,
    PopupMenuButton,
    PopupMenuItem,
    FloatingActionButton,
    NavigationRail,
    NavigationRailDestination,
    IconButton,
    Switch,
    Page,
    Row,
    Tab,
    Tabs,
    CrossAxisAlignment,
    MainAxisAlignment,
    MainAxisAlignment,
    Text,
    TextField,
    ScrollMode,
    UserControl,
    colors,
    icons,
    padding,
    margin,    
    alignment,    
    dropdown,
    border_radius,    
    InputBorder,
    MainAxisAlignment,
)
from controlador_metronomo_flet import Escrever_json, Ler_json, Metronomo_Control_flet, Thread
from winsound import MessageBeep, MB_ICONHAND
from sidebar import Sidebar
from task import Task
from time import sleep
from saidas import Saidas
config = 'config_metronomo_flet.json'



class TodoApp(UserControl):
    def build(self):        
        cont = 0
        self.Largura_tela_central = 850
        self.new_task = TextField(hint_text="Nome da tarefa", color = colors.BLUE, border = InputBorder.OUTLINE, border_width = 5, border_radius = 5,
                                  expand=True, max_length = 55)
        self.tasks = Column()
        self.saida = Column()
        self.barra_lateral =  Sidebar(self.Salvar_cofig)
        self.Carregar_dados()
        self.filter = Tabs(selected_index=0, on_change=self.tabs_changed,tabs=[Tab(text="Todos"), Tab(text="Ativos"), Tab(text="Concluídos")])
        self.ncontinuar = Switch(label = 'Continuar', data = 'Continuar')
        self.pomodoro_ativar = Switch(label = 'Pomodoro:', data ='Pomodoro_ativar' )
        self.pomodoro = Dropdown(options=[dropdown.Option(i) for i in range(1,30,1)], width = 55, value = 3, data= 'pomodoro')
        self.descanso = Dropdown(options=[dropdown.Option(i) for i in range(1,30,1)], width = 150, value = 1, prefix_text = 'Descanso:  ', data = 'descanso')
        self.Linha_pomodoro = Row([self.ncontinuar,self.pomodoro_ativar,self.pomodoro,self.descanso ])
        self.bpm_display = Text()
        self.nova_tarefa = Row(vertical_alignment = CrossAxisAlignment.START)
        self.nova_tarefa.controls.extend([self.new_task, FloatingActionButton(icon=icons.ADD, on_click=self.add_clicked, data = 'add_tarefa'),FloatingActionButton(icon=icons.OUTLINED_FLAG_OUTLINED, on_click=self.add_clicked, data = 'teste exibir')])
        self.coluna_tasks = Column(spacing=0,height = self.Largura_tela_central,alignment = MainAxisAlignment.START,scroll = ScrollMode.ALWAYS,)
        self.coluna_tasks.controls.append(self.tasks)
        self.Tela_tarefas =Column(width=self.Largura_tela_central,expand = 0,alignment = MainAxisAlignment.START,spacing=-5)
        self.Tela_tarefas.controls.extend([self.nova_tarefa,self.bpm_display,self.Linha_pomodoro,self.saida,self.filter,self.coluna_tasks])
        # application's root control (i.e. "view") containing all other controls
        return Row([self.barra_lateral, self.Tela_tarefas], alignment=MainAxisAlignment.START)

    def add_clicked(self, e):
        data= e.control.data
        match data:
            case 'add_tarefa':
                task = Task(self.new_task.value, self.task_status_change, self.task_delete)
                # task = self.build_task(self.new_task.value)
                self.tasks.controls.append(task)
                self.new_task.value = ""
                self.update()
            case 'Continuar':
                self.continuar = self.ncontinuar.value
            case 'Pomodoro_ativar':
                self.pomodoro_habilitado = self.pomodoro_ativar.value
            case 'pomodoro':
                self.tempo_pomodoro = self.pomodoro.value
            case 'descanso':
                self.tempo_descanso = self.descanso.value
            case 'teste exibir':
                saida = Saidas(tempo_de_treino = 'testando...',
                               tempo_pomodoro = 'tempo_pomodoro' ,
                               contagem = 'contagem',
                               tempo_restante = 'tempo_restante',
                               respiracao = 'respiracao',
                               TEXT = 'TEXT'
                               )
                self.saida.controls = [saida]
                self.update()

    def build_task(self, nome, bpm = 120):
        # cont += 1
        self.nome_tarefa = Text(nome, size = 25)
        self.display_task = Row([Checkbox(value=False, 
                                    #  label=self.task_name,
                                     check_color = colors.BLACK, 
                                     on_change=self.status_changed), self.nome_tarefa])
        self.bpm = Dropdown(data = 'valorbpm',
                options=[dropdown.Option(i) for i in range(30,250,5)],
                # min = 30,
                # max = 250,
                # divisions = 10,
                alignment = Alignment(0, -1),
                # text_size = 5,
                prefix_text = 'bpm',
                value = bpm,
                width = 120,
                height = 60,
                # border_color = colors.WHITE60,
                # border = flet.InputBorder.OUTLINE,
                # label = '{value}', 
                on_change = self.Modificar_bpm,                                                   
        )        

        # self.display_bpm = TextField(value = self.bpm.value, width = 60)
        self.edit_name = TextField(expand=1)
        self.icon_play = IconButton(
                            icon=icons.PLAY_ARROW_ROUNDED,
                            tooltip="Inicia o metrônomo",
                            on_click=self.Play_metronomo, 
                            # data = cont    
                        )
        self.icon_pause =   IconButton(
                            icon=icons.PAUSE_ROUNDED,
                            tooltip="Pausa o metrônomo",
                            on_click=self.Pause_metronomo,
                        )
        self.display_view = Row(
            alignment="spaceBetween",
            vertical_alignment="center",
            spacing = 0,
            controls=[
                self.display_task,
                # self.bpm,
                # self.display_bpm,
                Row(
                    spacing=0,
                    controls=[
                        self.bpm,
                        self.icon_play,
                        self.icon_pause,
                        IconButton(
                            icon=icons.STOP_ROUNDED,
                            tooltip="Para o metrônomo",
                            on_click=self.Stop_metronomo,
                            
                        ),                     
                        
                        IconButton(
                            icon=icons.CREATE_OUTLINED,
                            tooltip="Edit To-Do",
                            on_click=self.edit_clicked,
                        ),
                        IconButton(
                            icons.DELETE_OUTLINE,
                            tooltip="Delete To-Do",
                            on_click=self.delete_clicked,
                        ),
                    ],
                ),
            ],
        )

        self.edit_view = Row(
            visible=False,
            alignment="spaceBetween",
            vertical_alignment="center",
            controls=[
                self.edit_name,
                IconButton(
                    icon=icons.DONE_OUTLINE_OUTLINED,
                    icon_color=colors.GREEN,
                    tooltip="Update To-Do",
                    on_click=self.save_clicked,
                ),
            ],
        )
        return Column(controls=[self.display_view, self.edit_view])

    def Salvar_cofig(self, e):
        arquiv = {'tarefa':[], 'bpm':[]}
        for i in self.tasks.controls:
            arquiv['tarefa'].append(i.nome_tarefa.value)
            arquiv['bpm'].append(i.bpm.value)

        print(arquiv)
        print('\n\n\n')

        Escrever_json(arquiv, config)

    def Carregar_dados(self):
        arquiv = Ler_json(config)  
        for i , j in  zip(arquiv['Tarefas']['tarefa'],arquiv['Tarefas']['bpm']):
            task = Task(i, self.task_status_change, self.task_delete,j)
            # task = self.build_task(i,j)
            self.tasks.controls.append(task)
       
    def task_status_change(self, task):
        self.update()

    def task_delete(self, task):
        # print(vars(self.tasks.controls[1]).keys())
        self.tasks.controls.remove(task)
        self.update()


    def update(self):
        status = self.filter.tabs[self.filter.selected_index].text
        for task in self.tasks.controls:
            task.visible = (
                status == "Todos"
                or (status == "Ativos" and task.completed == False)
                or (status == "Concluídos" and task.completed)
            )
        super().update()

    def tabs_changed(self, e):
        self.update()
    @property
    def Barra_App(self):
        self.barra_app =  AppBar(
            leading=Icon(icons.PALETTE),
            # leading_width=40,
            title=Text("Metrônomo Tarefas"),
            center_title=False,
            bgcolor=colors.SURFACE_VARIANT,
            actions=[
                IconButton(icons.WB_SUNNY_OUTLINED),
                IconButton(icons.FILTER_3),
                PopupMenuButton(
                    items=[
                        PopupMenuItem(text="Item 1"),
                        PopupMenuItem(),  # divider
                        PopupMenuItem(
                            text="Checked item", checked=False, 
                            # on_click=check_item_clicked
                        ),
                    ]
                ),
            ],
        )  



    def edit_clicked(self, e):
        self.edit_name.value = self.nome_tarefa.value
        self.display_view.visible = False
        self.edit_view.visible = True
        self.update()

    def save_clicked(self, e):
        self.nome_tarefa.value = self.edit_name.value
        self.display_view.visible = True
        self.edit_view.visible = False
        self.update()

    def status_changed(self, e):
        self.completed = self.display_task.value
        self.task_status_change(self)

    def delete_clicked(self, e):
        self.task_delete(self)


    def Ler_parametros(self):
        nome_tarefa = self.nome_tarefa.value
        self.pomodoro_habilitado = self.pomodoro_ativar.value
        self.tempo_pomodoro = self.pomodoro.value
        self.tempo_descanso = self.descanso.value
        self.continuar = self.ncontinuar.value 
        bpm_atual= float(self.bpm.value)
        return nome_tarefa, bpm_atual
    
    # def Ini_Thread(self, controle, argu=''):
    #     if controle == 'pomodoro':
    #         # self.setOn = True
    #         if self.pomodoro_habilitado:
    #             if self.tempo_pomodoro != '' and self.tempo_descanso != '':
    #                 try:
    #                     self.tempo_pomodoro, self.tempo_descanso = float(
    #                         self.tempo_pomodoro), float(self.tempo_descanso)
    #                 except:
    #                     self.tempo_pomodoro, self.tempo_descanso = 3, 1
    #                 Thread(target=self.Pomodoro, daemon=True).start()

    #     elif controle == 'beep':
    #         self.setOn = False
    #         sleep(0.3)
    #         self.setOn = True
    #         if not self.metronomo_inciado:
    #             Thread(target=self.beep, daemon=True).start()
    #             self.metronomo_inciado = True    

    # def Play(self):
    #     self.Ini_Thread('pomodoro')
    #     self.Ini_Thread('beep')

    # def Pomodoro(self): 
    #     self.saida_tempo_pomodoro.value = 'Pomodoro inciado...'
    #     self.update()
    #     while self.pomodoro_habilitado:
    #         self.Contagem(self.tempo_pomodoro*60)
    #         if self.pomodoro_habilitado == False:
    #             break
    #         MessageBeep(MB_ICONHAND)

    #         if self.pomodoro_habilitado == False:
    #             break
    #         horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(
    #             self.descanso.value*60)
    #         self.saida_tempo_pomodoro.value = f'Faça uma pausa de {horas2}:{minutos2}:{segundos2}'
    #         self.update()

    #         self.contando = True
    #         # Thread(target=m.Barra_de_progresso, daemon=True).start()

    #         if self.pomodoro_habilitado == False:
    #             break
    #         self.Pausar
    #         if self.pomodoro_habilitado == False:
    #             break

    #         self.Contagem(self.tempo_descanso*60)
    #         self.contando = False

    #         if self.pomodoro_habilitado == False:
    #             break
    #         MessageBeep(MB_ICONHAND)
    #         if self.pomodoro_habilitado == False:
    #             break
    #         horas2, minutos2, segundos2 = self.converter_segundos_para_horas_min_segundos(
    #             self.tempo_pomodoro*60)
    #         self.saida_tempo_pomodoro.value = f'Volte a treinor por {horas2}:{minutos2}:{segundos2} '
    #         self.update()

    #         if self.pomodoro_habilitado == False:
    #             break

    #         self.Pausar

    #     self.saida_tempo_pomodoro.value = ''
    #     self.update()

    # def Contagem(self, tempo):
    #     tempo = int(round(tempo, 0))
    #     for i in range(tempo):
    #         while self.pausar_pomodoro:
    #             sleep(0.1)

    #         h1, h2, h3 = self.converter_segundos_para_horas_min_segundos(
    #             tempo-i)
    #         self.saida_contagem.value = f'({h1}:{h2}:{h3})'
    #         self.update()

    #         sleep(1)

    #         if self.pomodoro_habilitado == False:
    #             break
    #     self.saida_contagem.value = ''
    #     self.update()





    def Play_metronomo(self,e):
        # data = e.control.data
        # m = Metronomo_Control()
        # print(self.display_view.controls[1].controls[1].icon_color)
        print(vars(e.control))
        self.icon_play.icon_color = colors.RED_400
        self.nome_tarefa.color = colors.RED_400
        print('apertou play')
        nome_tarefa, bpm_atual = self.Ler_parametros()

        self.bpm_display.value  =  bpm_atual 
        self.Stop()
        self.setBpm(bpm_atual)
        self.Play()
        self.update()

    def Pause_metronomo(self,e):
        # m = Metronomo_Control()
        print('apertou pause')
        
        if self.pause:
            self.icon_pause.icon_color =  None
        else:
            self.icon_pause.icon_color =  colors.RED_400
        self.Pause()  
        self.update()

    def Stop_metronomo(self,e):
        # m = None
        # m = Metronomo_Control_flet()
        self.icon_play.icon_color = None
        self.icon_pause.icon_color =  None
        self.nome_tarefa.color =  None
        print('apertou stop')
        self.Stop('flet')   
        self.update()
    def Modificar_bpm(self,e):
        new_bpm = float(self.bpm.value)
        self.setBpm(new_bpm)
        self.Atualizar(True)
        # self.display_bpm.value = new_bpm
        # self.update()





def main(page: Page):
    page.title = "ToDo App"
    page.horizontal_alignment = "center"
    # page.scroll = flet.ScrollMode.ADAPTIVE
    # page.bgcolor = colors.WHITE
    page.theme = theme.Theme(
            font_family="Verdana")
 


    # create application instance
    app = TodoApp()
    # app.Barra_App
    # page.appbar = app.barra_app
     

    # add application's root control to the page

    page.add(app)
    page.update()

app(target=main, view=WEB_BROWSER)
# flet.app(target=main)