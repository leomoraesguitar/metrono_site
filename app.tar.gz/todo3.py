from flet import (
    Checkbox,
    Dropdown,
    Column,
    Container,
    WEB_BROWSER,
    app,
    Icon,
    AppBar,
    Alignment,
    border,
    icons,
    KeyboardEvent,
    theme,
    Slider,
    PopupMenuButton,
    PopupMenuItem,
    FloatingActionButton,
    NavigationRail,
    NavigationRailDestination,
    IconButton,
    Switch,
    Page,
    Row,
    Tab,
    Tabs,
    CrossAxisAlignment,
    MainAxisAlignment,
    MainAxisAlignment,
    ThemeMode,
    Text,
    TextField,
    ScrollMode,
    UserControl,

    Control,
    colors,
    icons,
    padding,
    margin,    
    alignment,    
    dropdown,
    border_radius,    
    InputBorder,
    MainAxisAlignment,
)
from controlador_metronomo_flet import Escrever_json, Ler_json, Metronomo_Control_flet, Thread
from winsound import MessageBeep, MB_ICONHAND
from sidebar import Sidebar
from task import Task
from time import sleep, time
from saidas import Saidas
from flet_contrib.color_picker import ColorPicker
from Layout_metronomo_flet import Layout

__docformat__ = "restructuredtext"


config = 'config_metronomo_flet.json'



class TodoApp(UserControl):
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.Metro_normal = Metronomo_Control_flet()
        self.layout = Layout()
        # self.Largura_tela_central = 850        
        # self.tasks = Column()
        self.stop = False
        self.saida = self.MeuContainer()        
        self.saida.content = Column()

        self.ncontinuar = Switch(label = 'Continuar', data = 'Continuar')
        self.pomodoro_ativar = Switch(label = 'Habilitar Pomodoro', data ='Pomodoro_ativar', value = True )
        self.pomodoro = Dropdown(on_change = self.add_clicked, 
                                 border_width = 0, 
                                 options=[dropdown.Option(i) for i in range(1,30,1)], 
                                 width = 150, 
                                 value = 3,
                                 prefix_text = 'Pomodoro:  ', 
                                 data= 'pomodoro',

                                 )
        self.descanso = Dropdown(on_change = self.add_clicked, border_width = 0, options=[dropdown.Option(i) for i in range(1,30,1)], width = 150, value = 1, prefix_text = 'Descanso:  ', data = 'descanso')
                
        
        #display dos bpm
        self.bpm_display = self.MeuContainer(cor  = "#303030")
        self.bpm_display.content = Dropdown(on_change = self.add_clicked, border_width = 0, options=[dropdown.Option(i) for i in range(30,251,1)], width = 150, value = 120, suffix_text = 'BPM', data= 'bpm_display')
        
        # self.barra_lateral =  Sidebar(self.Salvar_cofig)
        self.respiro = Container(content=Text(),bgcolor= colors.YELLOW)
        self.respiro.width = 0
        
        self.filter = Tabs(
                            selected_index=3, 
                            divider_color = '#282a36',
                            on_change=self.tabs_changed,
                            tabs=[
                                    Tab(text="Todos"), 
                                    Tab(text="Ativos"), 
                                    Tab(text="Concluídos"), 
                                    Tab(text="Metrônomo Normal"),
                                    Tab(text="Lento"),
                                    Tab(text="Médio"),
                                    Tab(text="Rápido"),
                                    Tab(text="Speed Burst"),
                                    ]
                            )
        self.linha_filtros = Row([self.filter], alignment=MainAxisAlignment.SPACE_BETWEEN)
        
        #TELA METRONOMO NORMAL
        self.Vol = Slider(min = 0, max = 1, divisions = 0.1, label ="{value}%", active_color = '#009900',
                            thumb_color = '#009900',    )
        self.iniciar_medicao_bpm = False
        self.tap = FloatingActionButton('Tap', on_click = self.Tap2)

        self.Criar_tela_mentronomo_nomal()            
        self.Criar_tela_tarefas()
        self.Criar_tela_Lento()
        self.Criar_tela_Medio()
        self.Criar_tela_Rapido()
        self.Criar_tela_Speed()
        self.Carregar_dados()

        self.Definir_tela_inicial()

        
        self.tela_principal = Column(
                                    [
                                        self.new_task, 
                                        self.linha_pomodoro, 
                                        self.saida,
                                        self.respiro,
                                        self.linha_filtros, 
                                        self.tarefas, 
                                        self.tela_mentronomo_nomal,
                                        self.Lento,
                                        self.Medio,
                                        self.Rapido,
                                        self.Speed,
                                        ]
                                    )








    @property
    def new_task(self):
        self.novas_tarefas = self.MeuContainer()
        linha1 = Row()
        
        self.nova_tarefa = TextField(hint_text="Nome da tarefa", 
                                color = '#0fff00',
                                border = InputBorder.OUTLINE, 
                                border_width = 0, border_radius = 5,
                                    expand=True, max_length = 55)
        
        botao_add_nova_tarefa = FloatingActionButton(icon=icons.ADD, on_click=self.add_clicked, data = 'add_tarefa', tooltip='adionar nova tarefa')
        Botao_exibir_saidas = FloatingActionButton(icon=icons.OUTLINED_FLAG_OUTLINED, on_click=self.add_clicked, data = 'teste exibir', tooltip='enviar texto para saída')
        Botao_salvar = FloatingActionButton(icon=icons.SAVE, on_click=self.Salvar_cofig, data = 'salvar', tooltip='salvar tarefas')
        linha1.controls = [self.nova_tarefa, botao_add_nova_tarefa,Botao_exibir_saidas, Botao_salvar]
        self.novas_tarefas.content = linha1    
        return self.novas_tarefas
    


    @property
    def linha_pomodoro(self):
        a1 = self.MeuContainer()
        linha2 = Row([self.ncontinuar,self.pomodoro_ativar,self.pomodoro,self.descanso ])
        linha2.alignment = MainAxisAlignment.SPACE_AROUND
        a1.content = linha2
        return a1
    


    @property
    def Add_saidas(self):
        saida = self.MeuContainer()
        return saida
    # @property
    # def tarefas(self):
    #     return Row()#spacing=0,alignment = MainAxisAlignment.START,scroll = ScrollMode.ALWAYS



    # @property
    # def Metro_normal(self):
    #         a1 = Task('', self.task_aba_change, self.task_delete, self.Exibir, self.Stop,self.page)
    #         a1.pomodoro = self.pomodoro.value
    #         a1.descanso = self.descanso.value
    #         a1.continuar = self.ncontinuar.value
    #         a1.pomodoro_ativar = self.pomodoro_ativar.value
    #         a1.bpm.text_size = 40         
    #         # a1.bpm.scale = 0.5        
    #         a1.bpm.expand = 0
    #         a1.bpm.border_width = 3
    #         a1.bpm.dense = False
    #         # a1.bpm.suffix_text = 'bpm'
            
    #         a1.bpm.width = 200         
    #         a1.bpm.height = 90  

    #         a1.icon_play.scale = 1.5
    #         a1.icon_pause.scale = 1.5
    #         a1.stope.scale = 1.5
    #         a1.icon_play.bgcolor = "#4a733e"
    #         a1.icon_pause.bgcolor = "#ffdb00"
    #         a1.stope.bgcolor = "#"+"80"+"10"+"10"
    #         return a1



    def Criar_tela_tarefas(self):
        self.tarefas = self.MeuContainer()
        self.tarefas.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 420,
                                    scroll = ScrollMode.ALWAYS,
                                    
                                    )     
    def Criar_tela_Lento(self):
        self.Lento = self.MeuContainer()
        self.Lento.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 420,
                                    scroll = ScrollMode.ALWAYS,
                                    alignment=MainAxisAlignment.START
                                    
                                    )
    def Criar_tela_Medio(self):
        self.Medio = self.MeuContainer()
        self.Medio.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 420,
                                    scroll = ScrollMode.ALWAYS,
                                    alignment=MainAxisAlignment.START
                                    
                                    )
    def Criar_tela_Rapido(self):
        self.Rapido = self.MeuContainer()
        self.Rapido.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 420,
                                    scroll = ScrollMode.ALWAYS,
                                    alignment=MainAxisAlignment.START
                                    
                                    )
    def Criar_tela_Speed(self):
        self.Speed = self.MeuContainer()
        self.Speed.content = Column(
                                    horizontal_alignment=CrossAxisAlignment.END, 
                                    height= 420,
                                    scroll = ScrollMode.ALWAYS,
                                    alignment=MainAxisAlignment.START
                                    
                                    )                        



    def Modificar_bpm2(self,e):
        return self.Metro_normal.ModificarBPM(int(self.bpm.value))

    def Play2(self, e=''):
        self.Metro_normal.pomodoro_habilitado = self.pomodoro_ativar.value
        self.Metro_normal.tempo_descanso, self.Metro_normal.tempo_pomodoro = int(self.descanso.value), int(self.pomodoro.value)
        Thread(target=self.check_display, daemon=False).start()
        return self.Metro_normal.Play()
    def Tap2(self, e=''):
        return self.Tap
    
    @property
    def Tap(self):
        print('tap pressionado')
        if not self.iniciar_medicao_bpm:
            self.ti = time()
            self.iniciar_medicao_bpm = not self.iniciar_medicao_bpm
        else:
            self.tf = time()
            # print(f'delta T = {self.tf-self.ti}')
            novo_bpm = int(60/(self.tf-self.ti))
            self.Metro_normal.ModificarBPM(novo_bpm)
            self.bpm.value = novo_bpm
            super().update() 
            self.ti = None
            self.tf = None
            self.iniciar_medicao_bpm = not self.iniciar_medicao_bpm

    def Criar_tela_mentronomo_nomal(self):
        self.tela_mentronomo_nomal = self.MeuContainer()
        self.tela_mentronomo_nomal.content = Row(vertical_alignment = CrossAxisAlignment.CENTER,
                                                alignment=MainAxisAlignment.SPACE_AROUND)     
        # self.tela_mentronomo_nomal.content.controls = [self.Metro_normal.bpm,
        #                                             self.Vol,
        #                                             self.Metro_normal.icon_play,
        #                                             self.Metro_normal.icon_pause,
        #                                             self.Metro_normal.stope,
        #                                             self.tap]
        
        self.botao_play = IconButton(
                            icon=icons.PLAY_ARROW_ROUNDED,
                            tooltip="Inicia o metrônomo",
                            on_click = self.Play2,
                            data = 'play',
                            scale = 1.5,
                            bgcolor = "#282a36",
                            # bgcolor = "#4a733e",
                            
                        )
        self.botao_pause =   IconButton(
                            icon=icons.PAUSE_ROUNDED,
                            tooltip="Pausa o metrônomo",
                            on_click = self.Metro_normal.Pause,
                            scale = 1.5,
                            bgcolor = "#282a36"
                            # bgcolor = "#ffdb00"
                        )
        self.botao_stope = IconButton(
                            icon=icons.STOP_ROUNDED,
                            tooltip="Para o metrônomo",
                            on_click = self.Metro_normal.Stop,
                            scale = 1.5,
                            bgcolor = "#282a36"
                            # bgcolor = "#"+"80"+"10"+"10"
                        )
        

        self.bpm = Dropdown(data = 'valorbpm',
                options=[dropdown.Option(i) for i in range(30,550,1)],
                alignment = Alignment(0, -1),
                prefix_text = 'bpm',
                value = 120,
                width = 200,
                height = 80,
                text_size = 25,
                border_width = 0,
                on_change = self.Modificar_bpm2,                                                   
        )

            
        self.tela_mentronomo_nomal.content.controls = [
                    self.bpm,
                    self.Vol,
                    self.botao_play,
                    self.botao_pause,
                    self.botao_stope,
                    self.tap
        ]
        

        # self.Metro_normal.display


        self.tela_mentronomo_nomal.visible = True



    def MeuContainer(self, cor  = "#282a36"):
        return Container(bgcolor = cor,
                                border = border.all(2, color = "#282a36"),#4f72a4
                                border_radius = 8)
   


    def build(self): 
        return Column([self.tela_principal])



    def Teclas(self, e: KeyboardEvent):
        if (aba := self.filter.tabs[self.filter.selected_index].text) == "Metrônomo Normal":
            match e.key:
                case ' ':
                    self.Play2()               
                    print('pressionou space') 
                case 'Enter':
                    self.Metro_normal.Stop()            
                    print('pressionou enter')
                case 'P':
                    self.Metro_normal.Pause()               
                    print('pressionou P')
                case 'Numpad 7':
                    new_bmp = self.bpm.value + 1
                    self.Metro_normal.ModificarBPM(new_bmp)
                    self.bpm.value = new_bmp
                    super().update()
                case 'Numpad 8':
                    new_bmp = self.bpm.value + 5
                    self.Metro_normal.ModificarBPM(new_bmp)
                    self.bpm.value = new_bmp
                    super().update()    
                case 'Numpad 9':
                    new_bmp = self.bpm.value + 10
                    self.Metro_normal.ModificarBPM(new_bmp)
                    self.bpm.value = new_bmp
                    super().update() 
                case 'Numpad 1':
                    new_bmp = self.bpm.value - 1
                    self.Metro_normal.ModificarBPM(new_bmp)
                    self.bpm.value = new_bmp
                    super().update()
                case 'Numpad 2':
                    new_bmp = self.bpm.value - 5
                    self.Metro_normal.ModificarBPM(new_bmp)
                    self.bpm.value = new_bmp
                    super().update()    
                case 'Numpad 3':
                    new_bmp = self.bpm.value - 10
                    self.Metro_normal.ModificarBPM(new_bmp)
                    self.bpm.value = new_bmp
                    super().update()  
                case 'Numpad 5':
                    self.Tap
                    super().update() 
                case 'Numpad 4':
                    self.check_display()                                         
                                                       


    
    def add_clicked(self, e): 
        data= e.control.data
        match data:
            case 'add_tarefa':
                # print('clicou em add tarefa')
                tarefa = Task(self.nova_tarefa.value, self.task_aba_change, self.task_delete, self.Exibir, self.Stop, self.page)
                # tarefa = self.build_task(self.new_task.value)
                aba = self.filter.tabs[self.filter.selected_index].text
                match aba:
                    case 'Todos':
                        self.tarefas.content.controls.append(tarefa)
                        self.nova_tarefa.value = ""
                    case 'Lento':
                        self.Lento.content.controls.append(tarefa)
                        self.nova_tarefa.value = ""
                    case 'Médio':
                        self.Medio.content.controls.append(tarefa)
                        self.nova_tarefa.value = ""
                    case 'Rápido':
                        self.Rapido.content.controls.append(tarefa)
                        self.nova_tarefa.value = ""
                    case 'Speed Burst':
                        self.Speed.content.controls.append(tarefa)
                        self.nova_tarefa.value = ""                                                                        
            
                
                self.update()
            case 'Continuar':
                self.Metro_normal.continuar = self.ncontinuar.value
            case 'Pomodoro_ativar':
                self.Metro_normal.pomodoro_habilitado = self.pomodoro_ativar.value
            case 'pomodoro':
                self.Metro_normal.tempo_pomodoro = int(self.pomodoro.value)
            case 'descanso':
                self.Metro_normal.tempo_descanso = int(self.descanso.value)
            case 'teste exibir':                         
                saida = Saidas(tempo_de_treino = 'testando...',
                               tempo_pomodoro = 'tempo_pomodoro' ,
                               contagem = 'contagem',
                               tempo_restante = 'tempo_restante',
                               respiracao = 'respiracao',
                               TEXT = 'TEXT'
                               )
                self.saida.content.controls = [saida]
                self.update()
            case 'play':
                self.Exibir(self, 'tocando')



    def Salvar_cofig(self, e):
        arquiv = {'Tarefas':{'tarefa':[], 'bpm':[]},
                  'Lento':{'tarefa':[], 'bpm':[]},
                  'Médio':{'tarefa':[], 'bpm':[]},
                  'Rápido':{'tarefa':[], 'bpm':[]},
                  'Speed':{'tarefa':[], 'bpm':[]},
                  
                  }
        if len(self.tarefas.content.controls) >0:
            for i in self.tarefas.content.controls:
                arquiv['Tarefas']['tarefa'].append(i.nome_tarefa.value)
                arquiv['Tarefas']['bpm'].append(i.bpm.value)
        if len(self.Lento.content.controls) >0:
            for i in self.Lento.content.controls:
                arquiv['Lento']['tarefa'].append(i.nome_tarefa.value)
                arquiv['Lento']['bpm'].append(i.bpm.value)  
        if len(self.Medio.content.controls) >0:
            for i in self.Medio.content.controls:
                arquiv['Médio']['tarefa'].append(i.nome_tarefa.value)
                arquiv['Médio']['bpm'].append(i.bpm.value) 
        if len(self.Rapido.content.controls) >0:
            for i in self.Rapido.content.controls:
                arquiv['Rápido']['tarefa'].append(i.nome_tarefa.value)
                arquiv['Rápido']['bpm'].append(i.bpm.value) 
        if len(self.Speed.content.controls) >0:
            for i in self.Speed.content.controls:
                arquiv['Speed']['tarefa'].append(i.nome_tarefa.value)
                arquiv['Speed']['bpm'].append(i.bpm.value)                                                 



        Escrever_json(arquiv, config)



    def Carregar_dados(self):
        arquiv = Ler_json(config)  
        for i , j in  zip(arquiv['Tarefas']['tarefa'],arquiv['Tarefas']['bpm']):
            tarefa = Task(i, self.task_aba_change, self.task_delete,self.Exibir,self.Stop,self.page, j )
            self.tarefas.content.controls.append(tarefa)
        for i , j in  zip(arquiv['Lento']['tarefa'],arquiv['Lento']['bpm']):
            tarefa = Task(i, self.task_aba_change, self.task_delete,self.Exibir,self.Stop,self.page, j )
            self.Lento.content.controls.append(tarefa) 
        for i , j in  zip(arquiv['Médio']['tarefa'],arquiv['Médio']['bpm']):
            tarefa = Task(i, self.task_aba_change, self.task_delete,self.Exibir,self.Stop,self.page, j )
            self.Medio.content.controls.append(tarefa) 
        for i , j in  zip(arquiv['Rápido']['tarefa'],arquiv['Rápido']['bpm']):
            tarefa = Task(i, self.task_aba_change, self.task_delete,self.Exibir,self.Stop,self.page, j )
            self.Rapido.content.controls.append(tarefa) 
        for i , j in  zip(arquiv['Speed']['tarefa'],arquiv['Speed']['bpm']):
            tarefa = Task(i, self.task_aba_change, self.task_delete,self.Exibir,self.Stop,self.page, j )
            self.Speed.content.controls.append(tarefa)                                     



    def task_aba_change(self, task):
        self.update()



    def task_delete(self, task):
        # print(vars(self.tasks.controls[1]).keys())
        aba = self.filter.tabs[self.filter.selected_index].text
        match aba:
            case 'Todos':
                self.tarefas.content.controls.remove(task)
            case 'Lento':
                self.Lento.content.controls.remove(task)
            case 'Médio':
                self.Medio.content.controls.remove(task)
            case 'Rápido':
                self.Rapido.content.controls.remove(task)
            case 'Speed':
                self.Speed.content.controls.remove(task)                                                

        super().update()


    def Respiro(self):
        descan = int(int(self.descanso.value)*60/8.5)
        self.stop = False
        width_max = 400
        def Inspire(d):
            s = Saidas(f'INSPIRE ({d})')
            s.saida_tempo_de_treino.controls[0].size = 80
            s.saida_tempo_pomodoro.controls[0].size = 30
            s.saida_tempo_de_treino.controls[0].color = colors.YELLOW
            self.saida.content.controls = [s]
            self.saida.content.controls[0].alignment= MainAxisAlignment.START

        def Expire(d):
            s = Saidas(f'EXPIRE  ({d})')
            s.saida_tempo_de_treino.controls[0].size = 80            
            s.saida_tempo_pomodoro.controls[0].size = 30
            s.saida_tempo_de_treino.controls[0].color = colors.GREEN
            self.saida.content.controls = [s]
            self.saida.content.controls[0].alignment= MainAxisAlignment.START

        for d in range(descan,0,-1):
            # a = time()
            Inspire(d)
            super().update()
            for i in range(0,width_max,4):
                self.respiro.width = i
                # sleep(0.0005)
                if self.stop:
                    break
                super().update()
            self.respiro.bgcolor = colors.GREEN
            Expire(d)
            super().update()
            for i in range(width_max,0,-1):
                self.respiro.width = i
                if self.stop:
                    break                    
                sleep(0.01)
                super().update()
            self.respiro.bgcolor = colors.YELLOW
            # b = time()-a
            # print(b)
        self.Metro_normal.contando = False
        self.Mostrar(' ')
        self.respiro.width = 0
        super().update()


    def Exibir(self, task):
        self.stop = False
        tempo = int(int(self.pomodoro.value)*60)
        for i in range(tempo,0,-1):
            h, m,s = self.converter_segundos_para_horas_min_segundos(i)
            self.Mostrar('Treine por:', f'{h}:{m}:{s}')
            if self.stop:
                break
            sleep(1)

        self.Mostrar(' ')


        if self.pomodoro_ativar.value:
            self.Respiro()
           


    def Mostrar(self, *texto):
        self.saida.content.controls = [Saidas(*texto)]
        self.update()
    

    def check_display(self):
        sleep(1)
        while self.Metro_normal.metronomo_inciado:
            sleep(0.5)
            b = self.Metro_normal.display
            self.Mostrar(*b.values() )
            if self.Metro_normal.contando:
                self.Respiro()


        self.Mostrar('')


    def Stop(self, task):
        self.stop = task.stopp
        print('veio stop: ', self.stop)


    @classmethod
    def converter_segundos_para_horas_min_segundos(self, segundos):
        def Algarismos(numero, qtd=2):
            numero = int(numero)
            return str(numero).zfill(qtd)
        horas = segundos // 3600  # 3600 segundos em uma hora
        horas = Algarismos(horas)
        segundos %= 3600
        minutos = segundos // 60  # 60 segundos em um minuto
        minutos = Algarismos(minutos)
        segundos %= 60
        segundos = Algarismos(segundos)

        return horas, minutos, segundos
    

    def update(self):
        aba = self.filter.tabs[self.filter.selected_index].text

        match aba:
            case "Ativos":
                for i, task in enumerate(self.tarefas.content.controls):
                    task.visible = task.completed == False
                for i, task in enumerate(self.Lento.content.controls):
                    task.visible = task.completed == False 
                for i, task in enumerate(self.Medio.content.controls):
                    task.visible = task.completed == False   
                for i, task in enumerate(self.Rapido.content.controls):
                    task.visible = task.completed == False   
                for i, task in enumerate(self.Speed.content.controls):
                    task.visible = task.completed  == False                                        
                                
            case "Concluídos":
                for i, task in enumerate(self.tarefas.content.controls):
                    task.visible = task.completed
                for i, task in enumerate(self.Lento.content.controls):
                    task.visible = task.completed   
                for i, task in enumerate(self.Medio.content.controls):
                    task.visible = task.completed   
                for i, task in enumerate(self.Rapido.content.controls):
                    task.visible = task.completed   
                for i, task in enumerate(self.Speed.content.controls):
                    task.visible = task.completed                                                                              
                                                        

            case "Lento":
                for i, task in enumerate(self.Lento.content.controls):
                    task.visible = True 
            case "Médio":
                for i, task in enumerate(self.Medio.content.controls):
                    task.visible = True 
            case "Rápido":
                for i, task in enumerate(self.Rapido.content.controls):
                    task.visible = True 
            case "Speed Burst":
                for i, task in enumerate(self.Speed.content.controls):
                    task.visible = True                                                             
            case "Todos":
                for i, task in enumerate(self.tarefas.content.controls):
                    task.visible = True                                   
 

        super().update()
    
    
    def Exibir_atributos(self, objeto):
        for i in objeto.__dict__.keys():
            print(i)
    
    
    def tabs_changed(self, e):
        aba = self.filter.tabs[self.filter.selected_index].text
        match aba:
            case "Metrônomo Normal":
                self.tarefas.visible = False
                self.tela_mentronomo_nomal.visible = True
                self.Lento.visible = False
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = False
                super().update()
            case "Lento":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = True 
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = False
                self.update()                                                
            case "Médio":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = False 
                self.Medio.visible = True
                self.Rapido.visible = False
                self.Speed.visible = False
                self.update()
            case "Rápido":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = False 
                self.Medio.visible = False
                self.Rapido.visible = True
                self.Speed.visible = False
                self.update()
            case "Speed Burst":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = False 
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = True
                self.update()

            case 'Ativos':
                self.Lento.visible = True
                self.Medio.visible = True
                self.Rapido.visible = True
                self.Speed.visible = True
                self.tarefas.visible = True
                self.tela_mentronomo_nomal.visible = False
                self.update() 
            case 'Concluídos':
                self.Lento.visible = True
                self.Medio.visible = True
                self.Rapido.visible = True
                self.Speed.visible = True                
                self.tarefas.visible = True
                self.tela_mentronomo_nomal.visible = False
                self.update()                               

            case _:
                self.Lento.visible = False
                self.tarefas.visible = True
                self.tela_mentronomo_nomal.visible = False
                self.update()


    def Definir_tela_inicial(self):
        aba = self.filter.tabs[self.filter.selected_index].text    
        match aba:
            case "Metrônomo Normal":
                self.tarefas.visible = False
                self.tela_mentronomo_nomal.visible = True
                self.Lento.visible = False
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = False
            case "Lento":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = True 
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = False                                             
            case "Médio":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = False 
                self.Medio.visible = True
                self.Rapido.visible = False
                self.Speed.visible = False
            case "Rápido":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = False 
                self.Medio.visible = False
                self.Rapido.visible = True
                self.Speed.visible = False
            case "Speed Burst":
                self.tela_mentronomo_nomal.visible = False
                self.tarefas.visible = False
                self.Lento.visible = False 
                self.Medio.visible = False
                self.Rapido.visible = False
                self.Speed.visible = True
                self.update()

            case 'Ativos':
                self.Lento.visible = True
                self.Medio.visible = True
                self.Rapido.visible = True
                self.Speed.visible = True
                self.tarefas.visible = True
                self.tela_mentronomo_nomal.visible = False
            case 'Concluídos':
                self.Lento.visible = True
                self.Medio.visible = True
                self.Rapido.visible = True
                self.Speed.visible = True                
                self.tarefas.visible = True
                self.tela_mentronomo_nomal.visible = False 

            case _:
                self.tarefas.visible = True
                self.tela_mentronomo_nomal.visible = False
                self.Lento.visible = False

     
        super().update()


    def sair(self, e):
        self.tela_mentronomo_nomal.content = Row(vertical_alignment = CrossAxisAlignment.CENTER,
                                                alignment=MainAxisAlignment.SPACE_AROUND)     
        self.tela_mentronomo_nomal.content.controls = [self.Metro_normal.bpm,
                                                    self.Vol,
                                                    self.Metro_normal.icon_play,
                                                    self.Metro_normal.icon_pause,
                                                    self.Metro_normal.stope,
                                                    self.tap]

        self.tela_mentronomo_nomal.visible = True       
        super().update()

    def Selecionar_cor(self, e):
        cor = ColorPicker()       
        self.tela_mentronomo_nomal.content = Row([cor, FloatingActionButton('Sair', on_click=self.sair)])
        super().update()



    @property
    def Barra_App(self):
        self.barra_app =  AppBar(
            leading=IconButton(icons.PALETTE, on_click = self.Selecionar_cor, tooltip='selecionar cor'),
            # leading_width=self.page.window_width,
            # automatically_imply_leading = True,
            title=Text("Metrônomo"),
            center_title=False,
            bgcolor='#343746')
        self.barra_app.actions=[
                IconButton(icons.WB_SUNNY_OUTLINED),
                IconButton(icons.FILTER_3),
                PopupMenuButton(
                    items=[
                        PopupMenuItem(text="Item 1"),
                        PopupMenuItem(),  # divider
                        PopupMenuItem(
                            text="Checked item", checked=False, 
                            # on_click=check_item_clicked
                        ),
                    ]
                )
            ]
          



    def edit_clicked(self, e):
        self.edit_name.value = self.nome_tarefa.value
        self.display_view.visible = False
        self.edit_view.visible = True
        self.update()
    def save_clicked(self, e):
        self.nome_tarefa.value = self.edit_name.value
        self.display_view.visible = True
        self.edit_view.visible = False
        self.update()
    def aba_changed(self, e):
        self.completed = self.display_task.value
        self.task_aba_change(self)
    def delete_clicked(self, e):
        self.task_delete(self)
    def Ler_parametros(self):
        nome_tarefa = self.nome_tarefa.value
        self.pomodoro_habilitado = self.pomodoro_ativar.value
        self.tempo_pomodoro = self.pomodoro.value
        self.tempo_descanso = self.descanso.value
        self.continuar = self.ncontinuar.value 
        bpm_atual= float(self.bpm.value)
        return nome_tarefa, bpm_atual
    


def main(page: Page):
    page.title = "ToDo App"
    page.horizontal_alignment = "center"
    page.scroll = ScrollMode.ADAPTIVE
    page.bgcolor = '#282a36'
    page.theme = theme.Theme( font_family="Verdana")
    page.theme_mode = ThemeMode.DARK
    page.window_width = 900

    


    app = TodoApp(page)
    page.on_keyboard_event = app.Teclas
    page.add(app)
    app.Barra_App
    page.appbar = app.barra_app



    page.update() 



app(target=main, view=WEB_BROWSER)
# flet.app(target=main)

'''Lista de coisas a implementar no app:-----------------------------------------------------

 - criar módulos separdas para layout, ações dos botoes, ...
- Adicionar um time para a duração do treino (1h)
- enviar os dados de exibição de controlador_metronomo_flet para o container saida de Todoapp
- ativar as funções do metrônomo (modos de treino e etc)
- Botão para dar play na lista de tarefas e eceutar todas
- Botâo para importar/exportar lista de tarefas
- display para mostar o tempo total da lista de tarefas
- Dropdown para selecionar alguma config salva
- selecionar temas
- Habilitar os modos Treinamento e compassos
- Habilitar as exibições das saídas
- criar abas: lento, médio, rápido, speedburst em filtros
- Exibir o tempo de descanso
- exibir o valor do volume
 - mewlhorar a vizualizaç~~ao das saídas





- criar um atributo em metronomo para que quando ele esteja ativado, todoapp exibir o respiro -ok
- ativar o "salvar" na tela lento - ok
- criar telas "ativos" e "Concluídos - ok
- recriar a janela metronomo normal (desta vez, usando parâmentro em todoapp) -ok
- criar um atributo em crontole metronomo para receber as 'atualizações de tela' - ok
- fzer o metrônomo tocar - ok (o problema estava na thread - daemon = True)
- adicionar um seletor de cores na tela metronomo normal - ok
- ativar função salvar para "lento" - ok
- ativar as teclas apenas em "metronomo normal' - ok
- ativar a funcção deletar tarefas na tela "Lento - ok
- ativar a opção "concluido" para as tarefas da tela lwnto - ok
- colocar o scroll na tela lento - ok
- Display para os bpm - ok
- criar um tela para o metrônomo normal - ok
- Botão Play para o Metrônomo normal - ok
- Botão Pause para o Metrônomo normal - ok
- Botão Stop para o Metrônomo normal - ok
- Botão Salvar  - ok
- Botões aumendar e diminuir bpm (+-1,+-5,+-10)
- Botão de Volume - ok
- Botão tap -ok
- ativar teclas do teclado - ok
'''

